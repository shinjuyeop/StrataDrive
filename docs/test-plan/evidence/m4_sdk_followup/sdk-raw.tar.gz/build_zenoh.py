import fcntl,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'build/m4-sdk-followup';lock=(root/'build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
home=out/'toolchain';src=next((out/'zenoh-source').iterdir());env={**os.environ,'CARGO_HOME':str(home/'cargo'),'RUSTUP_HOME':str(home/'rustup'),'PATH':str(home/'cargo/bin')+':'+os.environ['PATH']}
plan=[]
for name,toolchain in [('baseline','1.97.1'),('tsan','nightly-2026-10-20')]:
 e={**env,'CARGO_TARGET_DIR':str(out/('zenoh-'+name))}
 cmd=[str(home/'cargo/bin/cargo'),'+'+toolchain,'build','--locked','--no-default-features','--features','transport_tcp','--target','x86_64-unknown-linux-gnu','-j4']
 if name=='tsan':
  e['RUSTFLAGS']='-Zsanitizer=thread -Zexternal-clangrt -Cdebuginfo=2';cmd+=['-Zbuild-std']
 plan.append(dict(name=name,command=cmd,env={k:v for k,v in e.items() if k in ('CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','RUSTFLAGS')},timeout=900))
(out/'zenoh-build-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
results=[]
for row in plan:
 start=time.monotonic()
 with (out/('zenoh-'+row['name']+'-build.log')).open('w') as log:
  try: code=subprocess.run(row['command'],cwd=src,env={**env,**row['env']},stdout=log,stderr=subprocess.STDOUT,timeout=row['timeout']).returncode
  except subprocess.TimeoutExpired: code=124
 results.append(dict(name=row['name'],exit=code,seconds=time.monotonic()-start));(out/'zenoh-build-results.json').write_text(json.dumps(results,indent=2)+'\n');print(results[-1],flush=True)
