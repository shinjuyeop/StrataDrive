import fcntl, hashlib, json, os, subprocess, urllib.request
from pathlib import Path
root=Path.cwd(); out=root/'build/m4-sdk-followup'; home=out/'toolchain';home.mkdir(exist_ok=True)
lock=(root/'build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
env={**os.environ,'CARGO_HOME':str(home/'cargo'),'RUSTUP_HOME':str(home/'rustup')}
url='https://static.rust-lang.org/rustup/dist/x86_64-unknown-linux-gnu/rustup-init'
data=urllib.request.urlopen(url,timeout=60).read();expected=urllib.request.urlopen(url+'.sha256',timeout=30).read().decode().split()[0]
assert hashlib.sha256(data).hexdigest()==expected
exe=home/'rustup-init';exe.write_bytes(data);exe.chmod(0o700)
commands=[[str(exe),'-y','--no-modify-path','--profile','minimal','--default-toolchain','none'],[str(home/'cargo/bin/rustup'),'toolchain','install','1.97.1','--profile','minimal'],[str(home/'cargo/bin/rustup'),'toolchain','install','nightly-2026-10-20','--profile','minimal','--component','rust-src']]
(out/'rust-inputs.json').write_text(json.dumps(dict(installer_url=url,sha256=expected,commands=commands,env={k:env[k] for k in ('CARGO_HOME','RUSTUP_HOME')}),indent=2)+'\n')
results=[]
for n,cmd in enumerate(commands):
 with (out/f'rust-prepare-{n}.log').open('w') as log:
  try: code=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired: code=124
 results.append(dict(command=cmd,exit=code));(out/'rust-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(n,code,flush=True)
 if code: break
