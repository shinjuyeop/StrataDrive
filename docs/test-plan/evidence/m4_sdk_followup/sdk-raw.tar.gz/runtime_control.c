#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
static atomic_uint ready; static volatile unsigned bad_ready; static int payload, bad;
static void *writer(void *p) { (void)p; payload=42; if(bad) bad_ready=1; else atomic_store_explicit(&ready,1,memory_order_release); return 0; }
static void *reader(void *p) { (void)p; if(bad) {while(!bad_ready){}} else {while(!atomic_load_explicit(&ready,memory_order_acquire)){}} printf("payload=%d\n",payload); return 0; }
int main(int argc,char **argv) { if(argc!=2)return 2;bad=!strcmp(argv[1],"race");pthread_t a,b;if(pthread_create(&a,0,reader,0)||pthread_create(&b,0,writer,0))return 2;pthread_join(a,0);pthread_join(b,0);return payload!=42; }
