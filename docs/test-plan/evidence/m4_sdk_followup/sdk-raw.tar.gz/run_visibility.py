import fcntl,hashlib,json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'build/m4-sdk-followup/visibility';out.mkdir(exist_ok=False)
lock=(root/'build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
src=root/'tests/integration/middleware/dds_atomic_visibility.c';prefix=root/'build/m4-dds-full-tsan/install'
cmd=['gcc','-std=c11','-O2','-g','-fsanitize=thread','-fno-omit-frame-pointer','-pthread','-I'+str(prefix/'include'),str(src),'-L'+str(prefix/'lib'),'-Wl,-rpath,'+str(prefix/'lib'),'-lddsc','-o',str(out/'visibility')]
plan=dict(compiler=subprocess.check_output(['gcc','--version'],text=True).splitlines()[0],command=cmd,source_sha256=hashlib.sha256(src.read_bytes()).hexdigest(),repetitions=3,modes=['vendor','c11-control','race-control'],planned=9,timeout_seconds=15,scope='helper visibility only; not GC lifetime correctness or middleware acceptance')
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
with (out/'assembly.txt').open('w') as f:subprocess.run(['objdump','-d',str(out/'visibility')],stdout=f,check=True)
rows=[]
for rep in range(1,4):
 for mode in plan['modes']:
  command=['setarch','x86_64','-R',str(out/'visibility'),mode]
  try:r=subprocess.run(command,capture_output=True,text=True,timeout=15);code=r.returncode;log=r.stdout+r.stderr
  except subprocess.TimeoutExpired as e:code=124;log=str(e)
  (out/f'{rep}-{mode}.log').write_text(log);rows.append(dict(repetition=rep,mode=mode,exit=code,warnings=log.count('WARNING: ThreadSanitizer'),payload_ok='payload=42' in log,command=command))
  (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps(rows,indent=2))
