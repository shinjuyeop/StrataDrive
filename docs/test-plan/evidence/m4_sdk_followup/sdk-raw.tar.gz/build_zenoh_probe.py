import fcntl,json,subprocess
from pathlib import Path
root=Path.cwd();out=root/'build/m4-sdk-followup';lock=(root/'build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
src=next((out/'zenoh-source').iterdir());rt=out/'toolchain/rustup/toolchains/nightly-2026-10-20-x86_64-unknown-linux-gnu/lib/rustlib/x86_64-unknown-linux-gnu/lib/librustc-nightly_rt.tsan.a'
commands=[]
for mode in ('baseline','tsan'):
 build=out/('probe-'+mode)
 cmd=['cmake','-S',str(root),'-B',str(build),'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_C_COMPILER=clang-14','-DCMAKE_CXX_COMPILER=clang++-14','-DBUILD_TESTING=OFF','-DSTRATADRIVE_MIDDLEWARE_PROBES=ON','-DCMAKE_PREFIX_PATH='+str(root/'build/m4-communication-research/install'),'-DSTRATADRIVE_ZENOH_INCLUDE='+str(src/'include'),'-DSTRATADRIVE_ZENOH_LIBRARY='+str(out/('zenoh-'+mode)/'x86_64-unknown-linux-gnu/debug/libzenohc.so')]
 if mode=='tsan':cmd+=['-DSTRATADRIVE_TSAN=ON','-DCMAKE_EXE_LINKER_FLAGS=-fno-sanitize-link-runtime -Wl,--whole-archive,'+str(rt)+',--no-whole-archive -Wl,--export-dynamic -lpthread -ldl -lrt -lm']
 for command in (cmd,['cmake','--build',str(build),'--target','zenoh_candidate_probe','-j4']):
  commands.append(command);(out/'zenoh-probe-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
  with (out/f'zenoh-probe-build-{len(commands)}.log').open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
  print(mode,len(commands),code,flush=True)
  if code:raise SystemExit(code)
