import fcntl,json,subprocess,hashlib,os
from pathlib import Path
root=Path.cwd();parent=root/'build/m4-sdk-followup';out=parent/'zenoh-comparison';out.mkdir(exist_ok=False);lock=(root/'build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
binary=parent/'probe-tsan/tests/integration/middleware/zenoh_candidate_probe'
plan=dict(profiles=['partial','full'],conditions=['normal','overflow'],repetitions=2,planned=8,timeout=30,compiler='same Clang14 probe and LLVM23.1.4 runtime',rust='same nightly-2026-10-20',features=['transport_tcp'],suppression=False,env_sanitizer={k:v for k,v in os.environ.items() if k.startswith(('TSAN_','ASAN_','UBSAN_'))})
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
layouts={}
for mode,directory in [('partial','zenoh-nightly-uninstrumented'),('full','zenoh-tsan')]:
 p=parent/directory;files=list(p.glob('x86_64-unknown-linux-gnu/debug/build/**/out/opaque_types.rs'));assert len(files)==1
 layouts[mode]=hashlib.sha256(files[0].read_bytes()).hexdigest()
 lib=p/'x86_64-unknown-linux-gnu/debug/libzenohc.so';layouts[mode+'_library']=hashlib.sha256(lib.read_bytes()).hexdigest()
 assert lib.exists()
(out/'layouts.json').write_text(json.dumps(layouts,indent=2)+'\n');assert layouts['partial']==layouts['full']
rows=[]
for rep in range(1,3):
 for mode in plan['profiles']:
  libdir=parent/('zenoh-tsan' if mode=='full' else 'zenoh-nightly-uninstrumented')/'x86_64-unknown-linux-gnu/debug'
  for case in plan['conditions']:
   folder=out/f'{rep}-{mode}-{case}';folder.mkdir();cmd=['unshare','-Urnm','setarch','x86_64','-R','env','LD_LIBRARY_PATH='+str(libdir),'python3',str(root/'tests/integration/middleware/run_probe.py'),'--child',str(folder),str(binary),case]
   (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
   with (folder/'run.log').open('w') as log:
    try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=30).returncode
    except subprocess.TimeoutExpired:code=124
   result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
   warnings=sum(p.read_text().count('WARNING: ThreadSanitizer') for p in folder.glob('*.stderr'))
   rows.append(dict(repetition=rep,profile=mode,case=case,exit=code,warnings=warnings,verdict='PASS' if code==0 and not warnings and result.get('verdict')=='PASS' else 'FAIL'))
   (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
raise SystemExit(0 if all(r['verdict']=='PASS' for r in rows) else 1)
