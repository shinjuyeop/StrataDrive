import fcntl,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'build/m4-sdk-followup/dds-official';out.mkdir(exist_ok=False);prefix=out/'install'
lock=(root/'build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
src=root/'build/m4-communication-research/deps/cyclonedds-src/eclipse-cyclonedds-cyclonedds-e54e991'
commands=[['cmake','-S',str(src),'-B',str(out/'build'),'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DBUILD_TESTING=OFF','-DBUILD_EXAMPLES=OFF','-DBUILD_DDSPERF=OFF','-DENABLE_SECURITY=OFF','-DENABLE_ICEORYX=OFF','-DBUILD_IDLC=OFF','-DSANITIZER=thread','-DCMAKE_C_FLAGS=-fno-omit-frame-pointer','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON'],['cmake','--build',str(out/'build'),'-j4'],['cmake','--install',str(out/'build')]]
plan=dict(commands=commands,conditions=['normal','overflow'],repetitions=2,planned=4,timeout_seconds=30,suppression=False)
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
for i,c in enumerate(commands):
 with (out/f'build-{i}.log').open('w') as log:
  code=subprocess.run(c,stdout=log,stderr=subprocess.STDOUT,timeout=240).returncode
 if code:raise SystemExit(code)
(out/'sdk-sha256.txt').write_text(hashlib.sha256((prefix/'lib/libddsc.so.11.0.1').read_bytes()).hexdigest()+'\n')
rows=[]
for rep in range(1,3):
 for case in plan['conditions']:
  folder=out/f'{rep}-{case}';folder.mkdir();cmd=['unshare','-Urnm','setarch','x86_64','-R','env','LD_LIBRARY_PATH='+str(prefix/'lib'),'python3',str(root/'tests/integration/middleware/run_probe.py'),'--child',str(folder),str(root/'build/m4-probe-tsan/tests/integration/middleware/dds_candidate_probe'),case]
  (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
  with (folder/'run.log').open('w') as log:
   try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=30).returncode
   except subprocess.TimeoutExpired:code=124
  result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
  warnings=sum(p.read_text().count('WARNING: ThreadSanitizer') for p in folder.glob('*.stderr'))
  rows.append(dict(repetition=rep,case=case,exit=code,warnings=warnings,verdict='PASS' if code==0 and not warnings and result.get('verdict')=='PASS' else 'FAIL'))
  (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
raise SystemExit(0 if all(r['verdict']=='PASS' for r in rows) else 1)
