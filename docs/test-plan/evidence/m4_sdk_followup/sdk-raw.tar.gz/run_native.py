import fcntl,subprocess
from pathlib import Path
lock=Path('build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
with Path('build/m4-sdk-followup/native40.log').open('w') as log:
 r=subprocess.run(['python3','tests/integration/runtime/check_m4_delivery_trace.py','build/m4-sdk-followup/native40'],stdout=log,stderr=subprocess.STDOUT)
Path('build/m4-sdk-followup/native40.exit').write_text(str(r.returncode)+'\n');raise SystemExit(r.returncode)
