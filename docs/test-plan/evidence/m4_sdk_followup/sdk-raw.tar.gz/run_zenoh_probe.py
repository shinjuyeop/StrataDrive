import fcntl,json,subprocess,hashlib
from pathlib import Path
root=Path.cwd();out=root/'build/m4-sdk-followup/zenoh-probes';out.mkdir(exist_ok=False);lock=(root/'build/.m4-exclusive.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
plan=dict(profiles=['baseline','tsan'],conditions=['normal','overflow'],repetitions=2,planned=8,timeout=30,features=['transport_tcp'],sanitizer_runtime='Rust nightly-2026-10-20 LLVM23.1.4 static runtime; Clang14 C/C++; experimental interop, not original SDK binary',suppression=False)
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rows=[]
for rep in range(1,3):
 for profile in plan['profiles']:
  binary=root/'build/m4-sdk-followup'/('probe-'+profile)/'tests/integration/middleware/zenoh_candidate_probe'
  if rep==1:
   (out/(profile+'-loader.txt')).write_text(subprocess.check_output(['ldd',str(binary)],text=True));(out/(profile+'-sha256.txt')).write_text(hashlib.sha256(binary.read_bytes()).hexdigest()+'\n')
  for case in plan['conditions']:
   folder=out/f'{rep}-{profile}-{case}';folder.mkdir();cmd=['unshare','-Urnm','setarch','x86_64','-R','python3',str(root/'tests/integration/middleware/run_probe.py'),'--child',str(folder),str(binary),case]
   (folder/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
   with (folder/'run.log').open('w') as log:
    try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=30).returncode
    except subprocess.TimeoutExpired:code=124
   result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
   warnings=sum(p.read_text().count('WARNING: ThreadSanitizer') for p in folder.glob('*.stderr'))
   rows.append(dict(repetition=rep,profile=profile,case=case,exit=code,warnings=warnings,verdict='PASS' if code==0 and not warnings and result.get('verdict')=='PASS' else 'FAIL'))
   (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
raise SystemExit(0 if all(r['verdict']=='PASS' for r in rows) else 1)
