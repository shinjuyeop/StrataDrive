#pragma once
#include "someip/diagnostic_channel.hpp"
#include "someip/owner_message_binding.hpp"
#include "remote_diagnostics_context.hpp"
#include "startup_diagnostics.hpp"
#include "native_diagnostics.hpp"
#include "owner_diagnostics.hpp"
#include "async_leaf_owner.hpp"
#include "async_zone_owner.hpp"
#include "latest_snapshot.hpp"
#include <filesystem>
#include <thread>

namespace stratadrive::someip {class Transport;}
namespace stratadrive::someip::test {
struct DiagnosticSource {unsigned producer;Ecu ecu;diagnostics::Component component;bool native;};
inline constexpr std::array<DiagnosticSource,9> diagnostic_sources{{
    {20,Ecu::Front,diagnostics::Component::Front,false},{21,Ecu::Rear,diagnostics::Component::Rear,false},
    {22,Ecu::Front,diagnostics::Component::Steering,false},{23,Ecu::Front,diagnostics::Component::Brake,false},
    {24,Ecu::Rear,diagnostics::Component::Drive,false},{30,Ecu::Front,diagnostics::Component::Front,true},
    {31,Ecu::Rear,diagnostics::Component::Rear,true},{32,Ecu::Rear,diagnostics::Component::Bms,true},
    {33,Ecu::Rear,diagnostics::Component::Power,true}}};
inline constexpr std::uint64_t diagnostic_run=8001;
inline constexpr diagnostic::Services context_services(unsigned z) {return {static_cast<std::uint16_t>(0x5e00+2*z),static_cast<std::uint16_t>(0x5e01+2*z)};}
inline constexpr diagnostic::Services source_services(unsigned i) {return {static_cast<std::uint16_t>(0x5e10+2*i),static_cast<std::uint16_t>(0x5e11+2*i)};}
// Composition adapter for the existing native 3-ECU opt-in harness. Capture
// methods run solely on the actual ECU owner; worker owns all store/SDK IO.
class NativeDiagnosticRoutes {
public:
    static void bootstrap(const std::filesystem::path&);
    NativeDiagnosticRoutes(Ecu,const std::filesystem::path&,const std::string& tag);
    ~NativeDiagnosticRoutes();
    void configure(const std::shared_ptr<vsomeip::application>&);
    void registered();
    void start(Transport&);
    bool finish();
    void central(const session::SessionCoordinator&,const central::VehicleCoordinator&,std::uint64_t);
    void zone(unsigned,const zone::AsyncZoneOwner&,bool gate,const remote::RunLeaseEvidence&,std::uint64_t);
    void leaf(unsigned,const simulation::AsyncLeafOwner&,bool gate,const remote::RunLeaseEvidence&,std::uint64_t);
private:
    struct Source {
        struct Evidence {remote::RunLeaseEvidence credit;std::uint64_t captured_ns;};
        struct Original {NativeObservation fault;unsigned monitor;std::optional<std::uint64_t> selected;};
        diagnostics::EventQueue queue;
        runtime::LatestSnapshot<Evidence> evidence;
        std::array<runtime::LatestSnapshot<Original>,2> original;
        std::array<std::optional<Original>,2> last_original;
        std::unique_ptr<diagnostics::OwnerDiagnostics> owner;
        std::unique_ptr<diagnostics::NativeDiagnostics> native;
        std::uint32_t epoch{0};std::atomic<std::uint32_t> admitted{0};
        Source(const DiagnosticSource&);
    };
    void bind(Source&,std::uint32_t,std::uint64_t,const remote::RunLeaseEvidence&,std::uint64_t);
    void original(Source&,unsigned,const std::optional<NativeObservation>&,std::optional<std::uint64_t>);
    void work();
    const Ecu ecu_;const std::filesystem::path folder_;const std::string tag_;
    std::array<std::unique_ptr<Source>,9> sources_;
    std::array<std::unique_ptr<diagnostic::Channel>,9> source_channels_;
    std::array<std::unique_ptr<diagnostic::Channel>,2> context_channels_;
    diagnostics::EventQueue startup_queue_{diagnostic_run,7},central_queue_{diagnostic_run,8};
    diagnostics::StartupDiagnostics startup_{startup_queue_,{diagnostic_run,7,diagnostics::Domain::Monotonic,kDomain,1},diagnostics::Component::Coordinator,8,true};
    diagnostics::ControlDiagnostics central_{central_queue_,{diagnostic_run,8,diagnostics::Domain::Monotonic,kDomain,1}};
    std::uint32_t central_epoch_{0};
    std::atomic<bool> producing_{true};std::thread worker_;bool passed_{false};
};
} // namespace stratadrive::someip::test
