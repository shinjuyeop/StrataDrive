from pathlib import Path
import hashlib,json,re,subprocess,tarfile,xml.etree.ElementTree as ET
root=Path('build/native-epoch-replacement');out=Path('docs/test-plan/evidence/native-epoch-replacement')
changed=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
sources=sorted(Path(p) for p in changed if not p.startswith('docs/') and (Path(p).suffix in ('.cpp','.hpp','.cmake','.py') or Path(p).name=='CMakeLists.txt'))
meta=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sources]
(out/'sources.json').write_text(json.dumps(meta,indent=2)+'\n')
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
 for p in sources:tar.add(p,arcname=str(p))
cohorts=[];audits={}
with tarfile.open(out/'someip.tar.gz','w:gz') as tar:
 for folder in sorted(root.iterdir()):
  if folder.name=='validation':continue
  tar.add(folder,arcname=folder.name)
  results=json.loads((folder/'results.json').read_text())
  reports=[json.loads(p.read_text()) for p in sorted(folder.glob('*/result.json'))]
  assert reports and all(d['pass'] for d in reports)
  cohorts.append(dict(name=folder.name,results=results,runs=reports))
  audits[folder.name]=json.loads((root/'validation'/(folder.name+'-audit.json')).read_text())
(out/'audits.json').write_text(json.dumps(audits,indent=2)+'\n')
xml=ET.parse(root/'validation/debug-tests.xml').getroot();assert int(xml.attrib['failures'])==0
san=(root/'validation/sanitized-tests.log').read_text();counts=[int(x) for x in re.findall(r'\[  PASSED  \] (\d+) tests\.',san)]
assert counts==[49,39,16,5] and 'runtime error:' not in san and 'ERROR: AddressSanitizer' not in san
py=(root/'validation/python-tests.log').read_text();assert 'Ran 280 tests' in py and py.rstrip().endswith('OK')
for name in ('tidy-core.log','tidy-native.log'):assert not (root/'validation'/name).read_text().strip()
bins=['build/m1-angle/diagnostics_delivery_test','build/m1-angle/remote_diagnostics_context_test','build/m5-someip-normal/project/tests/integration/someip/someip_front_adapter']
report=dict(passed=True,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),scope='Opt-in live Front/Rear ECU replacement with fixed logical epoch streams and Central retirement spool',
 debug=dict(tests=int(xml.attrib['tests']),failures=0,excluded_label='runtime.wall'),sanitized=dict(tests=sum(counts),asan=True,ubsan=True,tsan=False),python_tests=280,clang_tidy_units=4,
 audits=audits,cohorts=cohorts,binaries=[dict(path=p,sha256=hashlib.sha256(Path(p).read_bytes()).hexdigest()) for p in bins],
 remaining=['Central process replacement and terminal service with epoch families','CARLA supervised recovery driving and actual application epoch transition','Role membership additions/removals','Single-epoch rollover and disk lifecycle','Whole wall/Target/ODD and trained model'])
(out/'acceptance.json').write_text(json.dumps(report,indent=2)+'\n')
with tarfile.open(out/'validation.tar.gz','w:gz') as tar:
 tar.add(root/'validation',arcname='validation')
 for build in ('m1-angle','m1-angle-sanitized','m5-someip-normal/project'):
  for name in ('CMakeCache.txt','compile_commands.json'):
   tar.add(Path('build')/build/name,arcname='build-config/'+build+'/'+name)
print(json.dumps(dict(sources=len(sources),cohorts=len(cohorts),debug=report['debug'],sanitized=report['sanitized'])))
