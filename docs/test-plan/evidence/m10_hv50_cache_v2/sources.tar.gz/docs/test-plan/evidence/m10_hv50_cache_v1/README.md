# Explicit HV50 and closed recording cache V1

Prospective30s then300s, stop on first original failure. See [protocol](../../perception-hv50-cache-v1-protocol.md). Results pending; not M10 acceptance.
