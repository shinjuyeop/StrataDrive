# Explicit HV50/cache V2 with direct stock startup map

V1 failed in empty preparation before native START. This fresh series selects Town03 through one temporary GameDefaultMap field and restores the original config inode. See [protocol](../../perception-hv50-cache-v2-protocol.md). Not yet live acceptance.
