#!/usr/bin/env python3
"""Plot original body speed and decoded actuator acquisitions around terminal events."""
import argparse
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from evidence_io import json_rows
from audit_m7_1q_native import frame, wire

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('directory', type=Path)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
fig, axes = plt.subplots(3, 2, figsize=(11, 8), sharex=True, constrained_layout=True)
for column, name in enumerate(('stop-01', 'input-loss-01')):
    report = json.loads((a.directory / (name + '-audit.json')).read_text())
    data = []
    for row in json_rows(a.directory / name / 'trace.jsonl'):
        t = row['simulation_seconds'] - report['trigger_ns'] * 1e-9
        if not -1 <= t <= 6:
            continue
        proof = row['native']['native_export']
        brake = frame(wire(proof['actual'][1], 0, 7, 9), 1, True, require_wheel=False)
        drive = frame(wire(proof['actual'][2], 1, 7, 9), 2, True, require_wheel=False)
        data.append((t, row['physics']['body_forward_velocity_m_s'] * 3.6,
                     drive['value'], brake['value'] / 1e6))
    t, speed, torque, pressure = zip(*data)
    for axis, values, label in zip(axes[:, column], (speed, torque, pressure),
                                  ('Body speed (km/h)', 'Actual torque (Nm)', 'Actual brake (MPa)')):
        axis.plot(t, values)
        axis.axvline(0, color='black', linestyle='--', alpha=.5)
        axis.axvline(report['stop_delay_s'], color='green', linestyle=':', label='Physical stop')
        axis.set_ylabel(label)
        axis.grid(alpha=.25)
    axes[0, column].set_title(report['mode'] + ' | Town03, simulation time')
    axes[0, column].legend(loc='upper right')
    if report['complete_delay_s'] is not None:
        axes[2, column].axvline(report['complete_delay_s'], color='purple', linestyle='-.', label='HV-off complete')
        axes[2, column].legend(loc='lower right')
    axes[2, column].set_xlabel('Seconds since terminal event')
fig.savefig(a.output, dpi=150)
