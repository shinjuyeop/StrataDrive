# M7 NoDrive 최소 서버 포트

CARLA0.9.16 commit `294096eb1c38eabf246e4f3a9cdab704e33a7f4c`와 프로젝트의
UE4.26.2 Linux 도구체인을 대상으로 하는 **opt-in 진단 포트**다.
zero-only는 [M7-1k](../../../docs/test-plan/evidence/m7_carla_1k/README.md), 승인 V1 nonzero는
[M7-1m](../../../docs/test-plan/evidence/m7_carla_1m/README.md) 범위다. 정상 주행 backend가 아니다.

`install.py --carla <source-root> --engine <pinned-ue-root> --manifest <external-path.json>`은 고정 revision과 원본
integration 파일을 검사하고 프로젝트 소스를 외부 CARLA fork에 설치한다. 다운로드·빌드·실행은
하지 않는다. 재실행은 manifest의 원본을 기준으로 패치를 재생성하며 알 수 없는 변경을 거부한다.
manifest는 실제 설치 소스 hash와 기존 RPC130개의 허용/차단 결정을 보존한다.
원래 빌드 호환 패치와 SimReady 설정을 변경하지 않는다.

`UM7NoDriveMovement`는 기존4W component의 wheel/animation 연결을 유지하고 명시적으로
바인딩된 차량만 `PxVehicleNoDrive`로 전환한다. 그 차량에서는 stock engine/gear/control
처리를 실행하지 않는다. 다른 차량은 기존4W 동작을 사용한다. M6 원본 receiver·codec12개는
byte 그대로 복사해 별도 `M7Native` UE 모듈에서 C++17/clang10/libc++로 컴파일한다.
Linux visibility 설정으로 필요한 원본 심볼을 내보내며 외부 PhysX SDK 바이너리를 링크하지 않는다.
엔진 소스/PhysX solver는 수정하지 않는다.1o의 직접 solver 읽기는 고정 UE commit과 두 header
hash를 검사하고 해당 설치의 내부 header를 include한다. engine 코드를 vendoring하지 않는다.
다른 플랫폼/UE 버전은 미지원이다.

서버는 `-StrataM7ZeroProbe` 또는 `-StrataM7V1Probe` 중 하나와 최소32문자의
`STRATADRIVE_M7_OWNER_KEY`가 있어야 bind를 허용한다. 두 flag 동시 지정은 거부한다.
V1 bind는 [승인 가상 모델](virtual_ev_v1.json)의 SHA256도 요구한다. 계수는 client 입력이 아니라
`model_header.py`로 생성한 서버 상수다. owner key는 실행 환경에서 만들고 서버/시험 client에만 전달한다. 저장소,
로그, RPC evidence에 키를 넣지 않는다. 전용 서버·무허가 client 배제는 계속 환경 gate다.
stock CARLA 전체를 인증·암호화하는 기능으로 주장하지 않는다.

RPC는 `client.m7_nodrive(JSON-string)` 하나이며 schema는 `m7-nodrive-zero-probe-v1`이다.
uint64 값은 정확한 decimal 문자열로 보존한다. `describe` 외 변경/receipt 요청은 owner key,
서버가 발급한 run UUID/session을 요구한다. wire/owner-wire v1 개정이 아니다.

| 요청 | 동작 |
| --- | --- |
| describe | 진단 한계·현재 frame·readback 조회. 정상 driving/work capability는 false |
| geometry | owner/run/session과 동일 physics generation을 검사한 읽기 전용 reference/rest geometry. actor/body/COM pose·reference bone·offset을 SI로 반환하며 tick/actuation 없음 |
| bind(actor) | sync10ms·4wheel 확인, 새 session/application epoch 발급, NoDrive 생성. 실패는 latch |
| stage(frame, steering/brake/drive) | 원래 CAN ID/FD flags/전체 payload hex와 oldest/expiry 검사. 각 native Actual receiver/P05/epoch/sequence/source 검사. zero profile은 세 값 모두0, V1은 고정 geometry와 승인 범위/law를 검사해 원자적 수용 |
| advance(ticket) | 한 번만 tick cue를 큐에 넣음. 응답은 queued이며 physics receipt가 아님 |
| receipt | physics 후 실제 frame/시각·원래 Actual·setter readback·raw signed ω 조회. 반복 조회는 재적용 없음 |
| pause | pending 폐기·setter 제거·latch. 자동 재무장 없음 |
| reset | pending 폐기·실제 physics state 재생성·latch. epoch 재사용으로 주행을 재개하지 않음 |
| close | setter 제거·바인딩한 ego 종료·독점 gate 해제. 다음 actor는 새 INIT/session 필요 |

바인딩 중 기존 제어·force/velocity/pose·physics·설정/reload·batch·일반 tick RPC는 서버에서
거부하고 route별 거부 횟수를 조회할 수 있다. `FCarlaServer::Tick` 내부 cue도 통과시키지 않는다.
읽기 RPC는 명시 allowlist다.
pre-physics에서 staged/queued/frame·10ms·동일 physics generation을 검사하고 한 번 소비한다.
post-physics 검증 실패는 ambiguous latch로 남기며 다음 tick을 막는다. 수신/advance timeout은
조회로 대조하며 advance를 맹목적으로 재시도하지 않는다.

clock은 `m7-zero-probe-logical-frame`이며 bind 원점1s + frame차×10ms다. 원래 Actual
payload source time을 바꾸지 않고 전체 구간 age30ms/skew10ms·exclusive expiry를 검사한다.
서버 simulation begin/end는 별도로 기록한다. 이 진단 clock/합성 epoch는 실제8-role authority,
native wall deadline 또는 kernel clock mapping 증명이 아니다. 과거 sample을 재취득했다고
표시하지 않는다.

[M7-1l geometry 검증](../../../docs/test-plan/evidence/m7_carla_1l/README.md)은5개 INIT 자세에서
reference bone→body→COM→world→actor를 교차 검증했다. wheel resting center와 contact patch,
공개 `center_of_mass`(RPC에서 이미 m로 변환된 COMNudge)와 실제 PhysX COM pose를 구분한다.
식별한 기준점은 body에 고정된 nominal rear-axle **rest** 중심이며 suspension에 따라 움직이는
wheel center 측정이 아니다. 실제 유압 보정은 미검증이다. V1의 조향 부호는1m 격리 범위만 확인했다.

zero profile은 nonzero를 계속 거부한다. V1은 사용자가 수용한 가상 EV이며 OEM calibration이 아니다.
이상 Ackermann/후륜50:50 및 합산0.001Nm/Pa의4륜 균등 brake capacity다. 승인 pressure0..1.5MPa,
각375Nm이 geometry의800Nm 상한 이내인지 검사한다. setter가 상한을 자동 적용한다고 가정하지 않는다.
pre-physics에서 원래 Actual만 적용하고, post-physics에서 float32 setter readback을 정확히 대조한 뒤
12개 setter를 모두 지운다. receipt의 `inputs_cleared_after_physics`와 다음 describe로 제거를 확인한다.
`set_*`는 적용 demand readback이며 새 actuator Actual이나 실제 brake 반력이 아니다.
공개 `omega_rad_s`와 직접 `solver_omega_rad_s`를 clamp/abs/epsilon으로 보정하지 않는다.
이 fork의 공개 getter는 무구동 저속에서 보정값을 반환하므로 native 연결 후보는 source ID
`PhysX3.4.mWheelSpeeds.direct.v1`의 직접 solver 값을 사용해야 한다. `interval_work_valid=false`이며 endpoint
Tωdt, SOC/회생 수용이나 full Actual 주행을 주장하지 않는다. RGB/GT·AI·Jetson은 이 포트 시험
범위 밖이며 기존 영상50ms와 ECU 주기/freshness 계약은 그대로다.

빌드는 기존 환경에서 `BuildCarlaUE4.sh --build --no-simready`,
`make PythonAPI ARGS=--python-version=3.10`을 사용한다. 기존 Client와 바이너리를 백업하고
별도 venv에 새 wheel을 설치한다. 서버가 살아 있는 동안 module을 다시 링크하지 않는다.

합성 fixture는 저장소 root에서 다음처럼 빌드한다. 실제 vECU/Zone 반환을 대체하는 정상
입력 생성기가 아니다.

```bash
g++ -std=c++17 -O2 -Wall -Wextra -Werror \
  -Iinterfaces/common -Iinterfaces/steering -Iinterfaces/brake -Iinterfaces/drive \
  tests/integration/carla/m7_1k_fixture.cpp \
  interfaces/{common,steering,brake,drive}/*.cpp -o <external-fixture>
<extension-venv>/bin/python tests/integration/carla/m7_1k_server_probe.py \
  --fixture <external-fixture> --output <new-evidence-dir> \
  --expected-version 294096e-dirty
python3 tests/integration/carla/audit_m7_1k_server_probe.py \
  <new-evidence-dir>/result.json --output <new-audit.json>
```

M7-1n의 `-StrataM7V1Substeps20`은 V1 flag를 함께 요구하는 별도 수치 진단 옵션이다.
기본 asset3/1은 유지하고 후보만 low/high20/20을 설정한다. 실제 readback count/threshold와
`numerical_profile`을 binding/receipt에 남기며 pre/post20/20 검사를 수행한다.
world10ms/영상50ms/Drive30ms·actuator model·tire law는 바꾸지 않는다.
[대조](../../../docs/test-plan/evidence/m7_carla_1n/README.md)에서 rear 음수487→3frame이나
launch 첫 tick FAIL이 남아 정상 profile로 채택하지 않았다.

[M7-1o](../../../docs/test-plan/evidence/m7_carla_1o/README.md)는40/80의 실패도 보존하고
저속 tire 반력/명시적 wheel 적분의 진동을 계측했다. 동일 방식의 명시 옵션40/80/160/320/640을
추가하고 여러 count 동시 지정은 거부한다.320분할의 새2서버와 기존 response 모델 입력에서
각1,621frame의 직접 solver 음수0을 확인해 후속 격리 통합 후보로 사용한다. 기본 asset3/1과
정상 주행 비활성은 유지한다. 내부 tire callback은 읽기 전용·저속 관측이고 생략될 수 있으며
work coverage가 아니다. 앞바퀴 중간값의 미세 음수도 원본 그대로 보존한다.

`tests/integration/carla/m7_1o_run.py`는 기존 설치/venv/fixture를 받아 전용2200 포트의 새 서버를
실행하고 소유 프로세스만 종료한다.320 후보는 `--vehicle-substeps 320 --require-solver-wheel`,
response 입력은 추가 `--response-fixture <m7-1o-actuator-fixture>`다. 전체 인수와 실행 바이너리
hash는 evidence의 `server-*.json`에 남긴다. owner key는 자식 환경에만 생성하며 로그에 저장하지 않는다.


종료/보호 정지 후속은 [일괄 검증 근거](../../../docs/test-plan/evidence/m7_carla_recovery/batch-closeout/README.md)를 따른다.
`--held-steer-sleep`는 native+solver-work에만 허용하며, 동일한 보호 effort를 유지할 때
비영 steer만으로 자연 sleep이 해제되는 것을 막는다. 기본은 off다. module ABI2와 CARLA
`M7NoDriveWork.cpp`를 함께 설치/빌드해야 한다. ABI1 module은 새 서버에서 거부한다.

```bash
python3 tools/carla/m7_nodrive/install.py --carla <carla-source> --engine <UE4-root> --manifest <external-manifest>
# 실행 중인 UE4Editor가 없는 상태에서 CARLA module과 observer를 빌드한다.
# CARLA source root: UE4_ROOT=<UE4-root> bash Util/BuildTools/BuildCarlaUE4.sh --build --no-simready
python3 tools/carla/m7_nodrive/build_solver_observer.py --engine <UE4-root> --output <new-external-build> --install
python3 tests/integration/carla/m7_integrated_run.py \
  --engine <UE4-root> --source <carla-source> --python <venv-python> \
  --fixture <fixture> --native <m7-wheel-shadow> --runtime <new-runtime-dir> --output <new-output-dir> \
  --held-steer-sleep --cases client-loss protected-sleep camera-a client-loss-cameras loading-abort wall-gap zero disabled
```

runner는 각 case마다 새 서버를 띄우고 원래 종료30s/준비180s 한도를 유지한다.
`client-loss`는 실제 probe process를 exit73으로 끊으며 cleanup 없이 SIGINT 종료를 검사한다.
`protected-sleep`는400구간/정산 후 pause/reset/close와 새 INIT의 hold 이력 초기화도 확인한다.
`audit_m7_closeout.py`는 exact body/pose·sleep/work·종료 frame·원래 취득 clock bracket을 검사하며,
PASS는 요청된 한정 범위뿐이다. wall timing/clock agreement는 이 suite로 자동 수용되지 않는다.


`--compact-work`를 native solver-work runner/suite에 추가하면 원시 solver journal을 사용한다.
기본 모드는 불변이며 원본 observer ABI2도 그대로다. 이 변경은 CARLA module만 재설치·빌드한다.
정산에는 원래320개 rear mean을 쓰고, 독립 감사는 시험 종료 전 journal의 전체 원시 steps를
회수한 뒤 수행한다. 최대1024entry이며 runner는950tick 이하로 제한한다. buffer full/readback
실패는 FAIL이다. close/new bind 후 이전 journal을 복구하거나 crash-durable 기록을 보장하지 않는다.
`client-loss`와의 조합은 거부한다. [측정 결과·재현](../../../docs/test-plan/evidence/m7_carla_wall_guard/pipeline/README.md)을 따른다.

`m7_phase_probe`는 stationary synthetic wheel의 Controller/management 시작 위상을 조사하는
component 도구다. CARLA 실행이나 wall clock 수용이 아니며 정상 runner 기본14ms를 바꾸지 않는다.
