import subprocess,json
from pathlib import Path
folder=Path('build/supervised-recovery-delivery');results=[]
files=['central/planning/speed_supervisor.cpp','central/control_allocation/control_allocation.cpp','central/coordinator/vehicle_coordinator.cpp','central/diagnostics/control_diagnostics.cpp','central/diagnostics/epoch_recorder.cpp','central/diagnostics/diagnostics_delivery.cpp','interfaces/diagnostics/diagnostic_wire.cpp','simulation/runtime/speed_loop.cpp','simulation/runtime/m4_owner_network.cpp']
for i,name in enumerate(files):
 with (folder/f'tidy-{i}.log').open('w') as f: code=subprocess.run(['/usr/bin/clang-tidy','--quiet','-p','build/m1-angle',name],stdout=f,stderr=subprocess.STDOUT).returncode
 results.append(dict(path=name,exit=code,log=f'tidy-{i}.log'))
(folder/'tidy-results.json').write_text(json.dumps(results,indent=2)+'\n')
raise SystemExit(any(row['exit'] for row in results))
