from pathlib import Path
import os,subprocess,json
out=Path('build/supervised-recovery-delivery');root=Path('build/m1-angle-sanitized')
env=dict(os.environ,ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
results=[]
for name in ['speed_supervisor_test','control_recovery_sil_test','control_allocation_test','vehicle_coordinator_test','diagnostics_delivery_test','epoch_recorder_test','diagnostics_delivery_process_test','diagnostic_binding_test','m7_functional_test']:
 binary=root/name if name!='m7_functional_test' else root/'tests/integration/carla/m7_1f'/name
 args=[str(binary),'--gtest_output=xml:'+str(out/('asan-'+name+'.xml'))]
 if name=='m7_functional_test':args.append('--gtest_filter=M10NativeSpeed.*:M8CarlaSpeed.*:M8CarlaStop.*')
 with (out/('asan-'+name+'.log')).open('w') as f:code=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,env=env).returncode
 results.append(dict(target=name,exit=code))
 (out/'asan-results.json').write_text(json.dumps(results,indent=2)+'\n')
 if code:raise SystemExit(code)
