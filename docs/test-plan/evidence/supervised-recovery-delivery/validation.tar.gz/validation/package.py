from pathlib import Path
import subprocess,tarfile,hashlib,json,shutil,xml.etree.ElementTree as ET
root=Path('.').resolve();work=root/'build/supervised-recovery-delivery';out=root/'docs/test-plan/evidence/supervised-recovery-delivery'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def archive(target, paths):
 with tarfile.open(target,'w:gz') as tar:
  for path,arc in paths:tar.add(path,arcname=str(arc))
changed=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
sources=sorted(p for p in changed if not p.startswith('docs/') and (root/p).is_file())
meta=[dict(path=p,sha256=sha(root/p)) for p in sources]
(out/'sources.json').write_text(json.dumps(meta,indent=2)+'\n')
archive(out/'sources.tar.gz',[(root/p,p) for p in sources])
shutil.copyfile(work/'recovery-audit.json',out/'recovery-audit.json')
shutil.copyfile(work/'epoch-delivery-audit-final.json',out/'epoch-delivery-audit.json')
archive(out/'recovery.tar.gz',[(work/'recovery-evidence','recovery')])
archive(out/'someip-epoch.tar.gz',[(work/'someip-epoch','someip-epoch')])
logs=[(p,Path('validation')/p.name) for p in sorted(work.iterdir()) if p.is_file()]
for build in ['m1-angle','m1-angle-sanitized','m5-someip-normal/project']:
 for name in ['CMakeCache.txt','compile_commands.json']:
  p=root/'build'/build/name
  if p.exists():logs.append((p,Path('build-config')/build/name))
archive(out/'validation.tar.gz',logs)
xml=list(work.glob('asan-*.xml'));tests=sum(int(ET.parse(p).getroot().attrib['tests']) for p in xml)
assert tests==162 and all(int(ET.parse(p).getroot().attrib['failures'])==0 for p in xml)
assert all(row['exit']==0 for row in json.loads((work/'asan-results.json').read_text()))
binaries=['build/m1-angle/control_recovery_sil_test','build/m1-angle/diagnostics_delivery_test','build/m5-someip-normal/project/tests/integration/someip/someip_diagnostics_live']
acceptance=dict(passed=True,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 scope='logical supervised recovery/clear and opt-in event-only epoch SOME/IP delivery',
 debug=dict(full_pre_allocation_qualification=1524,final_recovery=5,additional_cold_reader=1,unique=1525,excluded_label='runtime.wall'),
 sanitized=dict(unique=tests,asan=True,ubsan=True,tsan=False),python_tests=280,clang_tidy_units=9,
 recovery=json.loads((out/'recovery-audit.json').read_text()),someip=json.loads((out/'epoch-delivery-audit.json').read_text()),
 binaries=[dict(path=p,sha256=sha(root/p)) for p in binaries],
 remaining=['multi-source ContextualOutbox/MergedCollector epoch ordering and migration','supervised recovery driving in CARLA','single-epoch rollover and disk lifecycle','whole ODD/wall/Target and trained model'])
(out/'acceptance.json').write_text(json.dumps(acceptance,indent=2)+'\n')
print(json.dumps(dict(source_files=len(meta),sanitized_tests=tests,artifacts=[dict(name=p.name,bytes=p.stat().st_size) for p in sorted(out.iterdir())]),indent=2))
