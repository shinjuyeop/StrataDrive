"""Fixed five local TCP peer deaths; OS behavior only, not native SDK acceptance."""
import subprocess,socket,sys,json,errno
from pathlib import Path
program='''import socket,sys,time
s=socket.socket();s.bind(("127.0.0.1",0));s.listen(1)
print(s.getsockname()[1],flush=True)
c,_=s.accept();print("accepted",flush=True)
time.sleep(30)
'''
rows=[]
for index in range(5):
 peer=subprocess.Popen([sys.executable,'-c',program],stdout=subprocess.PIPE,text=True)
 sock=socket.create_connection(('127.0.0.1',int(peer.stdout.readline())),timeout=1)
 assert peer.stdout.readline().strip()=='accepted'
 sock.sendall(b'original unconsumed payload');peer.kill();peer.wait(timeout=1)
 errors=[]
 for operation in ('recv','send'):
  try:
   if operation=='recv':sock.recv(1)
   else:sock.sendall(b'next payload')
  except OSError as exc:errors.append({'operation':operation,'errno':exc.errno,'name':errno.errorcode[exc.errno]})
 sock.close();rows.append({'index':index,'peer_exit':peer.returncode,'errors':errors})
 assert peer.returncode==-9 and [e['errno'] for e in errors]==[errno.ECONNRESET,errno.EPIPE]
report={'scope':'kernel demonstration only; original native verdicts unchanged','fixed_cases':5,'results':rows}
Path('build/m9-feedback-root/tcp-crash-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print('5/5: SIGKILL -> ECONNRESET on receive -> EPIPE on next send')
