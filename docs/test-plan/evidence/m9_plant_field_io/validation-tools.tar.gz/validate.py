from pathlib import Path
import json,subprocess
base=Path('build/m9-feedback-root');rows=[]
def run(name,cmd):
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for profile,d in [('normal','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 run(profile+'-configure',['cmake','-S','.','-B',d])
 command=['cmake','--build',d,'--parallel','2']
 if profile=='tsan':command+=['--target','vehicle_coordinator_test','normal_stop_test','m4_async_runtime_test','async_owner_test','owner_schedule_test','plant_io_test']
 run(profile+'-build',command)
 command=(['setarch','x86_64','-R']if profile=='tsan'else[])+['ctest','--test-dir',d,'--output-on-failure']
 if profile=='tsan':command+=['-R','Coordinator|NormalStop|M4Async|M4Refresh|OwnerSchedule|AsyncOwnerTest|AsyncZoneOwnerTest|PlantIOTest']
 run(profile+'-test',command)
for profile in ('normal','asan','tsan'):
 run(profile+'-adapter',['cmake','--build','build/m5-someip-'+profile+'/project','--target','someip_front_adapter','--parallel','2'])
