import sys,json,struct,csv
from pathlib import Path
from datetime import datetime,timezone,timedelta
sys.path.insert(0,'tests/integration/diagnostics')
from audit_native_routing import SOURCES,IPS,CLIENTS
from audit_someip_diagnostics import pcap
from audit_service_response import crc32c
root=Path('build/m9-grant-basis/service-campaign')
bindings={};clients={r:(c,c+1) if r=='central' else (c,) for r,c in CLIENTS.items()}
for z,role in enumerate(('front','rear')):
 bindings[0x5e01+2*z,0x101]=clients['central'];bindings[0x5e00+2*z,0x102]=clients[role]
for i,(_,role,_) in enumerate(SOURCES):
 bindings[0x5e11+2*i,0x101]=clients[role];bindings[0x5e10+2*i,0x102]=clients['central']
for sid,sender in [(0x5344,'central'),(0x5345,'central'),(0x5348,'central'),(0x5349,'central'),(0x5346,'front'),(0x5347,'front'),(0x534a,'rear'),(0x534b,'rear')]:
 for mid in (0x10,0x20,0x40,0x50,0x60,0x70,0x80):bindings[sid,mid]=clients[sender]
p=root/'normal-actual-loss/central-rejoin-1'
messages,_=pcap(p/'traffic.pcap',(*range(30501,30509),31610,31611,31612),tuple(IPS.values()),bindings)
rows=[]
for m in messages:
 b=m['payload']
 if m['method']!=0x70 or b[24:26]!=b'\x09\x01':continue
 assert crc32c(b[:-4])==int.from_bytes(b[-4:],'little')
 assert struct.unpack_from('<I',b,26)[0]==0x281
 a=b[33:65];seq,epoch,ns,causal,state,origin=struct.unpack_from('<IIQIBB',a,4)
 if epoch==3 and 830400780000000<ns<830400840000000:
  rows.append(dict(seq=seq,epoch=epoch,source=ns,causal=causal,state=state,origin=origin,valid=a[3],pressure_raw=int.from_bytes(a[:2],'little'),crc=crc32c(b[:-4])))
print('BRAKE',json.dumps(rows,indent=2))
errors=[]
for case in ('asan-normal','asan-stop-request-loss','asan-normal-slow-signals'):
 p=root/case/'central-rejoin-1';r=json.loads((p/'result.json').read_text());s=r['clock_sample']
 for e in r['unexpected_sdk_errors']:
  stamp=datetime.strptime(e['text'][:26],'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=timezone(timedelta(seconds=s['utc_offset_s'])))
  ns=int(stamp.timestamp()*1e9)-s['wall_ns']+s['monotonic_ns']
  errors.append(dict(case=case,file=e['file'],ns=ns,crash_ns=r['injected_crash']['ns'],after_crash_ns=ns-r['injected_crash']['ns'],line=e['text']))
print('ERRORS',json.dumps(errors,indent=2))
Path('build/m9-feedback-root/original-analysis.json').write_text(json.dumps(dict(brake=rows,sdk=errors),indent=2)+'\n')
