from pathlib import Path
import json,subprocess,time
base=Path('build/m9-feedback-root');rows=[]
def run(name,cmd):
 (base/'phase.json').write_text(json.dumps({'phase':name,'time_ns':time.monotonic_ns()})+'\n')
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'phase':name,'command':cmd,'exit':r.returncode});(base/'continued-validation.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode and name!='native-cohorts':raise SystemExit(r.returncode)
for profile in ('normal','asan','tsan'):
 run(profile+'-adapter',['cmake','--build','build/m5-someip-'+profile+'/project','--target','someip_front_adapter','--parallel','2'])
for phase,script in [('remaining-checks','remaining-checks.py'),('source-snapshot','snapshot.py'),('native-cohorts','run-cohorts.py')]:run(phase,['python3',str(base/script)])
(base/'phase.json').write_text(json.dumps({'phase':'complete-with-original-tsan-wall-failure'})+'\n')
