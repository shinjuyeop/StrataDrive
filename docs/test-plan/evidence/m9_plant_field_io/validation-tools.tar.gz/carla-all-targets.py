from pathlib import Path
import subprocess,json,re
base=Path('build/m9-feedback-root');rows=[]
for part,name in [('m7_1c','m7_plant_contract_test'),('m7_1i','m7_effort_contract_test'),('m7_1f','m7_functional_test'),('m7_1g','m7_wheel_test'),('m7_1h','m7_external_test'),('m7_1q','m7_native_admission_test')]:
 cmd=[str(Path('build/m7-functional/tests/integration/carla')/part/name)]
 p=base/(name+'.log')
 with p.open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 text=p.read_text();counts=re.findall(r'\[==========\] (\d+) tests? from',text);assert counts and int(counts[0])>0
 rows.append({'name':name,'command':cmd,'exit':r.returncode,'tests':int(counts[0])})
 (base/'carla-all-targets.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,counts[0],flush=True)
 if r.returncode:raise SystemExit(r.returncode)
