from pathlib import Path
import csv, hashlib, json, struct, sys
sys.path.insert(0,'tests/integration/diagnostics')
from audit_someip_diagnostics import pcap
from audit_service_response import crc32c

base=Path(__file__).resolve().parent
def rows(path):
    with path.open() as f:return list(csv.DictReader(f))

summary={}
for cohort in ('cohort-1','compare-io'):
    data=[]
    for row in json.loads((base/cohort/'results.json').read_text()):
        analysis=json.loads((base/'analysis-final'/(cohort+'-'+row['name']+'.json')).read_text())
        root=base/cohort/row['name']/'central-rejoin-1';runtime=json.loads((root/'result.json').read_text())
        version='sdk-tsan-v2' if cohort=='cohort-1' else 'sdk-tsan-v3'
        loaded={role:str(base/version/'install/lib/libvsomeip3.so.3.7.6') in (root/(role+'.maps')).read_text() for role in ('central','front','rear')}
        assert all(loaded.values())
        data.append({'name':row['name'],'sdk_io_threads':row.get('sdk_io_threads',2),
            'service_qualified':not any(row[k] for k in ('service_exit','ordering_exit','timing_exit','response_exit')),
            'kernel_calibration_qualified':analysis['observation_complete'],'calibration':analysis['calibration'],
            'sdk_loaded_from_isolated_build':loaded,'complete_chains':analysis['complete_receive_chains'],
            'partial_chains':analysis['partial_receive_chains'],'normal_chains':analysis['normal_chains'],
            'normal_maxima':analysis['normal_maxima'],'first_faults':analysis['first_faults'],
            'unexpected_sdk_errors':runtime['unexpected_sdk_errors'],'sanitizer_diagnostics':runtime['sanitizer_diagnostics']})
    summary[cohort]=data
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

def p05(data):
    crc=0xffff
    for i,b in enumerate(data+b'\x02\x13'):
        if i in (29,30):continue
        crc^=b<<8
        for _ in range(8):crc=((crc<<1)^(0x1021 if crc&0x8000 else 0))&0xffff
    return crc

failure=[]
for repeat in (1,4):
    root=base/'compare-io'/f'tsan-stop-ack-loss-r{repeat}'/'central-rejoin-1'
    control=rows(root/'central-2-service.transport.csv')
    faults=[r for r in rows(root/'central-2-service.events.csv') if r['event']=='central-fault'];at=int(faults[0]['ns'])
    item={'case':root.parent.name,'first_fault':faults[0],'renewals':[]}
    for role in ('front','rear'):
        trace=rows(root/(role+'-1.transport.csv'));accepted=[r for r in trace if r['event']=='zone-result-enqueued' and r['operation']=='3' and r['decision']=='1']
        for r in [r for r in trace if r['event']=='zone-received' and r['operation']=='3' and at-25000000<int(r['ns'])<at][-2:]:
            previous=[q for q in accepted if int(q['ns'])<int(r['ns'])][-1]
            item['renewals'].append({'role':role,'received':r,'previous_success':previous,
                'send_to_receive_ns':int(r['ns'])-int(r['sent']),
                'arrival_after_previous_expiry_ns':int(r['ns'])-int(previous['inner_deadline'])})
    readiness=[r for r in control if r['event']=='allocation-readiness' and r['decision']=='3' and at-25000000<int(r['ns'])<at]
    first=readiness[0];grant=next(r for r in control if r['event']=='permission-issued' and r['peer']==first['peer'])
    item.update(short_support=first,grant=grant,permission_limit=next(r for r in control if r['event']=='permission-limit' and r['peer']==first['peer']),
                support_shortfall_ns=int(first['sent'])+18000000-int(first['inner_deadline']))
    packets,_=pcap(root/'traffic.pcap',tuple(range(30501,30509)),tuple(bytes([10,88,0,n])for n in (1,2,3)),
                   {(s,m):(0x1311,0x1312,0x1422,0x1522)for s in range(0x5344,0x534c)for m in (16,32,64,80,96,112,128)})
    status=[]
    for packet in packets:
        raw=packet['payload']
        if len(raw)!=101 or raw[24:26]!=bytes([9,3]) or int.from_bytes(raw[26:30],'little')!=0x283:continue
        data=raw[33:97];source=int.from_bytes(data[12:20],'little')
        if not at-40000000<source<at:continue
        crc=int.from_bytes(raw[-4:],'little');assert crc32c(raw[:-4])==crc and p05(data)==int.from_bytes(data[29:31],'little')
        status.append({'source_ns':source,'sequence':int.from_bytes(data[4:8],'little'),
                       'causal_sequence':int.from_bytes(data[20:24],'little'),'accepted_request_source_ns':int.from_bytes(data[52:60],'little'),
                       'crc':crc,'payload_sha256':hashlib.sha256(raw).hexdigest(),'p05_crc_ok':True,
                       'api':[{**r,'file':p.name}for p in root.glob('*.sdk-api.csv')for r in rows(p) if r['method']=='112' and r['crc']==str(crc)],
                       'internal':[{**r,'file':p.name}for p in root.glob('*.sdk-internal.csv')for r in rows(p) if r['method']=='112' and r['crc']==str(crc)]})
    item['nearby_power_status']=status
    item['input_snapshot_cut_time_recorded']=False
    failure.append(item)
(base/'renewal-correlation.json').write_text(json.dumps(failure,indent=2)+'\n')
for cohort,data in summary.items():
    print(cohort, 'service',sum(r['service_qualified']for r in data),'/',len(data),'kernel quality',sum(r['kernel_calibration_qualified']for r in data))
for r in failure:print(r['case'],'support shortfall',r['support_shortfall_ns'],[(x['role'],x['send_to_receive_ns'],x['arrival_after_previous_expiry_ns'])for x in r['renewals']])
