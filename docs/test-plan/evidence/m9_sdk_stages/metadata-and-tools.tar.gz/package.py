from pathlib import Path
import hashlib, json, subprocess, tarfile, platform

root=Path.cwd();base=root/'build/m9-sdk-stages';dest=root/'docs/test-plan/evidence/m9_sdk_stages'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
validation=[]
for name,command in [('python-bookkeeping',['python3','tests/unit/someip_pilot_test.py']),
                     ('python-stages',['python3','tests/unit/sdk_stages_test.py']),
                     ('python-compile',['python3','-m','py_compile',*[str(p)for p in (root/'tests/integration/someip').glob('*.py')],
                                        'tests/integration/diagnostics/audit_sdk_stages.py','tests/integration/diagnostics/audit_service_timing.py'])]:
    with (base/(name+'-final.txt')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    validation.append({'name':name,'command':command,'exit':r.returncode})
    assert r.returncode==0,name
validation.extend(json.loads((base/'static-compatible-v2/results.json').read_text()))
validation.append({'name':'helper-cppcheck','exit':0,'log':'helper-cppcheck.txt'})
validation.append({'name':'SDK-cppcheck-baseline-comparison','report':'cppcheck-comparison.json',
                   'new_diagnostics':json.loads((base/'cppcheck-comparison.json').read_text())['new_diagnostics']})
(dest/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
sources=sorted(set([*root.glob('tests/integration/someip/*.py'),*root.glob('tests/integration/diagnostics/*.py'),
    root/'tests/integration/someip/sdk_observation.hpp',root/'tests/unit/sdk_stages_test.py',root/'tests/unit/someip_pilot_test.py',
    root/'interfaces/common/concurrent_trace_buffer.hpp',root/'docs/test-plan/sdk-stages-protocol.md',root/'docs/test-plan/sdk-io-threads-protocol.md']))
manifest={str(p.relative_to(root)):digest(p)for p in sources}
(dest/'source-final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(dest/'source-final.tar.gz','w:gz') as archive:
    for path in sources:archive.add(path,arcname=str(path.relative_to(root)))
identity={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'platform':platform.platform(),
          'python':platform.python_version(),'original_sdk_clean':not subprocess.check_output(['git','-C','build/m5-someip-deps/vsomeip','status','--porcelain']),
          'original_sdk_pin':subprocess.check_output(['git','-C','build/m5-someip-deps/vsomeip','rev-parse','HEAD'],text=True).strip(),
          'observation_builds':{},'production_binaries':{}}
for version in ('sdk-tsan-v2','sdk-tsan-v3'):
    sdk=base/version;m=json.loads((sdk/'manifest.json').read_text())
    assert digest(sdk/'sdk_observation.hpp')==m['helper_sha256']
    assert all(digest(Path(p))==sha for p,sha in m['libraries'].items())
    identity['observation_builds'][version]={'manifest':m,'libraries_still_match':True,'helper_snapshot_matches':True}
for profile in ('normal','asan','tsan'):
    binary=root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter'
    identity['production_binaries'][profile]=digest(binary)
assert identity['production_binaries']['tsan']==json.loads((base/'cohort-1/manifest.json').read_text())['binary_sha256']
assert identity['original_sdk_clean']
(dest/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
for filename in ('summary.json','renewal-correlation.json','analysis-final-results.json'):
    (dest/filename).write_bytes((base/filename).read_bytes())
for cohort in ('cohort-1','compare-io'):
    for case in json.loads((base/cohort/'results.json').read_text()):
        path=base/cohort/case['name'];output=dest/(cohort+'-'+case['name']+'.tar.gz')
        with tarfile.open(output,'w:gz') as archive:archive.add(path,arcname=cohort+'/'+case['name'])
        print(output.name,output.stat().st_size,flush=True)
metadata=set(p for p in base.iterdir() if p.is_file())
for folder in ('analysis-final','static-compatible','static-compatible-v2','cppcheck-instrumented','cppcheck-baseline','cohort-1','compare-io'):
    metadata.update(p for p in (base/folder).iterdir() if p.is_file())
for version in ('sdk-tsan','sdk-tsan-v2','sdk-tsan-v3'):
    sdk=base/version;metadata.update(p for p in sdk.iterdir() if p.is_file())
    metadata.update(p for p in (sdk/'sdk').glob('*') if p.name in ('CMakeCache.txt','compile_commands.json'))
with tarfile.open(dest/'metadata-and-tools.tar.gz','w:gz') as archive:
    for path in sorted(metadata):archive.add(path,arcname=str(path.relative_to(base)))
assert all(p.stat().st_size<50*1024*1024 for p in dest.iterdir() if p.is_file())
print('packaged',sum(p.stat().st_size for p in dest.iterdir() if p.is_file()),flush=True)
