from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import tempfile

root=Path.cwd();dest=root/'docs/test-plan/evidence/m9_sdk_stages'
logs=root/'build/m9-sdk-stages/archive-reaudit';logs.mkdir(exist_ok=True)
cases=[('cohort-1','tsan-ack-loss-r1',0,0),
       ('compare-io','tsan-stop-ack-loss-r1',1,0),
       ('compare-io','tsan-ack-loss-r2',0,1),
       ('compare-io','tsan-stop-ack-loss-r3',1,1)]
rows=[]
def extract(path,folder):
    with tarfile.open(path) as archive:
        for member in archive.getmembers():
            assert not member.issym() and not member.islnk(),member.name
            assert (folder/member.name).resolve().is_relative_to(folder),member.name
        archive.extractall(folder)

with tempfile.TemporaryDirectory(prefix='stratadrive-sdk-reaudit-') as tmp:
    folder=Path(tmp)
    extract(dest/'source-final.tar.gz',folder)
    manifest=json.loads((dest/'source-final-manifest.json').read_text())
    for path,digest in manifest.items():
        assert hashlib.sha256((folder/path).read_bytes()).hexdigest()==digest,path
        assert hashlib.sha256((root/path).read_bytes()).hexdigest()==digest,path
    for cohort,name,service,stages in cases:
        archive=dest/f'{cohort}-{name}.tar.gz';extract(archive,folder)
        run=folder/cohort/name/'central-rejoin-1'
        for tag,script,expected in [('service','audit_native_service_faults.py',service),
                                    ('stages','audit_sdk_stages.py',stages),
                                    ('timing','audit_service_timing.py',0)]:
            command=['python3',str(folder/'tests/integration/diagnostics'/script),str(run)]
            if tag!='stages':command.append('--mutations')
            log=logs/f'{cohort}-{name}.{tag}.txt'
            with log.open('w') as output:
                result=subprocess.run(command,stdout=output,stderr=subprocess.STDOUT)
            row={'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
                 'audit':tag,'command':command,'expected_exit':expected,'actual_exit':result.returncode,
                 'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
            if tag=='stages':
                report=json.loads(log.read_text())
                row['observation_complete']=report['observation_complete']
                assert report['observation_complete']==(stages==0)
                original=json.loads((root/'build/m9-sdk-stages/analysis-final'/f'{cohort}-{name}.json').read_text())
                for key in ('complete_receive_chains','partial_receive_chains','normal_maxima','normal_windows','calibration'):
                    assert report[key]==original[key],(name,key)
                row['matches_final_report']=True
            elif expected:
                assert 'ValueError:' in log.read_text(),row
                # The same strict service failure must survive archive extraction.
                original=(root/'build/m9-sdk-stages'/cohort/(name+'.service.txt')).read_text()
                assert log.read_text().strip().splitlines()[-1]==original.strip().splitlines()[-1],name
                row['same_failure_reason']=True
            rows.append(row)
            (dest/'archive-reaudit.json').write_text(json.dumps({'source_files_verified':len(manifest),'checks':rows},indent=2)+'\n')
            print(cohort,name,tag,result.returncode,'expected',expected,flush=True)
            assert result.returncode==expected,row
with tarfile.open(dest/'archive-reaudit.tar.gz','w:gz') as archive:
    archive.add(Path(__file__),arcname='archive_reaudit.py')
    for path in sorted(logs.iterdir()):archive.add(path,arcname=path.name)
print('archive checks complete',len(rows),flush=True)
