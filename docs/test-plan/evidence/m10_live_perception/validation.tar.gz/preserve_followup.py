from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path.cwd();work=root/'build/m10-followup';dest=root/'docs/test-plan/evidence/m10_live_perception'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def archive(name,paths):
 with tarfile.open(dest/name,'w:gz',compresslevel=6) as tar:
  for path,arcname in paths:tar.add(path,arcname=arcname)
assert '100% tests passed, 0 tests failed out of 1459' in (work/'core-final.log').read_text()
for name in ['release','asan']:
 assert '100% tests passed, 0 tests failed out of 13' in (work/f'{name}-final.log').read_text()
assert 'Ran 55 tests' in (work/'unit-final.log').read_text() and '\nOK\n' in (work/'unit-final.log').read_text()
assert 'All checks passed!' in (work/'ruff-final.log').read_text()
assert len((work/'baseline-integrity.log').read_text().splitlines())==31
summary={'technical_status':'PASS_DECLARED_STARTUP_LIVE_CAMERA_BOUNDARIES','milestone_acceptance':'M10_OPEN','core_regression':{'passed':1459,'excluded':'runtime.wall; M7 opt-in suites not configured'},'component_ctest':{'Release':13,'ASan_UBSan':13,'Python_cases':55,'live_audit_mutations':21},'quality_acceptance':'NOT_SET','full_wall20hz_acceptance':'OPEN','native_vehicle_metric_fusion_M11_M12':'NOT_RUN','live':{},'stream':{},'renderer':{},'all_server_attempts':{}}
(dest/'live').mkdir();(dest/'stream').mkdir();(dest/'renderer').mkdir();(dest/'bin').mkdir()
for path in sorted(work.glob('rgb-*/dataset/live.json')):
 run=path.parent.parent; r=json.loads(path.read_text());server=json.loads((run/'server.json').read_text());audit=json.loads((run/'audit.json').read_text())
 assert r['status']==server['status']==audit['status']=='PASS' and server['server_exit']==130
 assert audit['live_sha256']==sha(path) and audit['server_sha256']==sha(run/'server.json')
 summary['live'][run.name]={k:r[k] for k in ('fault','requested_camera_frames','actual_camera_hz','receipt_to_completion','camera_callback_intervals','preparation','model_initialization_wall_ns','unique_consumed','boundary')}
 summary['live'][run.name]['counters']=r['worker']['counters']
 shutil.copy2(path,dest/'live'/f'{run.name}.json');shutil.copy2(run/'audit.json',dest/'live'/f'{run.name}-audit.json')
for run in sorted(work.glob('stream-*-prepared')):
 r=json.loads((run/'stream.json').read_text());assert r['status']=='PASS' and r['closed']
 summary['stream'][run.name]={'counters':r['worker']['counters'],'latency':r['submit_to_backend_completion'],'preparation':r['preparation'],'model_initialization_wall_ns':r['model_initialization_wall_ns']}
 shutil.copy2(run/'stream.json',dest/'stream'/f'{run.name}.json')
for kind in ('low','epic'):
 evaluation=work/f'renderer-{kind}-evaluation.json';e=json.loads(evaluation.read_text());r=json.loads((work/f'renderer-{kind}-inference/result.json').read_text())
 assert e['audit']=='PASS' and r['status']=='PASS'
 totals={key:sum(row[key] for row in e['raw_model'].values()) for key in ('tp','fp','fn')}
 totals['precision']=totals['tp']/(totals['tp']+totals['fp']);totals['recall']=totals['tp']/(totals['tp']+totals['fn'])
 summary['renderer'][kind]={'totals':totals,'scenes':e['scenes'],'model_valid':e['model_valid'],'admitted':e['admitted'],'late':e['late']}
 shutil.copy2(evaluation,dest/'renderer'/f'{kind}-evaluation.json');shutil.copy2(work/f'renderer-{kind}-inference/result.json',dest/'renderer'/f'{kind}-inference.json');shutil.copy2(work/f'renderer-{kind}-overview.png',dest/f'renderer-{kind}-overview.png')
for p in sorted(work.glob('*/server.json')):
 s=json.loads(p.read_text());summary['all_server_attempts'][p.parent.name]={k:s[k] for k in ('status','server_exit','elapsed_wall_seconds')}
 if s.get('forced_stop'):summary['all_server_attempts'][p.parent.name]['forced_stop']=True
write(dest/'acceptance.json',summary)
shutil.copy2(work/'environment.json',dest/'environment.json')
shutil.copy2(root/'build/m10-perception/release/tests/integration/perception/perception_replay',dest/'bin/perception_replay')
live_dirs=sorted(p for p in work.iterdir() if p.is_dir() and (p/'dataset/live.json').exists())
archive('live-runs.tar.gz',[(p,p.name) for p in live_dirs])
renderer_dirs=[work/f'renderer-{k}{suffix}' for k in ('low','epic') for suffix in ('','-dataset','-inference')]
archive('renderer-inputs.tar.gz',[(p,p.name) for p in renderer_dirs])
# Every executed runtime version is retained by content hash, including superseded files.
versions=work/'source-versions'
for p in list((root/'physical_ai/perception').glob('*.py'))+list((root/'profiles').glob('perception-*.json')):
 (versions/sha(p)).write_bytes(p.read_bytes())
coverage={}
reports=list(work.glob('*/dataset/live.json'))+list(work.glob('*/stream.json'))+list(work.glob('renderer-*-inference/result.json'))
for p in reports:
 r=json.loads(p.read_text());mapping=r['runtime']['source_files_sha256']
 for source,digest in mapping.items():assert (versions/digest).exists() and sha(versions/digest)==digest,(p,source,digest)
 coverage[str(p.relative_to(work))]=mapping
write(dest/'execution-source-coverage.json',{'status':'PASS','reports':coverage})
archive('source-versions.tar.gz',[(p,p.name) for p in sorted(versions.iterdir())])
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
paths=[root/p for p in sorted(set(changed+new)) if not p.startswith('docs/test-plan/evidence/') and (root/p).is_file()]
write(dest/'sources.json',{'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'date':'2026-11-06','files':{str(p.relative_to(root)):sha(p) for p in paths}})
archive('sources.tar.gz',[(p,str(p.relative_to(root))) for p in paths])
validation=[p for p in work.iterdir() if p.is_file() and p.suffix in ('.log','.txt','.json','.py') and p.name not in ('preserve.log',)]
archive('validation.tar.gz',[(p,p.name) for p in sorted(validation)])
print(json.dumps({'sources':len(paths),'runtime_reports':len(coverage),'archives':{p.name:p.stat().st_size for p in dest.glob('*.tar.gz')}},indent=2))
