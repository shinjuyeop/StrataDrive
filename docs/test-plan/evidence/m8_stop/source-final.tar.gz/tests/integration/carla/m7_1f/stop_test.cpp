#include "functional_rig.hpp"
#include "native_admission.hpp"
#include <gtest/gtest.h>
namespace {
using namespace stratadrive;
using namespace m7_functional;
TEST(M8CarlaStop, SameOwnersSelectTerminalHoldOrProtectionWithOriginalProof) {
    for(auto mode:{SpeedTerminal::NormalStop,SpeedTerminal::SpeedInputLoss}) {
        FunctionalRig rig({1,42,7},99,PlantMode::ExternalSolverWork,true,60000);rig.speed_profile(mode);
        EXPECT_THROW(rig.speed_profile(SpeedTerminal::None),std::runtime_error);
        EXPECT_THROW(rig.speed_profile(static_cast<SpeedTerminal>(99)),std::runtime_error);
        std::unique_ptr<m7_native::Admission> admission;
        m7_native::Output prior;Time previous=0;bool held=false,protected_actual=false,complete=false,corrupted=false;
        for(unsigned i=0;i<=2300;++i) {
            const double seconds=3.997146773152053+i*.009999999776482582;
            const auto now=static_cast<Time>(std::llround(seconds*1e9));
            Observation o{{1,42,7},domain,100+i,seconds,.01};WheelSample wheel{99,100+i,now,{0,0,0,0}};
            m7_external::SolverWork work;work.frame=100+i;work.begin=previous;work.end=now;
            work.oldest=prior.empty?previous:prior.oldest_actuator;work.torque=prior.torque;
            work.dt=double(.01f*(1.f/320.f));work.wheel={0,{7,99+i,previous},previous};
            Report r;
            ASSERT_NO_THROW(r=i?rig.observe(o,wheel,work):rig.observe(o,wheel))<<"frame="<<i<<" mode="<<static_cast<int>(mode);
            EXPECT_EQ(r.terminal_mode,mode);
            const auto& e=*r.native_export;m7_native::Input in;
            in.observed=e.observed;in.enable=e.enable;in.normal=e.normal;in.actual=e.actual;in.commands=e.commands;
            in.stop_requests=e.stop_requests;in.stop_results=e.stop_results;
            in.release=e.release;in.credit=e.credit;in.permission=e.permission;
            in.protection_since=e.protection_since;in.protection_selected_mask=e.protection_selected_mask;
            in.service_mask=r.service_mask;in.credit_mask=r.credit_mask;in.release_mask=r.release_mask;
            if(!admission)admission=std::make_unique<m7_native::Admission>(42,now);
            if(!in.normal && in.stop_requests[0] && !corrupted) {
                for(unsigned fault=0;fault<8;++fault) {
                    auto bad=in;m7_native::Output unused;
                    if(fault==0)bad.stop_results[1].reset();
                    if(fault==1)bad.stop_requests[2].reset();
                    if(fault==2)bad.credit_mask=0;
                    if(fault==3)bad.protection_since=now;
                    if(fault>=4 && fault<=6) {
                        auto m=remote::decode_owner_message(bad.stop_requests[0]->bytes.data(),bad.stop_requests[0]->size);
                        auto& q=std::get<transport::LeafRequest>(m->payload);
                        if(fault==4)q.lease->expires_at_ns=now+10*ms;
                        if(fault==5)q.lease->epoch=41;
                        if(fault==6)q.lease->sequence+=1;
                        bad.stop_requests[0]=remote::encode_owner_message(*m);
                    }
                    if(fault==7) {
                        auto m=remote::decode_owner_message(bad.stop_results[0]->bytes.data(),bad.stop_results[0]->size);
                        std::get<transport::LeafResult>(std::get<transport::LeafReport>(m->payload)).accepted=false;
                        bad.stop_results[0]=remote::encode_owner_message(*m);
                    }
                    EXPECT_FALSE(admission->eligible(bad,now,unused))<<"fault="<<fault;
                }
                corrupted=true;
            }
            if(held) {auto resume=in;resume.normal=true;resume.stop_requests={};resume.stop_results={};m7_native::Output unused;
                EXPECT_FALSE(admission->eligible(resume,now,unused));}
            ASSERT_TRUE(admission->accept(in,now,prior))<<admission->error()<<" frame="<<i<<" stop="<<static_cast<int>(r.stop_state);
            held|=prior.normal_stop;protected_actual|=prior.protection;
            complete|=r.stop_state==central::NormalStopState::Complete && r.power_off;
            previous=now;
        }
        EXPECT_EQ(held,mode==SpeedTerminal::NormalStop);EXPECT_EQ(complete,mode==SpeedTerminal::NormalStop);
        EXPECT_EQ(protected_actual,mode==SpeedTerminal::SpeedInputLoss);
    }
}
}
