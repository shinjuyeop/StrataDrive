
build/m4-sdk-followup/dds-official/install/lib/libddsc.so.11:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

00000000000c6500 <ddsi_writer_clear_retransmitting>:
   c6500:	f3 0f 1e fa          	endbr64 
   c6504:	55                   	push   %rbp
   c6505:	48 89 e5             	mov    %rsp,%rbp
   c6508:	41 54                	push   %r12
   c650a:	53                   	push   %rbx
   c650b:	48 83 ec 10          	sub    $0x10,%rsp
   c650f:	48 89 7d e8          	mov    %rdi,-0x18(%rbp)
   c6513:	48 8b 45 08          	mov    0x8(%rbp),%rax
   c6517:	48 89 c7             	mov    %rax,%rdi
   c651a:	e8 81 15 f6 ff       	call   27aa0 <__tsan_func_entry@plt>
   c651f:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c6523:	48 05 7c 01 00 00    	add    $0x17c,%rax
   c6529:	48 89 c7             	mov    %rax,%rdi
   c652c:	e8 bf 15 f6 ff       	call   27af0 <__tsan_write2@plt>
   c6531:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c6535:	0f b6 90 7c 01 00 00 	movzbl 0x17c(%rax),%edx
   c653c:	83 e2 f7             	and    $0xfffffff7,%edx
   c653f:	88 90 7c 01 00 00    	mov    %dl,0x17c(%rax)
   c6545:	48 8b 5d e8          	mov    -0x18(%rbp),%rbx
   c6549:	e8 12 0f f6 ff       	call   27460 <ddsrt_time_elapsed@plt>
   c654e:	48 89 83 c8 01 00 00 	mov    %rax,0x1c8(%rbx)
   c6555:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c6559:	48 05 d0 01 00 00    	add    $0x1d0,%rax
   c655f:	48 89 c7             	mov    %rax,%rdi
   c6562:	e8 79 1f f6 ff       	call   284e0 <__tsan_write8@plt>
   c6567:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c656b:	48 05 c8 01 00 00    	add    $0x1c8,%rax
   c6571:	48 89 c7             	mov    %rax,%rdi
   c6574:	e8 87 1e f6 ff       	call   28400 <__tsan_read8@plt>
   c6579:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c657d:	48 8b 55 e8          	mov    -0x18(%rbp),%rdx
   c6581:	48 8b 92 c8 01 00 00 	mov    0x1c8(%rdx),%rdx
   c6588:	48 89 90 d0 01 00 00 	mov    %rdx,0x1d0(%rax)
   c658f:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c6593:	48 05 38 02 00 00    	add    $0x238,%rax
   c6599:	48 89 c7             	mov    %rax,%rdi
   c659c:	e8 5f 1e f6 ff       	call   28400 <__tsan_read8@plt>
   c65a1:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c65a5:	4c 8b a0 38 02 00 00 	mov    0x238(%rax),%r12
   c65ac:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c65b0:	48 05 c8 01 00 00    	add    $0x1c8,%rax
   c65b6:	48 89 c7             	mov    %rax,%rdi
   c65b9:	e8 42 1e f6 ff       	call   28400 <__tsan_read8@plt>
   c65be:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c65c2:	48 8b 98 c8 01 00 00 	mov    0x1c8(%rax),%rbx
   c65c9:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c65cd:	48 05 c0 01 00 00    	add    $0x1c0,%rax
   c65d3:	48 89 c7             	mov    %rax,%rdi
   c65d6:	e8 25 1e f6 ff       	call   28400 <__tsan_read8@plt>
   c65db:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c65df:	48 8b 90 c0 01 00 00 	mov    0x1c0(%rax),%rdx
   c65e6:	48 89 d8             	mov    %rbx,%rax
   c65e9:	48 29 d0             	sub    %rdx,%rax
   c65ec:	49 8d 1c 04          	lea    (%r12,%rax,1),%rbx
   c65f0:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c65f4:	48 05 38 02 00 00    	add    $0x238,%rax
   c65fa:	48 89 c7             	mov    %rax,%rdi
   c65fd:	e8 de 1e f6 ff       	call   284e0 <__tsan_write8@plt>
   c6602:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c6606:	48 89 98 38 02 00 00 	mov    %rbx,0x238(%rax)
   c660d:	48 8b 45 e8          	mov    -0x18(%rbp),%rax
   c6611:	48 05 f0 00 00 00    	add    $0xf0,%rax
   c6617:	48 89 c7             	mov    %rax,%rdi
   c661a:	e8 61 0d f6 ff       	call   27380 <ddsrt_cond_mtime_broadcast@plt>
   c661f:	e8 3c 28 f6 ff       	call   28e60 <__tsan_func_exit@plt>
   c6624:	90                   	nop
   c6625:	48 83 c4 10          	add    $0x10,%rsp
   c6629:	5b                   	pop    %rbx
   c662a:	41 5c                	pop    %r12
   c662c:	5d                   	pop    %rbp
   c662d:	c3                   	ret    

Disassembly of section .fini:
