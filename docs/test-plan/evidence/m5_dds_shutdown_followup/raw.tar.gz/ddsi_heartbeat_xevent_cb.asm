
build/m4-sdk-followup/dds-official/install/lib/libddsc.so.11:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .plt.got:

Disassembly of section .plt.sec:

Disassembly of section .text:

0000000000130dbf <ddsi_heartbeat_xevent_cb>:
  130dbf:	f3 0f 1e fa          	endbr64 
  130dc3:	55                   	push   %rbp
  130dc4:	48 89 e5             	mov    %rsp,%rbp
  130dc7:	41 57                	push   %r15
  130dc9:	41 56                	push   %r14
  130dcb:	41 55                	push   %r13
  130dcd:	41 54                	push   %r12
  130dcf:	53                   	push   %rbx
  130dd0:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
  130dd7:	48 89 bd 78 ff ff ff 	mov    %rdi,-0x88(%rbp)
  130dde:	48 89 b5 70 ff ff ff 	mov    %rsi,-0x90(%rbp)
  130de5:	48 89 95 68 ff ff ff 	mov    %rdx,-0x98(%rbp)
  130dec:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
  130df3:	4c 89 85 58 ff ff ff 	mov    %r8,-0xa8(%rbp)
  130dfa:	64 48 8b 04 25 28 00 	mov    %fs:0x28,%rax
  130e01:	00 00 
  130e03:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
  130e07:	31 c0                	xor    %eax,%eax
  130e09:	48 8b 45 08          	mov    0x8(%rbp),%rax
  130e0d:	48 89 c7             	mov    %rax,%rdi
  130e10:	e8 8b 6c ef ff       	call   27aa0 <__tsan_func_entry@plt>
  130e15:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
  130e1c:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
  130e20:	48 8b 5d a0          	mov    -0x60(%rbp),%rbx
  130e24:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  130e2b:	48 05 00 04 00 00    	add    $0x400,%rax
  130e31:	48 89 c7             	mov    %rax,%rdi
  130e34:	e8 c7 75 ef ff       	call   28400 <__tsan_read8@plt>
  130e39:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  130e40:	48 8b 80 00 04 00 00 	mov    0x400(%rax),%rax
  130e47:	48 89 de             	mov    %rbx,%rsi
  130e4a:	48 89 c7             	mov    %rax,%rdi
  130e4d:	e8 4e 6e ef ff       	call   27ca0 <ddsi_entidx_lookup_writer_guid@plt>
  130e52:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
  130e56:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
  130e5b:	0f 85 c9 00 00 00    	jne    130f2a <ddsi_heartbeat_xevent_cb+0x16b>
  130e61:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  130e68:	48 83 c0 10          	add    $0x10,%rax
  130e6c:	48 89 c7             	mov    %rax,%rdi
  130e6f:	e8 ac 5f ef ff       	call   26e20 <__tsan_read4@plt>
  130e74:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  130e7b:	8b 40 10             	mov    0x10(%rax),%eax
  130e7e:	25 80 00 00 00       	and    $0x80,%eax
  130e83:	85 c0                	test   %eax,%eax
  130e85:	0f 84 e6 06 00 00    	je     131571 <ddsi_heartbeat_xevent_cb+0x7b2>
  130e8b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130e8f:	48 83 c0 0c          	add    $0xc,%rax
  130e93:	48 89 c7             	mov    %rax,%rdi
  130e96:	e8 85 5f ef ff       	call   26e20 <__tsan_read4@plt>
  130e9b:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130e9f:	44 8b 68 0c          	mov    0xc(%rax),%r13d
  130ea3:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130ea7:	48 83 c0 08          	add    $0x8,%rax
  130eab:	48 89 c7             	mov    %rax,%rdi
  130eae:	e8 6d 5f ef ff       	call   26e20 <__tsan_read4@plt>
  130eb3:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130eb7:	44 8b 60 08          	mov    0x8(%rax),%r12d
  130ebb:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130ebf:	48 83 c0 04          	add    $0x4,%rax
  130ec3:	48 89 c7             	mov    %rax,%rdi
  130ec6:	e8 55 5f ef ff       	call   26e20 <__tsan_read4@plt>
  130ecb:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130ecf:	8b 58 04             	mov    0x4(%rax),%ebx
  130ed2:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130ed6:	48 89 c7             	mov    %rax,%rdi
  130ed9:	e8 42 5f ef ff       	call   26e20 <__tsan_read4@plt>
  130ede:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
  130ee2:	8b 10                	mov    (%rax),%edx
  130ee4:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  130eeb:	48 83 c0 10          	add    $0x10,%rax
  130eef:	41 55                	push   %r13
  130ef1:	41 54                	push   %r12
  130ef3:	53                   	push   %rbx
  130ef4:	52                   	push   %rdx
  130ef5:	4c 8d 0d ec e7 0f 00 	lea    0xfe7ec(%rip),%r9        # 22f6e8 <unihashconsts.0+0x328>
  130efc:	4c 8d 05 fd e9 0f 00 	lea    0xfe9fd(%rip),%r8        # 22f900 <__func__.1>
  130f03:	b9 11 02 00 00       	mov    $0x211,%ecx
  130f08:	48 8d 15 d1 e4 0f 00 	lea    0xfe4d1(%rip),%rdx        # 22f3e0 <unihashconsts.0+0x20>
  130f0f:	be 80 00 00 00       	mov    $0x80,%esi
  130f14:	48 89 c7             	mov    %rax,%rdi
  130f17:	b8 00 00 00 00       	mov    $0x0,%eax
  130f1c:	e8 37 8b 0c 00       	call   1f9a58 <dds_log_cfg>
  130f21:	48 83 c4 20          	add    $0x20,%rsp
  130f25:	e9 47 06 00 00       	jmp    131571 <ddsi_heartbeat_xevent_cb+0x7b2>
  130f2a:	c7 45 8c 00 00 00 00 	movl   $0x0,-0x74(%rbp)
  130f31:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  130f35:	48 83 c0 30          	add    $0x30,%rax
  130f39:	48 89 c7             	mov    %rax,%rdi
  130f3c:	e8 8f 68 ef ff       	call   277d0 <ddsrt_mutex_lock@plt>
  130f41:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  130f45:	48 05 7c 01 00 00    	add    $0x17c,%rax
  130f4b:	48 89 c7             	mov    %rax,%rdi
  130f4e:	e8 0d 79 ef ff       	call   28860 <__tsan_read1@plt>
  130f53:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  130f57:	0f b6 80 7c 01 00 00 	movzbl 0x17c(%rax),%eax
  130f5e:	83 e0 01             	and    $0x1,%eax
  130f61:	84 c0                	test   %al,%al
  130f63:	75 28                	jne    130f8d <ddsi_heartbeat_xevent_cb+0x1ce>
  130f65:	48 8d 05 b4 e9 0f 00 	lea    0xfe9b4(%rip),%rax        # 22f920 <__PRETTY_FUNCTION__.0>
  130f6c:	48 89 c1             	mov    %rax,%rcx
  130f6f:	ba 23 02 00 00       	mov    $0x223,%edx
  130f74:	48 8d 05 65 e4 0f 00 	lea    0xfe465(%rip),%rax        # 22f3e0 <unihashconsts.0+0x20>
  130f7b:	48 89 c6             	mov    %rax,%rsi
  130f7e:	48 8d 05 ec e4 0f 00 	lea    0xfe4ec(%rip),%rax        # 22f471 <unihashconsts.0+0xb1>
  130f85:	48 89 c7             	mov    %rax,%rdi
  130f88:	e8 c3 67 ef ff       	call   27750 <__assert_fail@plt>
  130f8d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  130f91:	48 05 b0 01 00 00    	add    $0x1b0,%rax
  130f97:	48 89 c7             	mov    %rax,%rdi
  130f9a:	e8 61 74 ef ff       	call   28400 <__tsan_read8@plt>
  130f9f:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  130fa3:	48 8b 80 b0 01 00 00 	mov    0x1b0(%rax),%rax
  130faa:	48 8d 55 b0          	lea    -0x50(%rbp),%rdx
  130fae:	48 89 d6             	mov    %rdx,%rsi
  130fb1:	48 89 c7             	mov    %rax,%rdi
  130fb4:	e8 b6 36 ff ff       	call   12466f <ddsi_whc_get_state>
  130fb9:	48 8d 55 b0          	lea    -0x50(%rbp),%rdx
  130fbd:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  130fc1:	48 89 d6             	mov    %rdx,%rsi
  130fc4:	48 89 c7             	mov    %rax,%rdi
  130fc7:	e8 ea 52 f9 ff       	call   c62b6 <ddsi_writer_must_have_hb_scheduled>
  130fcc:	85 c0                	test   %eax,%eax
  130fce:	75 22                	jne    130ff2 <ddsi_heartbeat_xevent_cb+0x233>
  130fd0:	c7 45 8c 01 00 00 00 	movl   $0x1,-0x74(%rbp)
  130fd7:	48 c7 45 98 00 00 00 	movq   $0x0,-0x68(%rbp)
  130fde:	00 
  130fdf:	48 b8 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rax
  130fe6:	ff ff 7f 
  130fe9:	48 89 45 90          	mov    %rax,-0x70(%rbp)
  130fed:	e9 c0 00 00 00       	jmp    1310b2 <ddsi_heartbeat_xevent_cb+0x2f3>
  130ff2:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
  130ff9:	48 8d 4d b0          	lea    -0x50(%rbp),%rcx
  130ffd:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  131001:	48 89 ce             	mov    %rcx,%rsi
  131004:	48 89 c7             	mov    %rax,%rdi
  131007:	e8 e6 e6 ff ff       	call   12f6f2 <ddsi_writer_hbcontrol_must_send>
  13100c:	85 c0                	test   %eax,%eax
  13100e:	75 39                	jne    131049 <ddsi_heartbeat_xevent_cb+0x28a>
  131010:	c7 45 8c 01 00 00 00 	movl   $0x1,-0x74(%rbp)
  131017:	48 c7 45 98 00 00 00 	movq   $0x0,-0x68(%rbp)
  13101e:	00 
  13101f:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
  131026:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
  13102d:	48 8d 4d b0          	lea    -0x50(%rbp),%rcx
  131031:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  131035:	48 89 ce             	mov    %rcx,%rsi
  131038:	48 89 c7             	mov    %rax,%rdi
  13103b:	e8 1e e3 ff ff       	call   12f35e <ddsi_writer_hbcontrol_intv>
  131040:	48 01 d8             	add    %rbx,%rax
  131043:	48 89 45 90          	mov    %rax,-0x70(%rbp)
  131047:	eb 69                	jmp    1310b2 <ddsi_heartbeat_xevent_cb+0x2f3>
  131049:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
  131050:	48 8d 4d b0          	lea    -0x50(%rbp),%rcx
  131054:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  131058:	48 89 ce             	mov    %rcx,%rsi
  13105b:	48 89 c7             	mov    %rax,%rdi
  13105e:	e8 cb f2 ff ff       	call   13032e <ddsi_writer_hbcontrol_ack_required>
  131063:	89 45 8c             	mov    %eax,-0x74(%rbp)
  131066:	8b 4d 8c             	mov    -0x74(%rbp),%ecx
  131069:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
  131070:	48 8d 75 b0          	lea    -0x50(%rbp),%rsi
  131074:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  131078:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  13107e:	48 89 c7             	mov    %rax,%rdi
  131081:	e8 f0 e6 ff ff       	call   12f776 <ddsi_writer_hbcontrol_create_heartbeat>
  131086:	48 89 45 98          	mov    %rax,-0x68(%rbp)
  13108a:	48 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%rbx
  131091:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
  131098:	48 8d 4d b0          	lea    -0x50(%rbp),%rcx
  13109c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1310a0:	48 89 ce             	mov    %rcx,%rsi
  1310a3:	48 89 c7             	mov    %rax,%rdi
  1310a6:	e8 b3 e2 ff ff       	call   12f35e <ddsi_writer_hbcontrol_intv>
  1310ab:	48 01 d8             	add    %rbx,%rax
  1310ae:	48 89 45 90          	mov    %rax,-0x70(%rbp)
  1310b2:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1310b6:	48 05 f0 01 00 00    	add    $0x1f0,%rax
  1310bc:	48 89 c7             	mov    %rax,%rdi
  1310bf:	e8 bc 6a ef ff       	call   27b80 <ddsrt_avl_is_empty@plt>
  1310c4:	85 c0                	test   %eax,%eax
  1310c6:	0f 84 90 01 00 00    	je     13125c <ddsi_heartbeat_xevent_cb+0x49d>
  1310cc:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  1310d3:	48 83 c0 10          	add    $0x10,%rax
  1310d7:	48 89 c7             	mov    %rax,%rdi
  1310da:	e8 41 5d ef ff       	call   26e20 <__tsan_read4@plt>
  1310df:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  1310e6:	8b 40 10             	mov    0x10(%rax),%eax
  1310e9:	25 80 00 00 00       	and    $0x80,%eax
  1310ee:	85 c0                	test   %eax,%eax
  1310f0:	0f 84 7f 03 00 00    	je     131475 <ddsi_heartbeat_xevent_cb+0x6b6>
  1310f6:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1310fa:	48 89 c7             	mov    %rax,%rdi
  1310fd:	e8 29 d4 f7 ff       	call   ae52b <ddsi_writer_read_seq_xmit>
  131102:	49 89 c6             	mov    %rax,%r14
  131105:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
  131109:	48 83 c0 08          	add    $0x8,%rax
  13110d:	48 89 c7             	mov    %rax,%rdi
  131110:	e8 eb 72 ef ff       	call   28400 <__tsan_read8@plt>
  131115:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
  131119:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
  131120:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  131124:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
  13112b:	ff ff 7f 
  13112e:	48 39 d0             	cmp    %rdx,%rax
  131131:	74 2a                	je     13115d <ddsi_heartbeat_xevent_cb+0x39e>
  131133:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  131137:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
  13113e:	48 29 d0             	sub    %rdx,%rax
  131141:	66 0f ef c0          	pxor   %xmm0,%xmm0
  131145:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
  13114a:	f2 0f 10 0d ee e7 0f 	movsd  0xfe7ee(%rip),%xmm1        # 22f940 <__PRETTY_FUNCTION__.0+0x20>
  131151:	00 
  131152:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
  131156:	66 48 0f 7e c3       	movq   %xmm0,%rbx
  13115b:	eb 07                	jmp    131164 <ddsi_heartbeat_xevent_cb+0x3a5>
  13115d:	48 8b 1d e4 e7 0f 00 	mov    0xfe7e4(%rip),%rbx        # 22f948 <__PRETTY_FUNCTION__.0+0x28>
  131164:	48 83 7d 98 00       	cmpq   $0x0,-0x68(%rbp)
  131169:	74 09                	je     131174 <ddsi_heartbeat_xevent_cb+0x3b5>
  13116b:	4c 8d 2d 9d e5 0f 00 	lea    0xfe59d(%rip),%r13        # 22f70f <unihashconsts.0+0x34f>
  131172:	eb 07                	jmp    13117b <ddsi_heartbeat_xevent_cb+0x3bc>
  131174:	4c 8d 2d 99 e5 0f 00 	lea    0xfe599(%rip),%r13        # 22f714 <unihashconsts.0+0x354>
  13117b:	83 7d 8c 00          	cmpl   $0x0,-0x74(%rbp)
  13117f:	74 09                	je     13118a <ddsi_heartbeat_xevent_cb+0x3cb>
  131181:	4c 8d 25 6e e4 0f 00 	lea    0xfe46e(%rip),%r12        # 22f5f6 <unihashconsts.0+0x236>
  131188:	eb 07                	jmp    131191 <ddsi_heartbeat_xevent_cb+0x3d2>
  13118a:	4c 8d 25 66 e4 0f 00 	lea    0xfe466(%rip),%r12        # 22f5f7 <unihashconsts.0+0x237>
  131191:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  131195:	48 83 c0 10          	add    $0x10,%rax
  131199:	48 89 c7             	mov    %rax,%rdi
  13119c:	e8 7f 5c ef ff       	call   26e20 <__tsan_read4@plt>
  1311a1:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1311a5:	8b 40 10             	mov    0x10(%rax),%eax
  1311a8:	89 85 48 ff ff ff    	mov    %eax,-0xb8(%rbp)
  1311ae:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1311b2:	48 83 c0 0c          	add    $0xc,%rax
  1311b6:	48 89 c7             	mov    %rax,%rdi
  1311b9:	e8 62 5c ef ff       	call   26e20 <__tsan_read4@plt>
  1311be:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1311c2:	8b 70 0c             	mov    0xc(%rax),%esi
  1311c5:	89 b5 44 ff ff ff    	mov    %esi,-0xbc(%rbp)
  1311cb:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1311cf:	48 83 c0 08          	add    $0x8,%rax
  1311d3:	48 89 c7             	mov    %rax,%rdi
  1311d6:	e8 45 5c ef ff       	call   26e20 <__tsan_read4@plt>
  1311db:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1311df:	44 8b 78 08          	mov    0x8(%rax),%r15d
  1311e3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1311e7:	48 83 c0 04          	add    $0x4,%rax
  1311eb:	48 89 c7             	mov    %rax,%rdi
  1311ee:	e8 2d 5c ef ff       	call   26e20 <__tsan_read4@plt>
  1311f3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1311f7:	8b 50 04             	mov    0x4(%rax),%edx
  1311fa:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  131201:	48 83 c0 10          	add    $0x10,%rax
  131205:	41 56                	push   %r14
  131207:	ff b5 50 ff ff ff    	push   -0xb0(%rbp)
  13120d:	41 55                	push   %r13
  13120f:	41 54                	push   %r12
  131211:	8b 8d 48 ff ff ff    	mov    -0xb8(%rbp),%ecx
  131217:	51                   	push   %rcx
  131218:	8b b5 44 ff ff ff    	mov    -0xbc(%rbp),%esi
  13121e:	56                   	push   %rsi
  13121f:	41 57                	push   %r15
  131221:	52                   	push   %rdx
  131222:	66 48 0f 6e c3       	movq   %rbx,%xmm0
  131227:	4c 8d 0d f2 e4 0f 00 	lea    0xfe4f2(%rip),%r9        # 22f720 <unihashconsts.0+0x360>
  13122e:	4c 8d 05 cb e6 0f 00 	lea    0xfe6cb(%rip),%r8        # 22f900 <__func__.1>
  131235:	b9 3a 02 00 00       	mov    $0x23a,%ecx
  13123a:	48 8d 15 9f e1 0f 00 	lea    0xfe19f(%rip),%rdx        # 22f3e0 <unihashconsts.0+0x20>
  131241:	be 80 00 00 00       	mov    $0x80,%esi
  131246:	48 89 c7             	mov    %rax,%rdi
  131249:	b8 01 00 00 00       	mov    $0x1,%eax
  13124e:	e8 05 88 0c 00       	call   1f9a58 <dds_log_cfg>
  131253:	48 83 c4 40          	add    $0x40,%rsp
  131257:	e9 19 02 00 00       	jmp    131475 <ddsi_heartbeat_xevent_cb+0x6b6>
  13125c:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  131263:	48 83 c0 10          	add    $0x10,%rax
  131267:	48 89 c7             	mov    %rax,%rdi
  13126a:	e8 b1 5b ef ff       	call   26e20 <__tsan_read4@plt>
  13126f:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  131276:	8b 40 10             	mov    0x10(%rax),%eax
  131279:	25 80 00 00 00       	and    $0x80,%eax
  13127e:	85 c0                	test   %eax,%eax
  131280:	0f 84 ef 01 00 00    	je     131475 <ddsi_heartbeat_xevent_cb+0x6b6>
  131286:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  13128a:	48 89 c7             	mov    %rax,%rdi
  13128d:	e8 99 d2 f7 ff       	call   ae52b <ddsi_writer_read_seq_xmit>
  131292:	49 89 c7             	mov    %rax,%r15
  131295:	48 8d 45 b0          	lea    -0x50(%rbp),%rax
  131299:	48 83 c0 08          	add    $0x8,%rax
  13129d:	48 89 c7             	mov    %rax,%rdi
  1312a0:	e8 5b 71 ef ff       	call   28400 <__tsan_read8@plt>
  1312a5:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
  1312a9:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
  1312b0:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1312b4:	48 05 f0 01 00 00    	add    $0x1f0,%rax
  1312ba:	48 89 c6             	mov    %rax,%rsi
  1312bd:	48 8b 05 a4 cc 14 00 	mov    0x14cca4(%rip),%rax        # 27df68 <ddsi_wr_readers_treedef@@Base+0x7e8>
  1312c4:	48 89 c7             	mov    %rax,%rdi
  1312c7:	e8 84 65 ef ff       	call   27850 <ddsrt_avl_root_non_empty@plt>
  1312cc:	48 89 c3             	mov    %rax,%rbx
  1312cf:	48 8d 43 30          	lea    0x30(%rbx),%rax
  1312d3:	48 89 c7             	mov    %rax,%rdi
  1312d6:	e8 85 75 ef ff       	call   28860 <__tsan_read1@plt>
  1312db:	0f b6 43 30          	movzbl 0x30(%rbx),%eax
  1312df:	83 e0 04             	and    $0x4,%eax
  1312e2:	84 c0                	test   %al,%al
  1312e4:	74 09                	je     1312ef <ddsi_heartbeat_xevent_cb+0x530>
  1312e6:	4c 8d 35 09 e3 0f 00 	lea    0xfe309(%rip),%r14        # 22f5f6 <unihashconsts.0+0x236>
  1312ed:	eb 07                	jmp    1312f6 <ddsi_heartbeat_xevent_cb+0x537>
  1312ef:	4c 8d 35 6e e3 0f 00 	lea    0xfe36e(%rip),%r14        # 22f664 <unihashconsts.0+0x2a4>
  1312f6:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1312fa:	48 05 f0 01 00 00    	add    $0x1f0,%rax
  131300:	48 89 c6             	mov    %rax,%rsi
  131303:	48 8b 05 5e cc 14 00 	mov    0x14cc5e(%rip),%rax        # 27df68 <ddsi_wr_readers_treedef@@Base+0x7e8>
  13130a:	48 89 c7             	mov    %rax,%rdi
  13130d:	e8 3e 65 ef ff       	call   27850 <ddsrt_avl_root_non_empty@plt>
  131312:	48 89 c3             	mov    %rax,%rbx
  131315:	48 8d 43 38          	lea    0x38(%rbx),%rax
  131319:	48 89 c7             	mov    %rax,%rdi
  13131c:	e8 df 70 ef ff       	call   28400 <__tsan_read8@plt>
  131321:	48 8b 43 38          	mov    0x38(%rbx),%rax
  131325:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
  13132c:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  131330:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
  131337:	ff ff 7f 
  13133a:	48 39 d0             	cmp    %rdx,%rax
  13133d:	74 2a                	je     131369 <ddsi_heartbeat_xevent_cb+0x5aa>
  13133f:	48 8b 45 90          	mov    -0x70(%rbp),%rax
  131343:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
  13134a:	48 29 d0             	sub    %rdx,%rax
  13134d:	66 0f ef c0          	pxor   %xmm0,%xmm0
  131351:	f2 48 0f 2a c0       	cvtsi2sd %rax,%xmm0
  131356:	f2 0f 10 0d e2 e5 0f 	movsd  0xfe5e2(%rip),%xmm1        # 22f940 <__PRETTY_FUNCTION__.0+0x20>
  13135d:	00 
  13135e:	f2 0f 5e c1          	divsd  %xmm1,%xmm0
  131362:	66 48 0f 7e c3       	movq   %xmm0,%rbx
  131367:	eb 07                	jmp    131370 <ddsi_heartbeat_xevent_cb+0x5b1>
  131369:	48 8b 1d d8 e5 0f 00 	mov    0xfe5d8(%rip),%rbx        # 22f948 <__PRETTY_FUNCTION__.0+0x28>
  131370:	48 83 7d 98 00       	cmpq   $0x0,-0x68(%rbp)
  131375:	74 09                	je     131380 <ddsi_heartbeat_xevent_cb+0x5c1>
  131377:	4c 8d 2d 91 e3 0f 00 	lea    0xfe391(%rip),%r13        # 22f70f <unihashconsts.0+0x34f>
  13137e:	eb 07                	jmp    131387 <ddsi_heartbeat_xevent_cb+0x5c8>
  131380:	4c 8d 2d 8d e3 0f 00 	lea    0xfe38d(%rip),%r13        # 22f714 <unihashconsts.0+0x354>
  131387:	83 7d 8c 00          	cmpl   $0x0,-0x74(%rbp)
  13138b:	74 09                	je     131396 <ddsi_heartbeat_xevent_cb+0x5d7>
  13138d:	4c 8d 25 62 e2 0f 00 	lea    0xfe262(%rip),%r12        # 22f5f6 <unihashconsts.0+0x236>
  131394:	eb 07                	jmp    13139d <ddsi_heartbeat_xevent_cb+0x5de>
  131396:	4c 8d 25 5a e2 0f 00 	lea    0xfe25a(%rip),%r12        # 22f5f7 <unihashconsts.0+0x237>
  13139d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1313a1:	48 83 c0 10          	add    $0x10,%rax
  1313a5:	48 89 c7             	mov    %rax,%rdi
  1313a8:	e8 73 5a ef ff       	call   26e20 <__tsan_read4@plt>
  1313ad:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1313b1:	8b 40 10             	mov    0x10(%rax),%eax
  1313b4:	89 85 44 ff ff ff    	mov    %eax,-0xbc(%rbp)
  1313ba:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1313be:	48 83 c0 0c          	add    $0xc,%rax
  1313c2:	48 89 c7             	mov    %rax,%rdi
  1313c5:	e8 56 5a ef ff       	call   26e20 <__tsan_read4@plt>
  1313ca:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1313ce:	8b 70 0c             	mov    0xc(%rax),%esi
  1313d1:	89 b5 40 ff ff ff    	mov    %esi,-0xc0(%rbp)
  1313d7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1313db:	48 83 c0 08          	add    $0x8,%rax
  1313df:	48 89 c7             	mov    %rax,%rdi
  1313e2:	e8 39 5a ef ff       	call   26e20 <__tsan_read4@plt>
  1313e7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1313eb:	8b 78 08             	mov    0x8(%rax),%edi
  1313ee:	89 bd 3c ff ff ff    	mov    %edi,-0xc4(%rbp)
  1313f4:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1313f8:	48 83 c0 04          	add    $0x4,%rax
  1313fc:	48 89 c7             	mov    %rax,%rdi
  1313ff:	e8 1c 5a ef ff       	call   26e20 <__tsan_read4@plt>
  131404:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  131408:	8b 50 04             	mov    0x4(%rax),%edx
  13140b:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  131412:	48 83 c0 10          	add    $0x10,%rax
  131416:	41 57                	push   %r15
  131418:	ff b5 50 ff ff ff    	push   -0xb0(%rbp)
  13141e:	41 56                	push   %r14
  131420:	ff b5 48 ff ff ff    	push   -0xb8(%rbp)
  131426:	41 55                	push   %r13
  131428:	41 54                	push   %r12
  13142a:	8b 8d 44 ff ff ff    	mov    -0xbc(%rbp),%ecx
  131430:	51                   	push   %rcx
  131431:	8b b5 40 ff ff ff    	mov    -0xc0(%rbp),%esi
  131437:	56                   	push   %rsi
  131438:	8b bd 3c ff ff ff    	mov    -0xc4(%rbp),%edi
  13143e:	57                   	push   %rdi
  13143f:	52                   	push   %rdx
  131440:	66 48 0f 6e c3       	movq   %rbx,%xmm0
  131445:	4c 8d 0d 34 e3 0f 00 	lea    0xfe334(%rip),%r9        # 22f780 <unihashconsts.0+0x3c0>
  13144c:	4c 8d 05 ad e4 0f 00 	lea    0xfe4ad(%rip),%r8        # 22f900 <__func__.1>
  131453:	b9 43 02 00 00       	mov    $0x243,%ecx
  131458:	48 8d 15 81 df 0f 00 	lea    0xfdf81(%rip),%rdx        # 22f3e0 <unihashconsts.0+0x20>
  13145f:	be 80 00 00 00       	mov    $0x80,%esi
  131464:	48 89 c7             	mov    %rax,%rdi
  131467:	b8 01 00 00 00       	mov    $0x1,%eax
  13146c:	e8 e7 85 0c 00       	call   1f9a58 <dds_log_cfg>
  131471:	48 83 c4 50          	add    $0x50,%rsp
  131475:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
  131479:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
  131480:	48 89 d6             	mov    %rdx,%rsi
  131483:	48 89 c7             	mov    %rax,%rdi
  131486:	e8 5a 43 ff ff       	call   1257e5 <ddsi_resched_xevent_if_earlier>
  13148b:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  13148f:	48 05 60 01 00 00    	add    $0x160,%rax
  131495:	48 89 c7             	mov    %rax,%rdi
  131498:	e8 43 70 ef ff       	call   284e0 <__tsan_write8@plt>
  13149d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1314a1:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
  1314a5:	48 89 90 60 01 00 00 	mov    %rdx,0x160(%rax)
  1314ac:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1314b0:	48 83 c0 30          	add    $0x30,%rax
  1314b4:	48 89 c7             	mov    %rax,%rdi
  1314b7:	e8 74 5f ef ff       	call   27430 <ddsrt_mutex_unlock@plt>
  1314bc:	48 83 7d 98 00       	cmpq   $0x0,-0x68(%rbp)
  1314c1:	0f 84 aa 00 00 00    	je     131571 <ddsi_heartbeat_xevent_cb+0x7b2>
  1314c7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1314cb:	48 05 7c 01 00 00    	add    $0x17c,%rax
  1314d1:	48 89 c7             	mov    %rax,%rdi
  1314d4:	e8 87 73 ef ff       	call   28860 <__tsan_read1@plt>
  1314d9:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
  1314dd:	0f b6 80 7c 01 00 00 	movzbl 0x17c(%rax),%eax
  1314e4:	83 e0 80             	and    $0xffffff80,%eax
  1314e7:	84 c0                	test   %al,%al
  1314e9:	75 1d                	jne    131508 <ddsi_heartbeat_xevent_cb+0x749>
  1314eb:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
  1314ef:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
  1314f6:	ba 00 00 00 00       	mov    $0x0,%edx
  1314fb:	48 89 ce             	mov    %rcx,%rsi
  1314fe:	48 89 c7             	mov    %rax,%rdi
  131501:	e8 71 b3 ff ff       	call   12c877 <ddsi_xpack_addmsg>
  131506:	eb 69                	jmp    131571 <ddsi_heartbeat_xevent_cb+0x7b2>
  131508:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  13150f:	48 83 c0 10          	add    $0x10,%rax
  131513:	48 89 c7             	mov    %rax,%rdi
  131516:	e8 05 59 ef ff       	call   26e20 <__tsan_read4@plt>
  13151b:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  131522:	8b 40 10             	mov    0x10(%rax),%eax
  131525:	25 80 00 00 00       	and    $0x80,%eax
  13152a:	85 c0                	test   %eax,%eax
  13152c:	74 37                	je     131565 <ddsi_heartbeat_xevent_cb+0x7a6>
  13152e:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
  131535:	48 83 c0 10          	add    $0x10,%rax
  131539:	4c 8d 0d 9a e2 0f 00 	lea    0xfe29a(%rip),%r9        # 22f7da <unihashconsts.0+0x41a>
  131540:	4c 8d 05 b9 e3 0f 00 	lea    0xfe3b9(%rip),%r8        # 22f900 <__func__.1>
  131547:	b9 5b 02 00 00       	mov    $0x25b,%ecx
  13154c:	48 8d 15 8d de 0f 00 	lea    0xfde8d(%rip),%rdx        # 22f3e0 <unihashconsts.0+0x20>
  131553:	be 80 00 00 00       	mov    $0x80,%esi
  131558:	48 89 c7             	mov    %rax,%rdi
  13155b:	b8 00 00 00 00       	mov    $0x0,%eax
  131560:	e8 f3 84 0c 00       	call   1f9a58 <dds_log_cfg>
  131565:	48 8b 45 98          	mov    -0x68(%rbp),%rax
  131569:	48 89 c7             	mov    %rax,%rdi
  13156c:	e8 ac 64 ff ff       	call   127a1d <ddsi_xmsg_free>
  131571:	e8 ea 78 ef ff       	call   28e60 <__tsan_func_exit@plt>
  131576:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
  13157a:	64 48 2b 04 25 28 00 	sub    %fs:0x28,%rax
  131581:	00 00 
  131583:	74 05                	je     13158a <ddsi_heartbeat_xevent_cb+0x7cb>
  131585:	e8 16 6c ef ff       	call   281a0 <__stack_chk_fail@plt>
  13158a:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
  13158e:	5b                   	pop    %rbx
  13158f:	41 5c                	pop    %r12
  131591:	41 5d                	pop    %r13
  131593:	41 5e                	pop    %r14
  131595:	41 5f                	pop    %r15
  131597:	5d                   	pop    %rbp
  131598:	c3                   	ret    

Disassembly of section .fini:
