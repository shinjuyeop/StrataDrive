from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
root=Path.cwd();work=root/'build/runtime-speed-connection';out=root/'docs/test-plan/evidence/runtime-speed-connection'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,source in [('nominal','carla-nominal-600'),('input-loss','carla-input-loss')]:
 src=work/source;dst=out/'carla'/name;dst.mkdir(parents=True,exist_ok=True)
 for file in ['result.json','trace.jsonl.gz','native.stderr','diagnostic-collector.stderr']:
  shutil.copy2(src/file,dst/file)
 shutil.copytree(src/'diagnostic-store',dst/'diagnostic-store',dirs_exist_ok=True)
 shutil.copy2(work/(('carla-nominal-replay' if name=='nominal' else 'carla-input-loss-supervision')+'.json'),dst/'supervision.json')
 shutil.copy2(work/('carla-'+name+'-work.json'),dst/'work.json')
 if name=='nominal':shutil.copy2(work/'carla-nominal-supervision.json',dst/'mutations.json')
 shutil.copy2(work/(source+'.log'),dst/'server.json')
files=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
files=sorted(root/p for p in files if not p.startswith('docs/test-plan/evidence/') and (root/p).is_file())
manifest=[dict(path=str(p.relative_to(root)),sha256=sha(p),bytes=p.stat().st_size) for p in files]
(out/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'sources.tar.gz','w:gz') as archive:
 for p in files:archive.add(p,arcname=str(p.relative_to(root)),recursive=False)
validation=[]
for p in work.rglob('*'):
 if not p.is_file() or '/probe/' in str(p) or p.name=='trace.jsonl.gz' or p.suffix=='.pyc' or p.name.endswith('-compile-commands.json'):continue
 # Actual traces/stores are available separately; archive logs and bounded host evidence.
 if any(part in ('carla-nominal-600','carla-input-loss') for part in p.relative_to(work).parts):continue
 if p.name.startswith('server.log') or p.stat().st_size<20*1024*1024:validation.append(p)
with tarfile.open(out/'validation.tar.gz','w:gz') as archive:
 for p in sorted(validation):archive.add(p,arcname=str(p.relative_to(work)),recursive=False)
 for build in ['m1-angle','m1-angle-sanitized']:
  archive.add(root/'build'/build/'CMakeCache.txt',arcname=build+'/CMakeCache.txt')
  commands=json.loads((root/'build'/build/'compile_commands.json').read_text())
  subset=[v for v in commands if Path(v['file']) in files]
  p=work/(build+'-compile-commands.json');p.write_text(json.dumps(subset,indent=2)+'\n');archive.add(p,arcname=p.name)
result=dict(status='PASS_BOUNDED_NATIVE_SPEED_CONNECTION',baseline=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 tests=dict(debug_inventory=1515,initial_full_pass=1514,initial_full_fail=1,corrected_fixture='SupervisedPowerProvenance.SpeedGateExpiryAndDuplicateIdentityRemainStrict',final_affected_pass=113,final_supervision_unit_pass=20,asan_ubsan_unique_pass=89,final_native_admission_asan_pass=1,python_pass=280,cli_pass=8,clang_tidy_units=9),
 carla={name:json.loads((out/'carla'/name/'supervision.json').read_text()) for name in ['nominal','input-loss']},
 artifacts=dict(source_files=len(files),validation_files=len(validation),binary_sha256=sha(root/'build/m1-angle/tests/integration/carla/m7_1g/m7_wheel_shadow')),
 unresolved=['new monitor qualified Passed/clear','online road-load estimation and learned model','EpochRecorder transport/ACK integration and disk retention','whole ODD/wall/Target','historical M3/M4 and renderer/loading root causes'],
 initial_carla_startup=dict(status='FAIL_BEFORE_EGO',startup_seconds=180,forced_sigkill=True,retained_in='validation.tar.gz'))
(out/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(out)}\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
# Verify all tar members against manifest/current files before allowing a commit.
with tarfile.open(out/'sources.tar.gz','r:gz') as archive:
 for item in manifest:assert hashlib.sha256(archive.extractfile(item['path']).read()).hexdigest()==item['sha256']
with tarfile.open(out/'validation.tar.gz','r:gz') as archive:
 for p in validation:assert hashlib.sha256(archive.extractfile(str(p.relative_to(work))).read()).hexdigest()==sha(p)
print(json.dumps(dict(source_files=len(files),validation_files=len(validation),total_bytes=sum(p.stat().st_size for p in out.rglob('*') if p.is_file()))))
