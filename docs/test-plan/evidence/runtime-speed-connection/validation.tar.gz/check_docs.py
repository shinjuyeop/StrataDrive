from pathlib import Path
import re,subprocess,json,csv,hashlib
files=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
files=sorted(Path(p) for p in files if p.endswith('.md'))
def anchors(path):
 text=path.read_text();seen={};result=set(re.findall(r'<a\s+(?:id|name)=["\x27]([^"\x27]+)',text))
 for h in re.findall(r'^#{1,6}\s+(.+)',text,re.M):
  slug=re.sub(r'[^\w\s-]','',h.strip().lower()).replace(' ','-');n=seen.get(slug,0);seen[slug]=n+1;result.add(slug+(f'-{n}' if n else ''))
 return result
bad=[];count=0
for path in files:
 for dest in re.findall(r'\]\(([^)]+)\)',path.read_text()):
  if '://' in dest or dest.startswith(('mailto:','data:')):continue
  name,_,anchor=dest.partition('#');target=path.parent/name if name else path;count+=1
  if not target.exists():bad.append([str(path),dest,'missing file'])
  elif anchor and target.suffix=='.md' and anchor not in anchors(target):bad.append([str(path),dest,'missing anchor'])
rows=list(csv.DictReader(Path('docs/test-plan/component-traceability.csv').open()));ids=[r['id'] for r in rows];assert len(ids)==len(set(ids))
adr=Path('docs/archive/design-decisions.md').read_text();headings=re.findall(r'^## (ADR-\d{4})',adr,re.M);index=re.findall(r'^- \[(ADR-\d{4})',adr,re.M)
assert len(headings)==108 and set(headings)==set(index) and len(set(headings))==len(headings)
meta=json.loads(Path('docs/test-plan/evidence/runtime-speed-connection/sources.json').read_text())
for item in meta:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
report=dict(markdown_files=len(files),links=count,component_rows=len(rows),adr_entries=len(headings),errors=bad)
Path('build/runtime-speed-connection/docs-check.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps(report,ensure_ascii=False));assert not bad
