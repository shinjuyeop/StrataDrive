#!/usr/bin/env python3
"""Own one fresh CARLA process, read-only readiness, capture, bounded cleanup."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import socket
import subprocess
import sys
import time
import traceback


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--engine", type=Path, required=True)
    p.add_argument("--source", type=Path, required=True)
    p.add_argument("--python", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--port", type=int, default=2300)
    args = p.parse_args()
    guards = []
    try:
        for port in range(args.port, args.port + 3):
            sock = socket.socket()
            guards.append(sock)
            sock.bind(("127.0.0.1", port))
    finally:
        for sock in guards:
            sock.close()
    args.output.mkdir(parents=True, exist_ok=False)
    command = [
        str(args.engine / "Engine/Binaries/Linux/UE4Editor"),
        str(args.source / "Unreal/CarlaUE4/CarlaUE4.uproject"),
        "/Game/Carla/Maps/Town03_Opt",
        "-game",
        "-FixedSeed",
        "-RenderOffScreen",
        "-nosound",
        "-unattended",
        "-nosplash",
        "-carla-server",
        f"-carla-rpc-port={args.port}",
        "-quality-level=Low",
        "-StrataM7SensorFrame5",
        "-ini:EditorSettings:[/Script/UnrealEd.CrashReportsPrivacySettings]:bSendUnattendedBugReports=False",
        "-ini:Engine:[CrashReportClient]:bAgreeToCrashUpload=False,[CrashReportClient]:bImplicitSend=False",
        "-log",
        "-stdout",
        "-FullStdOutLogOutput",
    ]
    report = {
        "status": "FAIL",
        "argv": command,
        "startup_budget_seconds": 180,
        "capture_budget_seconds": 180,
        "source_head": subprocess.check_output(
            ["git", "-C", str(args.source), "rev-parse", "HEAD"], text=True
        ).strip(),
    }
    proc = None
    begun = time.monotonic()

    def no_core():
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

    ready_code = """
import carla,json,sys,time
c=carla.Client('127.0.0.1',int(sys.argv[1]));end=time.monotonic()+float(sys.argv[2])
while time.monotonic()<end:
 c.set_timeout(2)
 try:
  w=c.get_world();s=w.get_snapshot()
  if s.frame>0:
   print(json.dumps({'frame':s.frame,'version':c.get_server_version(),'world':w.id}));sys.exit(0)
 except RuntimeError as error:print(str(error),flush=True)
 time.sleep(.2)
sys.exit(1)
"""
    try:
        with (args.output / "server.log").open("w") as log:
            proc = subprocess.Popen(
                command,
                stdout=log,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                preexec_fn=no_core,
            )
        report["pid"] = proc.pid
        deadline = time.monotonic() + 180
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                raise RuntimeError("server exited before RPC readiness")
            try:
                with socket.create_connection(("127.0.0.1", args.port), timeout=0.5):
                    break
            except OSError:
                time.sleep(0.2)
        else:
            raise TimeoutError("RPC port readiness")
        remaining = deadline - time.monotonic()
        with (args.output / "readiness.log").open("w") as log:
            ready = subprocess.run(
                [str(args.python), "-c", ready_code, str(args.port), str(remaining)],
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=remaining + 2,
            )
        if ready.returncode or proc.poll() is not None:
            raise RuntimeError("server readiness failed")
        probe = args.output / "capture-probe.py"
        shutil.copy2(Path(__file__).with_name("carla_capture.py"), probe)
        report["probe_sha256"] = hashlib.sha256(probe.read_bytes()).hexdigest()
        with (args.output / "client.log").open("w") as log:
            capture = subprocess.run(
                [
                    str(args.python),
                    str(probe),
                    "--output",
                    str(args.output / "dataset"),
                    "--port",
                    str(args.port),
                ],
                stdout=log,
                stderr=subprocess.STDOUT,
                timeout=180,
            )
        report["capture_exit"] = capture.returncode
        if capture.returncode:
            raise RuntimeError("capture failed")
        report["status"] = "PASS"
    except Exception:
        report["error"] = traceback.format_exc()
    finally:
        if proc is not None:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGINT)
                try:
                    proc.wait(timeout=30)
                except subprocess.TimeoutExpired:
                    report["forced_stop"] = True
                    os.killpg(proc.pid, signal.SIGKILL)
                    proc.wait(timeout=10)
            report["server_exit"] = proc.returncode
            if proc.returncode != 130 or report.get("forced_stop"):
                report["status"] = "FAIL"
        report["elapsed_wall_seconds"] = time.monotonic() - begun
        (args.output / "server.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
