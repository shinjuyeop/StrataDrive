# 영상 인지 실행과 평가

M10 Host 프로파일의 입력은 RGB이고 출력은 원본 영상 pixel 좌표의 객체·관측 이력이다.
거리/trajectory/차량 command는 만들지 않는다. [계약](interfaces/perception.md)과
[실행 근거](test-plan/evidence/m10_perception/README.md)의 정확도·timing 한계를 먼저 확인한다.

## 환경과 모델

저장소 루트에서 실행한다. 기본 C++ 빌드에는 Python/ONNX/CARLA가 필요 없다.
영상 경로의 재현 환경은 `physical_ai/requirements-host.txt`다. 독립 가상환경을 권장한다.

```sh
python3 -m venv build/perception-venv
build/perception-venv/bin/pip install -r physical_ai/requirements-host.txt
build/perception-venv/bin/python -m physical_ai.perception.artifact build/perception/yolox.onnx
```

Download는 명시적 명령에서만 실행한다. 기존 파일이 있으면 크기·SHA256을 검사하고 다르면
거절한다. 런타임은 고정 FP32 CPU provider를 사용하며 artifact 경로 교체로 다른 가중치를
몰래 읽지 않도록 검증한 byte 자체로 세션을 만든다. [모델 출처·license](../third_party/opencv-zoo-yolox/README.md)를 따른다.

## Component와 수신 경계

```sh
cmake -S . -B build/perception-check -DCMAKE_BUILD_TYPE=Debug \
  -DSTRATADRIVE_PERCEPTION_TESTS=ON \
  -DPython3_EXECUTABLE="$PWD/build/perception-venv/bin/python"
cmake --build build/perception-check --target perception_receiver_test perception_replay --parallel 2
ctest --test-dir build/perception-check -R 'Perception|perception' --output-on-failure
```

명시적인 Python 경로가 필요하다. 다른 Python에 numpy/OpenCV가 없으면 configure에서 거절한다.
이 시험은 모델 다운로드 없이 전후처리·bounded worker·고장·session·tracking·C++ 경계를 검사한다.
`perception_replay`의 text 입력은 시험 도구이며 실제 CAN/SOME-IP wire가 아니다.

## CARLA 데이터 수집

[CARLA Host 경로](carla-guide.md#준비된-host-경로)의 준비된 source build를 사용한다.
전용 새 서버·빈 port2300–2302가 필요하다. 기존 주행 서버에 연결하지 않는다.
정지한 차량/보행자·단일 tick owner로 세 장면의 RGB/instance60쌍을 수집한다.
Actor physics는 꺼져 있으며 `apply_control`이나 기존 NoDrive 제어에 접근하지 않는다.

```sh
python3 tests/integration/perception/run_capture.py \
  --engine /d/shin/stratadrive-tools/UnrealEngine_4.26 \
  --source /d/shin/stratadrive-tools/m7-source/carla-0.9.16 \
  --python /d/shin/stratadrive-tools/m7-source/m7-nodrive-venv/bin/python \
  --output build/perception-capture
build/perception-venv/bin/python tests/integration/perception/prepare_dataset.py \
  build/perception-capture/dataset/capture.json build/perception-dataset
```

SDK Python은 표준 라이브러리와 기존 `carla`만 사용하고 추론 환경은 별도다.
원본 BGRA·metadata·hash는 유지하고 RGB-only `rgb.json`과 `evaluation-only-gt.json`을 분리한다.
프로젝트의 현재 renderer에는 검은 하늘/엔진 warning overlay가 관측된다. 수집 PASS는 pair·timestamp·
단일 tick·정리 검사이지 정상 ClearNoon ODD 이미지 품질 수용이 아니다. 서버의 기존 asset은 수정하지 않는다.

## 실제 추론·정답 평가·부하

아래의 출력 경로는 새 디렉터리/파일이어야 한다. 이전 실패를 덮어쓰지 않는다.

```sh
build/perception-venv/bin/python -m physical_ai.perception.run \
  --dataset build/perception-dataset/rgb.json --model build/perception/yolox.onnx \
  --output build/perception-results \
  --boundary build/perception-check/tests/integration/perception/perception_replay
build/perception-venv/bin/python tests/integration/perception/evaluate.py \
  --dataset build/perception-dataset/rgb.json \
  --truth build/perception-dataset/evaluation-only-gt.json \
  --run build/perception-results --output build/perception-evaluation.json
build/perception-venv/bin/python tests/integration/perception/stream_probe.py \
  --dataset build/perception-dataset/rgb.json --model build/perception/yolox.onnx \
  --output build/perception-stream --fault none
```

`--fault slow`는 실제 모델 앞에150ms 지연, `--fault exception`은 playback frame10부터 backend
예외를 넣는다. 각자 새 output 경로를 사용한다. 20Hz 미디어 재생은 실제 camera acquisition latency
시험이 아니다. 원래 영상 frame/time과 새 playback source를 모두 기록한다.

`result.json`은 expected/attempted/model_valid/admitted/late/errors, pre/inference/post/total wall
Mean/P95/P99/Max·N, throughput·process CPU/RSS·runtime/source hash를 기록한다.
첫 추론을 warmup 명목으로 빼지 않는다. `predictions.jsonl`은 원본 identity·모든 결과와 관측 track을 보존한다.
`boundary-input.txt`/`boundary-output.json`은 같은 결과의 C++ 수락/거절 근거다.

평가의 `raw_model`은 late 결과도 포함한 모델 TP/FP/FN, `admitted_output`은 실제 deadline을 통과한
결과만의 값이다. 둘 다 visible-instance@IoU0.5이며 COCO mAP가 아니다. Empty valid는 무검출이고
안전한 빈 도로라는 뜻이 아니다. Flat/blackout/whiteout만 별도 image-health로 거절한다.
`quality_acceptance=NOT_SET`, `wall_acceptance=NOT_CLAIMED`를 functional PASS와 구분한다.

`check_onnx.py`는 실제 ONNX Runtime/OpenCV raw tensor 동등성을 검사하고,
`check_corruptions.py`는 모델 입력 건전성과 감사 변조를 검사한다. `render_results.py`로
원본 RGB 위에 raw model·평가 전용 GT를 겹친 PNG를 만들 수 있다. 모두 `--help`에서 인자를 확인한다.

## 선택형 Host CUDA

호환 NVIDIA driver가 있는 Host에서 CPU 환경과 별도 가상환경을 만든다. 일반 환경의 ORT를
교체하지 않는다. 모델·dataset·threshold는 그대로 두고 실행 descriptor만 명시적으로 선택한다.

```sh
python3 -m venv build/perception-cuda-venv
build/perception-cuda-venv/bin/pip install -r physical_ai/requirements-cuda-host.txt
build/perception-cuda-venv/bin/python -m physical_ai.perception.run \
  --dataset build/perception-dataset/rgb.json --model build/perception/yolox.onnx \
  --output build/perception-cuda-results --execution cuda \
  --boundary build/perception-check/tests/integration/perception/perception_replay
build/perception-cuda-venv/bin/python tests/integration/perception/check_cuda.py \
  --dataset build/perception-dataset/rgb.json --model build/perception/yolox.onnx \
  --output build/perception-cuda-equivalence.json
```

`stream_probe.py`도 `--execution cuda`를 지원한다. TF32·CPU node fallback을 끄고 옵션을
readback한다. 미설치/cuDNN 로딩 오류는 실패로 기록한다. Cold call 비용을 분모에서 빼지 않으며
이 측정만으로 startup·CARLA와의 동시 GPU 부하·Jetson이나 실시간20Hz를 보장하지 않는다.
