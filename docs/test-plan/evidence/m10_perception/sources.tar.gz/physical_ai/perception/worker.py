"""Bounded latest-frame inference owner with session and completion admission."""

from dataclasses import asdict, dataclass
import threading
import time
from .contract import CameraFrame, LIFETIME_NS, uint


@dataclass
class Counters:
    submitted: int = 0
    overwritten: int = 0
    started: int = 0
    completed: int = 0
    published: int = 0
    rejected: int = 0
    errors: int = 0
    late: int = 0
    obsolete: int = 0
    cancelled: int = 0


class LatestFrameWorker:
    """source_now belongs to the declared camera clock, wall_now is monotonic ns.

    No queue, thread, or model is shared with a control owner. A stuck backend
    cannot be cancelled safely; close(timeout) reports False in that case.
    """

    def __init__(self, backend, source_now, wall_now=time.monotonic_ns):
        self._backend, self._source_now, self._wall_now = backend, source_now, wall_now
        self._condition = threading.Condition()
        self._counts = Counters()
        self._epoch = self._clock = self._generation = 0
        self._enable = self._last_source = self._last_wall = 0
        self._last_frame = self._last_acquisition = 0
        self._clock_fault = False
        self._pending = self._current = None
        self._busy = self._stopped = False
        self._last_error = None
        self._thread = threading.Thread(
            target=self._run, name="m10-perception", daemon=True
        )
        self._thread.start()

    def _clocks(self):
        try:
            source, wall = self._source_now(), self._wall_now()
        except Exception as error:
            self._clock_fault = True
            self._current = None
            self._last_error = "clock_unavailable"
            raise ValueError("clock unavailable") from error
        if (
            not uint(source)
            or not uint(wall)
            or source < self._last_source
            or wall < self._last_wall
        ):
            self._clock_fault = True
            self._current = None
            self._last_error = "clock_regression"
            raise ValueError("clock regression/type")
        self._last_source, self._last_wall = source, wall
        return source, wall

    def start_session(self, epoch, clock_instance, enable_ns):
        with self._condition:
            try:
                source, wall = self._source_now(), self._wall_now()
            except Exception:
                self._clock_fault = True
                self._current = None
                self._last_error = "clock_unavailable"
                return False
            if (
                not uint(source)
                or not uint(wall)
                or wall < self._last_wall
                or (clock_instance == self._clock and source < self._last_source)
            ):
                self._clock_fault = True
                self._current = None
                self._last_error = "clock_regression"
                return False
            if (
                self._stopped
                or not uint(epoch, 2**32 - 1, True)
                or epoch <= self._epoch
                or not uint(clock_instance, positive=True)
                or not uint(enable_ns)
                or not uint(source)
                or not uint(wall)
                or wall < self._last_wall
                or enable_ns > source
                or (
                    clock_instance == self._clock
                    and (source < self._last_source or enable_ns < self._last_source)
                )
            ):
                return False
            self._epoch, self._clock, self._enable = epoch, clock_instance, enable_ns
            self._last_source, self._last_wall = source, wall
            self._generation += 1
            self._last_frame = self._last_acquisition = 0
            self._clock_fault = False
            self._current = None
            self._last_error = None
            if self._pending is not None:
                self._counts.cancelled += 1
                self._pending = None
            return True

    def submit(self, frame: CameraFrame):
        with self._condition:
            try:
                frame.validate()
                source, wall = self._clocks()
                identity = frame.identity
                if (
                    self._stopped
                    or self._clock_fault
                    or not self._epoch
                    or (identity.epoch, identity.clock_instance)
                    != (self._epoch, self._clock)
                    or identity.source_ns < self._enable
                    or not identity.source_ns
                    <= source
                    < identity.source_ns + LIFETIME_NS
                    or identity.frame <= self._last_frame
                    or (
                        self._last_frame
                        and identity.source_ns <= self._last_acquisition
                    )
                ):
                    raise ValueError("frame admission")
            except (ValueError, TypeError, AttributeError) as error:
                self._counts.rejected += 1
                self._current = None
                self._last_error = str(error)
                # A result already in flight must not reopen availability after
                # a newer invalid submission. A new valid frame can recover.
                self._generation += 1
                if self._pending is not None:
                    self._counts.cancelled += 1
                    self._pending = None
                return False
            self._last_frame, self._last_acquisition = (
                identity.frame,
                identity.source_ns,
            )
            self._counts.submitted += 1
            if self._pending is not None:
                self._counts.overwritten += 1
            self._pending = (self._generation, frame, wall)
            self._condition.notify_all()
            return True

    def snapshot(self):
        with self._condition:
            try:
                source, _ = self._clocks()
            except ValueError:
                return None
            if (
                self._stopped
                or self._clock_fault
                or self._current is None
                or source >= self._current.expires_ns
            ):
                return None
            return self._current

    def status(self):
        with self._condition:
            return dict(
                counters=asdict(self._counts),
                busy=self._busy,
                pending=self._pending is not None,
                stop_requested=self._stopped,
                stopped=not self._thread.is_alive(),
                clock_fault=self._clock_fault,
                last_error=self._last_error,
            )

    def drain(self, timeout=5):
        """Test/offline lifecycle helper, never called by a controller."""
        with self._condition:
            return self._condition.wait_for(
                lambda: not self._busy and self._pending is None, timeout
            )

    def close(self, timeout=5):
        with self._condition:
            self._stopped = True
            self._current = None
            if self._pending is not None:
                self._counts.cancelled += 1
                self._pending = None
            self._condition.notify_all()
        self._thread.join(timeout)
        return not self._thread.is_alive()

    def _run(self):
        while True:
            with self._condition:
                self._condition.wait_for(
                    lambda: self._pending is not None or self._stopped
                )
                if self._stopped:
                    return
                generation, frame, submitted = self._pending
                self._pending = None
                self._busy = True
                self._counts.started += 1
            result, error = None, None
            try:
                result = self._backend.infer(frame)
                result.validate()
                if result.identity != frame.identity:
                    raise ValueError("backend changed camera identity")
            except Exception as caught:  # Backend failure is an unavailable result, never an empty road.
                error = f"{type(caught).__name__}: {caught}"
            with self._condition:
                self._counts.completed += 1
                self._busy = False
                if generation != self._generation or self._stopped:
                    self._counts.obsolete += 1
                else:
                    try:
                        source, wall = self._clocks()
                        if self._clock_fault:
                            raise ValueError("clock fault latched")
                        if error is not None:
                            raise ValueError(error)
                        if (
                            source >= result.expires_ns
                            or wall - submitted >= LIFETIME_NS
                        ):
                            self._counts.late += 1
                            self._current = None
                            self._last_error = "deadline"
                        else:
                            self._current = result
                            self._counts.published += 1
                            self._last_error = None
                    except (ValueError, TypeError, AttributeError) as caught:
                        self._counts.errors += 1
                        self._current = None
                        self._last_error = str(caught)
                self._condition.notify_all()
