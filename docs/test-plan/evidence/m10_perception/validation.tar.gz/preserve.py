from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile
root=Path.cwd();work=root/'build/m10-perception';dest=root/'docs/test-plan/evidence/m10_perception'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def tar(name,entries):
 with tarfile.open(dest/name,'w:gz',compresslevel=6) as archive:
  for path,arcname in entries:archive.add(path,arcname=arcname,recursive=True)
checks={}
for execution in ('cpu','cuda'):
 r=json.loads((work/'acceptance'/execution/'result.json').read_text())
 assert r['status']=='PASS' and r['expected']==r['attempted']==r['model_valid']==60
 assert r['boundary']['status']=='PASS'
 for path,digest in r['runtime']['source_files_sha256'].items():assert sha(root/path)==digest,path
 checks[execution]={k:r[k] for k in ('status','execution','model_valid','admitted','late','errors','latency','boundary','process_usage')}
for path in sorted((work/'acceptance').glob('stream-*/stream.json')):
 r=json.loads(path.read_text());assert r['status']=='PASS' and r['closed']
 for source,digest in r['runtime']['source_files_sha256'].items():assert sha(root/source)==digest,source
 checks[path.parent.name]=r['worker']['counters']
for name in ('debug','asan','release'):
 assert '100% tests passed, 0 tests failed out of 13' in (work/f'{name}-closeout-ctest.log').read_text()
assert '100% tests passed, 0 tests failed out of 1459' in (work/'full-ctest.log').read_text()
assert 'Ran 30 tests' in (work/'python-closeout.log').read_text()
assert (work/'clang-tidy-closeout.log').stat().st_size==0
for name in ('cuda-equivalence.json','onnx-equivalence-final.json','corruptions-final.json'):
 r=json.loads((work/name).read_text());assert r['status']=='PASS';shutil.copy2(work/name,dest/name)
shutil.copytree(work/'acceptance',dest/'acceptance')
shutil.copytree(work/'cuda-unavailable',dest/'cuda-unavailable')
shutil.copy2(work/'environment.json',dest/'environment.json')
shutil.copy2(work/'overview-final.png',dest/'overview.png')
(dest/'bin').mkdir(exist_ok=True)
shutil.copy2(work/'release/tests/integration/perception/perception_replay',dest/'bin/perception_replay')
tar('capture.tar.gz',[(work/'carla-final','carla-final'),(work/'dataset-final','dataset-final')])
exploratory=['carla-01','carla-02','dataset','exploratory-source','inference-01','inference-02','cpu-final','cuda-final','cuda-01','stream-none','stream-slow','stream-exception']
exploratory += [p.name for p in work.glob('final-stream-*') if p.is_dir()]
tar('exploratory.tar.gz',[(work/n,n) for n in exploratory])
validation=[p for p in work.iterdir() if p.is_file() and p.suffix in ('.log','.txt','.json','.py') and p.name not in ('overview.png','overview-final.png') and '-full-local' not in p.name]
tar('validation.tar.gz',[(p,p.name) for p in sorted(validation)])
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
paths=[root/p for p in sorted(set(changed+new)) if not p.startswith('docs/test-plan/evidence/') and (root/p).is_file()]
manifest={'baseline':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'date':'2026-11-06','timezone':'Asia/Seoul',
          'files':{str(p.relative_to(root)):sha(p) for p in paths}}
(dest/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
tar('sources.tar.gz',[(p,str(p.relative_to(root))) for p in paths])
summary={'technical_status':'PASS_DECLARED_HOST_BOUNDARY','milestone_acceptance':'M10_OPEN','capture_pairs':60,'capture_attempts':3,'capture_successes':2,'capture_preparation_failures':1,
 'core_regression':{'passed':1459,'excluded':'runtime.wall; M7 opt-in suites not configured'},
 'component_ctest':{'Debug':13,'Release':13,'ASan_UBSan':13,'python_cases_per_test':30,'cpp_cases':11,'boundary_mutations':19},
 'quality_acceptance':'NOT_SET','full_20hz_acceptance':'OPEN; CPU throughput and CUDA cold miss/drop',
 'metric_fusion_native_vehicle_m11_planner_jetson':'NOT_RUN','runs':checks}
(dest/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'source_files':len(paths),'files':len(list(dest.rglob('*'))),'archive_bytes':{p.name:p.stat().st_size for p in dest.glob('*.tar.gz')}},indent=2))
