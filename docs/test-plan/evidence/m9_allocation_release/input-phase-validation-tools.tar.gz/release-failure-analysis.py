import csv,json
from pathlib import Path
base=Path('build/m9-closeout');case=base/'service-campaign/tsan-normal/central-rejoin-1'
read=lambda name:list(csv.DictReader((case/name).open()))
rows=read('central-1.transport.csv')
ready=next(r for r in rows if r['event']=='allocation-readiness' and r['peer']=='102' and r['decision']=='0')
front=next(r for r in rows if r['event']=='central-enqueued' and r['token']=='251')
period=10000000;checked=int(ready['sent']);execution=int(front['payload_source']);actual=checked+((execution-checked)//period)*period
expiry=int(front['inner_deadline']);next_release=actual+period
assert actual>checked and expiry<next_release and int(ready['inner_deadline'])-checked>18000000
report={'case':str(case),'qualification':ready,'front_command':front,'checked_release_ns':checked,'actual_recorded_release_ns':actual,'next_release_ns':next_release,'expiry_ns':expiry,'gap_before_next_release_ns':next_release-expiry,'command_delivery':[]}
for role,token in [('front','251'),('rear','254')]:
 tx=next(r for r in rows if r['event']=='central-enqueued' and r['token']==token)
 remote=read(role+'-1.transport.csv');rx=next(r for r in remote if r['event']=='zone-received' and r['token']==token)
 assert int(rx['ns'])<expiry
 report['command_delivery'].append({'role':role,'sent_ns':int(tx['sent']),'received_ns':int(rx['ns']),'before_expiry_ns':expiry-int(rx['ns'])})
(base/'release-failure-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
