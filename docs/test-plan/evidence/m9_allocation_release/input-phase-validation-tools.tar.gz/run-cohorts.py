from pathlib import Path
import subprocess,json,time
base=Path('build/m9-closeout');rows=[]
for name in ('regressions','campaign'):
 command=['python3',str(base/(name+'.py'))];begin=time.monotonic_ns()
 with (base/(name+'-driver.log')).open('w')as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'cohort':name,'command':command,'begin_ns':begin,'end_ns':time.monotonic_ns(),'exit':r.returncode})
 (base/'cohorts.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
raise SystemExit(int(any(r['exit']for r in rows)))
