from pathlib import Path
import subprocess,json
base=Path('build/m9-release-slot');rows=[]
for profile,d in [('normal','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 cmds=[(profile+'-rebuild',['cmake','--build',d,'--parallel','2','--target','vehicle_coordinator_test','m4_async_runtime_test','async_owner_test','owner_schedule_test']),
       (profile+'-control-retest',(['setarch','x86_64','-R']if profile=='tsan'else[])+['ctest','--test-dir',d,'--output-on-failure','-R','Coordinator|M4Async|M4Refresh|OwnerSchedule|AsyncOwnerTest|AsyncZoneOwnerTest'])]
 for name,cmd in cmds:
  with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'rebuild-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
for profile in ('normal','asan','tsan'):
 name=profile+'-adapter-rebuild';cmd=['cmake','--build','build/m5-someip-'+profile+'/project','--target','someip_front_adapter','--parallel','2']
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'rebuild-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for phase,script in [('remaining-checks','remaining-checks.py'),('source-snapshot','snapshot.py'),('native-cohorts','run-cohorts.py')]:
 (base/'phase.json').write_text(json.dumps({'phase':phase})+'\n')
 r=subprocess.call(['python3',str(base/script)])
 if r:raise SystemExit(r)
(base/'phase.json').write_text(json.dumps({'phase':'complete'})+'\n')
