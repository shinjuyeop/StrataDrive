from pathlib import Path
import hashlib,json,tarfile,shutil
root=Path.cwd();out=root/'docs/test-plan/evidence/m9_allocation_release'
out.mkdir(parents=True,exist_ok=False)
combined={};identities=[]
for label,directory in [('input-phase','build/m9-closeout'),('release-slot','build/m9-release-slot')]:
 base=root/directory;source_manifest=json.loads((base/'runtime-sources.json').read_text())
 with tarfile.open(base/'runtime-sources.tar.gz')as archive:
  for name,digest in source_manifest.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest,name
 reports={}
 for cohort in ('functional-regressions','service-campaign'):
  folder=base/cohort;manifest=json.loads((folder/'manifest.json').read_text());rows=json.loads((folder/'results.json').read_text());reports[cohort]={'manifest':manifest,'results':rows}
  for name,digest in manifest['sources'].items():
   # Protocol files outside the complete source archive are preserved in the
   # functional per-cohort snapshot; runtime sources themselves must match.
   if name in source_manifest:assert digest==source_manifest[name],(label,name)
  if cohort=='functional-regressions':
   with tarfile.open(out/(label+'-functional.tar.gz'),'w:gz',compresslevel=6)as tar:tar.add(folder,arcname=cohort)
  else:
   for profile,repeat in [('normal',1),('asan',1),('tsan',1),('tsan',2),('tsan',3)]:
    group=[r for r in rows if r['name'].startswith(profile+'-')and(r['name'].endswith('-r'+str(repeat))if repeat>1 else not r['name'].endswith(('-r2','-r3')))]
    assert len(group)==6
    with tarfile.open(out/(label+'-'+profile+'-r'+str(repeat)+'.tar.gz'),'w:gz',compresslevel=6)as tar:
     for row in group:
      name=row['name'];tar.add(folder/name,arcname=cohort+'/'+name)
      for p in sorted(folder.glob(name+'.*.log')):tar.add(p,arcname=cohort+'/'+p.name)
 combined[label]=reports
 with tarfile.open(out/(label+'-validation-tools.tar.gz'),'w:gz',compresslevel=6)as tar:
  for p in sorted(base.iterdir()):
   if p.is_file() or p.name=='static-initial':tar.add(p,arcname=p.name)
  for p in sorted((base/'service-campaign').glob('*.json')):tar.add(p,arcname='service-campaign/'+p.name)
 shutil.copy2(base/'runtime-sources.tar.gz',out/(label+'-sources.tar.gz'))
 identities.append({'candidate':label,'snapshot_files_verified':len(source_manifest)})
final=combined['release-slot']['service-campaign']['manifest']
for profile,digest in final['binaries'].items():assert hashlib.sha256((root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==digest
for name,digest in json.loads((root/'build/m9-release-slot/runtime-sources.json').read_text()).items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
(out/'results.json').write_text(json.dumps(combined,indent=2)+'\n')
(out/'identity-checks.json').write_text(json.dumps({'candidates':identities,'final_sources_match':True,'final_binaries_match':True},indent=2)+'\n')
with tarfile.open(out/'build-configurations.tar.gz','w:gz')as tar:
 for profile in ('normal','asan','tsan'):
  for part in ('project','sdk'):
   for name in ('CMakeCache.txt','compile_commands.json'):
    p=root/f'build/m5-someip-{profile}'/part/name
    if p.exists():tar.add(p,arcname=f'{profile}/{part}/{name}')
print(json.dumps({p.name:p.stat().st_size for p in out.iterdir()},indent=2))
