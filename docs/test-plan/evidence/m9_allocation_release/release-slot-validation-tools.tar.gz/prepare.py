from pathlib import Path
import json,subprocess,tarfile,hashlib
base=Path('build/m9-release-slot')
for name in ('regressions','campaign','run-cohorts','static'):
 source=Path('build/m9-closeout',name+'.py').read_text().replace('build/m9-closeout','build/m9-release-slot')
 if name=='regressions':source=source.replace("files=[", "files=['central/coordinator/vehicle_coordinator.cpp','central/coordinator/vehicle_coordinator.hpp','tests/unit/vehicle_coordinator_test.cpp','docs/test-plan/allocation-release-protocol.md',")
 if name=='static':source=source.replace("names=['tests", "names=['central/coordinator/vehicle_coordinator.cpp','tests").replace('assert len(selected)==1','assert len(selected)==2')
 (base/(name+'.py')).write_text(source)
