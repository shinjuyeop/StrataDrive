from pathlib import Path
import json,subprocess,time
base=Path('build/m9-release-slot')
while True:
 rows=json.loads((base/'validation.json').read_text())
 if any(r['exit']for r in rows):raise SystemExit('validation failed')
 if len(rows)==12 and rows[-1]['name']=='tsan-adapter':break
 time.sleep(3)
for phase,script in [('remaining-checks','remaining-checks.py'),('source-snapshot','snapshot.py'),('native-cohorts','run-cohorts.py')]:
 (base/'phase.json').write_text(json.dumps({'phase':phase,'monotonic_ns':time.monotonic_ns()})+'\n')
 result=subprocess.call(['python3',str(base/script)])
 if result:raise SystemExit(result)
(base/'phase.json').write_text(json.dumps({'phase':'complete','monotonic_ns':time.monotonic_ns()})+'\n')
