from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
root=Path.cwd();out=root/'build/m9-release-slot/functional-regressions';out.mkdir(exist_ok=False)
cases=[(p,c,three) for p in ('normal','asan') for three,names in ((True,('normal','command-loss','restart-live')),(False,('delay','overflow','close-full'))) for c in names]
files=['central/coordinator/vehicle_coordinator.cpp','central/coordinator/vehicle_coordinator.hpp','tests/unit/vehicle_coordinator_test.cpp','docs/test-plan/allocation-release-protocol.md','tests/integration/someip/owner_schedule.hpp','tests/unit/owner_schedule_test.cpp','docs/test-plan/owner-input-phase-protocol.md','central/coordinator/async_coordinator_port.cpp','central/coordinator/async_coordinator_port.hpp','tests/integration/someip/native_oracle.py','docs/test-plan/feedback-order-protocol.md','interfaces/someip/owner_transport.hpp','interfaces/common/monotonic_condition.hpp','tests/integration/someip/front_adapter.cpp','tests/integration/someip/front_run.py','tests/integration/someip/sdk_outcomes.py','tests/integration/someip/fixture_signals.hpp','tests/integration/someip/fixture_placement.hpp','tests/integration/someip/fixture_placement.py','tests/integration/someip/native_diagnostic_routes.cpp','tests/integration/someip/native_continuity_service.cpp']
manifest={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'cases':cases,'sources':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in files},'binaries':{p:hashlib.sha256(Path(f'build/m5-someip-{p}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()for p in ('normal','asan')}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');results=[]
for profile,case,three in cases:
 name=profile+'-'+case;cmd=[sys.executable,'tests/integration/someip/front_run.py',str(out/name),'--profile',profile,'--cases',case]
 if three:cmd+=['--three','--simple-vehicle','--diagnostics','--isolated-ecus']
 assert hashlib.sha256(Path(f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==manifest['binaries'][profile]
 for source,digest in manifest['sources'].items():
  assert hashlib.sha256(Path(source).read_bytes()).hexdigest()==digest,source
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'three':three,'command':cmd,'exit':r.returncode};results.append(row);print(json.dumps(row),flush=True)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
 for p,digest in manifest['sources'].items():
  assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest
  tar.add(p,arcname=p)
sys.exit(int(any(x['exit'] for x in results)))
