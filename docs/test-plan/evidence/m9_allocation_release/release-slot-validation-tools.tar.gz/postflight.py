from pathlib import Path
import json,subprocess,time
base=Path('build/m9-release-slot')
while True:
 p=base/'cohorts.json'
 if p.exists():
  rows=json.loads(p.read_text())
  if len(rows)==2:break
 time.sleep(3)
cmd=['ctest','--test-dir','build/m7-functional','-R','^M7','--no-tests=error','--output-on-failure']
with (base/'carla-actual-tests.log').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(base/'carla-actual-tests.json').write_text(json.dumps({'command':cmd,'exit':r.returncode})+'\n')
print('carla actual',r.returncode,flush=True)
if not r.returncode:
 subprocess.run(['python3',str(base/'analyze-release.py')],check=True)
raise SystemExit(r.returncode)
