import hashlib,json,os,subprocess,sys
from pathlib import Path
sys.path.insert(0,'tests/integration/diagnostics')
from service_sanitizer_suite import judge_xml
profile=sys.argv[1]; build=Path(sys.argv[2]).resolve(); out=Path('build/m9-sensor-matrix')/(profile+'-validation'); out.mkdir(exist_ok=False)
targets=('native_sensor_matrix_test','native_diagnostics_sil_test','async_owner_test')
rows=[]
for target in targets:
    binary=build/target; xml=(out/(target+'.xml')).resolve(); log=out/(target+'.log')
    command=(['setarch','x86_64','-R'] if profile=='tsan' else [])+[str(binary),'--gtest_output=xml:'+str(xml)]
    env=dict(os.environ,ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:exitcode=66')
    if target=='native_sensor_matrix_test': env['STRATADRIVE_M9_MATRIX_EVIDENCE']=str((out/'matrix').resolve())
    row={'target':target,'command':command,'sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
    with log.open('w') as stream:
        try: code=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=600).returncode
        except subprocess.TimeoutExpired: code=124
    row['exit']=code
    try: row.update(judge_xml(xml,code,log.read_text()))
    except Exception as error: row.update({'pass':False,'error':str(error)})
    rows.append(row); (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n'); print(json.dumps(row),flush=True)
sys.exit(not all(r['pass'] for r in rows))
