from pathlib import Path
import hashlib,json,subprocess,tarfile,xml.etree.ElementTree as ET
base=Path('build/m9-sensor-matrix'); out=Path('docs/test-plan/evidence/m9_sensor_matrix')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reports={}
for profile in ('asan','tsan'):
    rows=json.loads((base/(profile+'-validation/results.json')).read_text())
    assert len(rows)==3 and all(r['pass'] for r in rows)
    assert sum(r['tests'] for r in rows)==51
    for row in rows:
        binary=row['command'][3] if profile=='tsan' else row['command'][0]
        assert sha(binary)==row['sha256']
    reports[profile]=rows
xml=ET.parse(base/'debug-v2.xml').getroot();assert int(xml.get('tests'))==16 and int(xml.get('failures'))==0
xml=ET.parse(base/'remote-debug.xml').getroot();assert int(xml.get('tests'))==24 and int(xml.get('failures'))==0
wall=(base/'ctest-wall.log').read_text();assert '100% tests passed, 0 tests failed out of 9' in wall
summary={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'scope':'8-role logical sensor-fault SIL; no CARLA/native wall matrix or full M9 completion',
 'recipes':15,'runs_per_profile':30,'profiles':{},'sanitizers':reports,
 'debug_checks':{'unique_total':1297,'matrix':16,'regression':1272,'quiet_wall':9,
    'first_regression_pass':1271,'first_regression_fail':1,'corrected_binding_target_pass':24},
 'python_unittests':41,'static_analysis':'4 affected TUs clang-tidy and cppcheck; no project findings',
 'initial_debug':{'gtests':16,'pass':14,'fail':2,'exported_cases':28,'binary_hash_available':False}}
for profile,folder in (('debug','debug-v2'),('asan','asan-validation/matrix'),('tsan','tsan-validation/matrix')):
    rows=json.loads((base/('audit-'+profile+'-final.json')).read_text());assert len(rows)==30 and all(r['passed'] for r in rows)
    summary['profiles'][profile]={'pass':30,'total':30,'root_dtc':sum(r['roots'] for r in rows),
       'qualified_passes':sum(r['qualified_passes'] for r in rows),'mutations_rejected':sum(len(r['mutations_rejected']) for r in rows)}
    with tarfile.open(out/(profile+'.tar.gz'),'w:gz') as tar:tar.add(base/folder,arcname=profile)
with tarfile.open(out/'initial-debug.tar.gz','w:gz') as tar:tar.add(base/'debug',arcname='initial-debug')
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
files=sorted(set(p for p in files if p and Path(p).is_file() and (Path(p).suffix in ('.cpp','.hpp','.py','.cmake') or Path(p).name=='CMakeLists.txt' or p=='docs/test-plan/native-sensor-matrix-protocol.md')))
manifest={p:sha(p) for p in files}
(out/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
    for p in files:tar.add(p,arcname=p)
prior=json.loads((base/'runtime-sources.json').read_text())
summary['source_changes_after_matrix_build']=[p for p,h in prior.items() if sha(p)!=h]
assert set(summary['source_changes_after_matrix_build'])=={'tests/unit/remote_zone_integration_test.cpp','tests/integration/diagnostics/audit_native_sensor_matrix.py'}
with tarfile.open(out/'validation.tar.gz','w:gz') as tar:
    for p in sorted(base.iterdir()):
        if p.is_file():tar.add(p,arcname=p.name)
    for profile in ('asan','tsan'):
        for p in sorted((base/(profile+'-validation')).iterdir()):
            if p.is_file():tar.add(p,arcname=profile+'-validation/'+p.name)
summary['debug_matrix_binary_sha256']=sha('build/m1-angle/native_sensor_matrix_test')
summary['source_count']=len(manifest)
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
verified={}
for profile,folder in (('debug','debug-v2'),('asan','asan-validation/matrix'),('tsan','tsan-validation/matrix'),('initial-debug','debug')):
    count=0
    with tarfile.open(out/(profile+'.tar.gz')) as tar:
        for member in tar:
            if member.isfile():
                relative=Path(member.name).relative_to(profile)
                assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==sha(base/folder/relative)
                count+=1
    verified[profile]=count
(out/'archive-verification.json').write_text(json.dumps(verified,indent=2)+'\n')
print(json.dumps({'profiles':summary['profiles'],'archives_verified':verified,'source_count':len(manifest)},indent=2))
