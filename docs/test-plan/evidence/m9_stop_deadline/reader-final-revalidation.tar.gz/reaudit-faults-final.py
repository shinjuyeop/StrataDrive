from pathlib import Path
import json,subprocess,hashlib
base=Path('build/m9-stop-poll');out=base/'reader-revalidation-final';out.mkdir(exist_ok=False);rows=[]
for cohort in ('m9-closeout','m9-release-slot','m9-sdk-smt','m9-stop-poll'):
 source=Path('build')/cohort/'service-campaign'
 for row in json.loads((source/'results.json').read_text()):
  if row['fault']=='normal':continue
  name=row['name'];expected=row['audit_exit']
  if cohort=='m9-closeout' and name in ('normal-stop-request-loss','asan-stop-request-loss','tsan-stop-request-loss-r2'):expected=0
  if cohort=='m9-stop-poll' and name in ('tsan-stop-request-loss-r2','tsan-stop-request-loss-r3'):expected=0
  cmd=['python3','tests/integration/diagnostics/audit_native_service_faults.py',str(source/name/'central-rejoin-1'),'--mutations']
  with (out/(cohort+'-'+name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  rows.append({'cohort':cohort,'case':name,'expected_exit':expected,'exit':r.returncode})
  (base/'reader-revalidation-final.json').write_text(json.dumps({'reader_sha256':hashlib.sha256(Path(cmd[1]).read_bytes()).hexdigest(),'rows':rows},indent=2)+'\n')
print('cases',len(rows),'unexpected',[(r['cohort'],r['case'],r['exit'])for r in rows if r['exit']!=r['expected_exit']],flush=True)
raise SystemExit(int(any(r['exit']!=r['expected_exit']for r in rows)))
