from pathlib import Path
import struct,json
p=Path('build/m9-stop-poll/service-campaign/tsan-actual-loss-r2/central-rejoin-1/traffic.pcap');data=p.read_bytes();at=24;active={};flows={};n=0
while at<len(data):
 sec,usec,size,orig=struct.unpack_from('<IIII',data,at);at+=16;packet=data[at:at+size];at+=size
 if len(packet)<34 or packet[12:14]!=b'\x08\x00':continue
 ip=packet[14:];ihl=(ip[0]&15)*4
 if ip[9]!=6:continue
 tcp=ip[ihl:];src,dst,seq=struct.unpack_from('!HHI',tcp)
 if not {src,dst}&{*range(30501,30509),31610,31611,31612}:continue
 pair=(bytes(ip[12:16]).hex(),bytes(ip[16:20]).hex(),src,dst)
 if tcp[13]&2 and not tcp[13]&16:
  if pair not in active or active[pair][0]!=seq:active[pair]=(seq,n);n+=1
 initial,g=active.get(pair,(0,-1));header=(tcp[12]>>4)*4;length=int.from_bytes(ip[2:4],'big');payload=ip[ihl+header:length]
 if payload:flows.setdefault(pair+(g,initial),[]).append((seq+int(bool(tcp[13]&2)),len(payload)))
reports=[]
for key,segs in flows.items():
 end=None;gaps=[]
 for seq,length in sorted(segs):
  if end is not None and seq>end:gaps.append([end,seq,seq-end])
  end=max(end or 0,seq+length)
 if gaps:reports.append({'flow':key,'segments':len(segs),'gaps':gaps,'lowest':min(segs),'highest':max(segs)})
Path('build/m9-stop-poll/pcap-gap.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports,indent=2))
