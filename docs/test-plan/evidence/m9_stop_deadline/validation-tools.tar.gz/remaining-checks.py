from pathlib import Path
import subprocess,json
base=Path('build/m9-stop-poll');rows=[]
commands=[('static',['python3',str(base/'static.py')]),('sdk-stages-python',['python3','tests/unit/sdk_stages_test.py']),('carla-python',['python3','tests/unit/carla_evidence_test.py']),('carla-configure',['cmake','-S','.','-B','build/m7-functional']),('carla-build',['cmake','--build','build/m7-functional','--parallel','2','--target','m7_functional_test','m7_wheel_test','m7_external_test','m7_native_admission_test','m7_plant_contract_test','m7_effort_contract_test']),('carla-test',['python3',str(base/'carla-all-targets.py')])]
for name,cmd in commands:
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'remaining-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
