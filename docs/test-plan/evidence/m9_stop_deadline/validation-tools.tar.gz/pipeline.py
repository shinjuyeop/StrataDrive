from pathlib import Path
import subprocess,json,time
base=Path('build/m9-stop-poll');rows=[]
for phase,script in [('validation','validate.py'),('remaining-checks','remaining-checks.py'),('source-snapshot','snapshot.py'),('native-cohorts','run-cohorts.py')]:
 (base/'phase.json').write_text(json.dumps({'phase':phase,'time_ns':time.monotonic_ns()})+'\n')
 r=subprocess.call(['python3',str(base/script)])
 rows.append({'phase':phase,'exit':r});(base/'pipeline-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 if r:raise SystemExit(r)
(base/'phase.json').write_text(json.dumps({'phase':'complete'})+'\n')
