from pathlib import Path
import subprocess,json,tarfile
base=Path('build/m9-stop-poll');rows=[];source=Path('central/coordinator/vehicle_coordinator.cpp');fixed=source.read_bytes()
def run(name,cmd):
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'red-green.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True);return r.returncode
try:
 with tarfile.open('docs/test-plan/evidence/m9_allocation_release/release-slot-sources.tar.gz')as tar:source.write_bytes(tar.extractfile(str(source)).read())
 assert run('red-build',['cmake','--build','build/m1-angle','--target','vehicle_coordinator_test','--parallel','2'])==0
 assert run('red',['build/m1-angle/vehicle_coordinator_test','--gtest_filter=CoordinatorTest.StopAgeBetweenManagement*'])==1
finally:source.write_bytes(fixed)
assert run('green-build',['cmake','--build','build/m1-angle','--target','vehicle_coordinator_test','normal_stop_test','--parallel','2'])==0
assert run('green-coordinator',['build/m1-angle/vehicle_coordinator_test'])==0
assert run('green-stop',['build/m1-angle/normal_stop_test'])==0
