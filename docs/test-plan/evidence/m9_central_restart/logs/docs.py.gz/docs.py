from pathlib import Path
p=Path('docs/interfaces/diagnostics.md');s=p.read_text();i=s.index('## 다음 구현 경계');s=s[:i]+'''## Central process 재기동과 trusted issuer 계승

`ContextualOutbox`의 명시적 `CentralIssuer` manifest는 최초 Epoch1부터 최대16개의
`producer/first_epoch` 구간을 고정한다. 경계는 증가하고 발행자는 중복되지 않는다. 수신 packet으로
발행자를 학습하지 않는다. 기존 단일 발행자 API는 `{producer,1}`과 같다. 새 원본 Session은 해당
Epoch의 trusted issuer·run/profile/clock·8-role Release와 실제 local accepted RunLease를 모두
만족해야 한다. 새 issuer context를 durable commit한 뒤에만 sender ACK 메모리를0으로 되돌려
원래 ordinal1부터 보낸다. 오래된/앞선 ACK는 진행을 건너뛰지 못한다. 원격 producer/sequence와
원본 times는 유지한다. CRC/manifest는 인증 기능이 아니다.

`MergedCollector`는 명시적으로 전달된 predecessor의 검증 committed prefix를 새 merged store에
가져오고 현재 replica와 대조한 뒤 live 입력을 받는다. 동일 ID/동일 bytes는 dedup하고 충돌·foreign
registry·저장 실패는 fail closed다. 원본 suffix/incomplete marker를 고치거나 옮기지 않는다.
재시작 projection은 Unknown이며 새 Session/재전송만으로 이전 고장을 Passed/cleared로 만들지 않는다.

Native `central-rejoin --diagnostics --three`는 Central1을 실제 SIGKILL하고 같은 kernel/netns에서
새 Central2 SDK client0x1312로 시작한다. Front/Rear/plant는 계속 살아 있다. 명시적 startup 요청과
실제 EpochStore의 Epoch2가 필요하다. Central 준비/영속 Epoch 발급 중에는 기존 quiescent ingress
전환으로 이전 상태 입력을 계수하며 차단한다. 새 handshake 전에 전환을 끝내고 정상 FIFO8을 쓴다.
새 readiness를 과거 overflow 소거로 만들지 않는다.

Private lifecycle9100은 generation2를 영속 발급한다. Global issuer는7→`(1<<32)|7`, observer는
8→`(1<<32)|8`이며 trusted 경계는 Epoch2다. 새 observer 순번1의 SD-5001/monitor10/subject8은
원래 boot 시각·previous/new generation·cause_unknown/unmapped를 기록한다. Central event queue의
저장 전 손실은 증명할 수 없다. 손실 개수를 추정하지 않고, 새 실제 정상 운전/정지/HV-off와 완전한
replay도 이 incident의 복구 proof나 clear 허가가 아니다. 연속성 reconciliation/clear 계약은 OPEN이다.

Fixture는9개의 생존 source stream8200–8208을 유지한다. 새 Central replica `source-*-2`, merged
`merged-2`(store8002), context source `context-*-2`를 사전 provision한다. 이전 merged8000/9개
replica의 committed 원본을 가져오며 old context source의 원본 Session1은 ordinal1, 새 Session2는
ordinal2다. 이전 파일·commit·suffix를 보존한다. Control TCP512/진단2048·FIFO8·pending32·retry100ms·
drain2s·원래100ms 물리 판정은 유지한다. 같은 clock의2세대 유한 fixture이며 host reboot·반복 재기동
용량·native4ms/Target 수용은 포함하지 않는다.
[recipe](../test-plan/diagnostics-protocol.md#central-process-재기동-fixture)와
[원본·검증·실패](../test-plan/evidence/m9_central_restart/README.md)를 따른다.

'''+s[i:];s=s.replace('Front/Rear process 재기동의 producer adoption·연속성 미확인 전달 뒤에는 Central process 재기동,\n연속성 reconciliation과', 'Central/Front/Rear process 재기동의 producer adoption·연속성 미확인 전달 뒤에는\n연속성 reconciliation과');p.write_text(s)
p=Path('docs/test-plan/diagnostics-protocol.md');s=p.read_text()+'''

## Central process 재기동 fixture

사전 고정: 기존11개 기능 case에 central-process-rejoin(control case central-rejoin)1개를 추가한다.
실제 정상 control/physical·9개 원격 source 최초 committed prefix·두 context ACK·8개 실제 Release
ACK의 writer flush 뒤 Central1을 SIGKILL한다. 같은 Front/Rear PID·plant를 유지하고 독립 보호와
원래100ms torque/brake 반응을 관측한다. 명시적 startup 요청 뒤 Central2의 새 SDK client·실제
Epoch2/8-role Release·accepted credit18개·새 정상 운전/정지/HV-off를 확인한다.

Trusted issuer 범위는 Epoch1의7과 Epoch2 이상의(1<<32)|7이다. 잘못된 issuer/범위·중복 ID·빈
manifest·local ID·17개 범위는 거부한다. 실제 새 credit 없이 successor Session을 채택하지 않는다.
새 issuer 채택 뒤 sender ACK0부터 재전송하며 새 replica는 원본 ordinal1부터 commit/ACK해야 한다.
Central2의 준비/EpochStore IO에는 기존 ingress quiesce를 적용하고 폐기 수를 남긴다. 정상 제어의
queue/deadline 예산을 늘리거나 이미 관측한 overflow를 지워 통과시키지 않는다.

이전 merged/9개 replica의 committed prefix를 새 store로 가져온다. 이전 store·suffix·incomplete를
보존하고 독립 auditor로 watermark/bytes/보고값을 대조한다. 단위 시험은 실제 uncommitted tail,
foreign registry, 동일 ID 충돌도 검사한다. Source/replica/새 merged의 원형 bytes·DTC 중복 집계 없음·
SD-5001 uncleared를 확인한다. 정상 복귀와 replay는 unknown volatile loss의 복구 증거가 아니다.

Normal/ASan은12개 case를, SDK TSan은 normal/drop-ack/Central process 재기동을 단독 실행한다.
모든 실패/timeout/cleanup·source/binary/config/도구 hash를 보존한다. 독립 auditor는 두 실제 process,
8개 실제 ACK씩의 원래 수신 시각, 원본 Session/credit, 새 client의 모든 remote ordinal ACK와
fresh replica ordinal1, lifecycle9100의 unclosed start/new generation/explicit close를 확인한다.
issuer/Release/prefix/tail/gap/boot/credit/fresh ACK/ordinal1/clear/physical/survivor12개 변조를 거부한다.
Native4ms/Target·host clock 변경·무한 반복·연속성 reconciliation/clear·TBD-08 수용은 OPEN이다.
''';p.write_text(s)
p=Path('docs/archive/design-decisions.md');s=p.read_text()+'''

## ADR-0091: Central process 재기동의 명시적 issuer 구간과 fresh collector

상태: Host 기능 구현. M9/TBD-08·native4ms/Target·연속성 reconciliation/clear 수용 OPEN.

Central process는 global Session 발행자도 잃으므로 기존 producer/순번을 새 process에서 재사용하지
않는다. Private lifecycle9100으로 세대를 발급하고 trusted manifest가 issuer의 Epoch 구간을
명시한다. 원격 source는 원본 Session과 실제 local accepted credit를 재대조한 뒤 fresh replica로
ordinal1부터 재전송한다. 수신 packet으로 신뢰 목록이나 새 Epoch를 만들지 않는다.

이전 collector journal을 자동 repair하지 않고 검증된 committed prefix만 fresh merged/replica에
가져온다. 기존 bytes/suffix는 보존하고 동일 ID 충돌과 저장 실패는 fail closed다. Source producer와
원래 timestamp를 유지한다. Central 준비/EpochStore IO는 기존 명시적 ingress quiesce 안에서
수행하고 폐기 수를 기록한 뒤 실제 새 handshake를 시작한다. FIFO/deadline은 유지한다.

재기동/정상 복귀/replay가 저장 전 메모리 손실 여부를 증명하지 못한다. 새 Central observer의
SD-5001은 original boot/세대·cause_unknown/unmapped로 남기고 clear를 차단한다. 재합류를
연속성 해소나 임의 Passed의 근거로 삼지 않는다. 두 세대/same-kernel fixture·독립 원본/PCAP 감사와
변조12개로 부분 검증하며 일반 host 전원/clock 복구·반복 용량·전체 system 수용은 별도다.
''';p.write_text(s)
p=Path('docs/test-plan/requirements-traceability.md');s=p.read_text().replace('Central 재기동/연속성 clear와 SYS-DIAG-001 전체 수용은 닫지 않는다.', '연속성 clear와 SYS-DIAG-001 전체 수용은 닫지 않는다.\n\nC-M9-CENTRAL-01–05는 [Central 재기동](evidence/m9_central_restart/README.md)의 명시적 issuer\n구간·fresh collector prefix import·실제 Central SDK SIGKILL/새 Epoch2·생존 source ordinal1 replay·\nSD-5001 clear 차단을 연결한다. 연속성 해소·TBD-08·전체 TC 수용은 OPEN이다.');p.write_text(s)
p=Path('docs/test-plan/README.md');s=p.read_text().replace('| 실제3-process SOME/IP', '| M9 Central process 재기동·trusted issuer 계승·fresh collector·연속성 clear 차단 | [Central 재기동 검증](evidence/m9_central_restart/README.md) |\n| 실제3-process SOME/IP');p.write_text(s)
p=Path('docs/test-plan/component-traceability.csv');s=p.read_text()+'''C-M9-CENTRAL-01,SYS-DIAG-001;SYS-SAFE-001,central/diagnostics/remote_diagnostics_context.cpp#ContextualOutbox::context,RemoteDiagnosticsContext.TrustedCentralSuccessorRequiresNewActualEpochAndReplaysWithoutHealingHistory;RemoteDiagnosticsContext.CentralLineageIsExplicitBoundedAndCannotBeLearnedFromTrafficOrReusedAcrossEpochs,Trusted epoch-bound issuer lineage;actual local credit before handover;original ordinal1 replay;mapped history remains Unknown,m9_central_restart/results.json
C-M9-CENTRAL-02,SYS-DIAG-001,central/diagnostics/diagnostics_delivery.cpp#MergedCollector::MergedCollector,DiagnosticsDelivery.FreshCollectorImportsOnlyPredecessorCommittedPrefixAndPreservesTailAndUnknown;DiagnosticsDelivery.PredecessorImportRejectsForeignRegistryAndConflictingOriginalWithoutOverwriting,Explicit old committed prefix only;old suffix retained;foreign registry and ID conflict fail closed;no recount or implicit clear,m9_central_restart/results.json
C-M9-CENTRAL-03,SYS-DIAG-001;SYS-SAFE-001,tests/integration/someip/front_adapter.cpp;tests/integration/someip/front_run.py,native-central-process-rejoin,Actual Central SIGKILL;Front/Rear PIDs unchanged;quiesced startup IO;real Epoch2 and8-role Release;original100ms protection and new normal stop/HV-off,m9_central_restart/results.json
C-M9-CENTRAL-04,SYS-DIAG-001,tests/integration/someip/native_diagnostic_routes.cpp#NativeDiagnosticRoutes::work;central/diagnostics/control_diagnostics.cpp,native-central-process-rejoin,Central lifecycle9100 and fresh issuers;old merged/replica import;fresh context/source replicas;SD5001 unverified continuity remains uncleared after successful rejoin/replay,m9_central_restart/results.json
C-M9-CENTRAL-05,SYS-DIAG-001;SYS-SAFE-001,tests/integration/diagnostics/audit_central_restart.py#judge;tests/integration/diagnostics/audit_central_restart.py#mutations,native-central-restart-audit;native-central-mutations12,Two original8-role ACK axes and18 actual credits;new SDK client ACKs all surviving source ordinals;exact source/replica/merged;old tail/lifecycle/clear/physics audited,m9_central_restart/results.json
''';p.write_text(s)
p=Path('docs/roadmap.md');s=p.read_text().replace('다음은 Central process 재기동·연속성 reconciliation/clear·native fault matrix와 원인 연결/복구·', '[Central process 재기동](test-plan/evidence/m9_central_restart/README.md)은 명시적 issuer 계승·\nfresh collector prefix import·생존 source 재전송·미확인 연속성 clear 차단을 연결한다.\n다음은 연속성 reconciliation/clear·native fault matrix와 원인 연결/복구·');p.write_text(s)
p=Path('docs/project-status.md');s=p.read_text().replace('Front/Rear ECU 재기동의 발행자 세대·prefix 재전송·손실 미확인 표시; Central 재기동·연속성 조정 후속', 'Central/Front/Rear ECU 재기동·발행자 계승·prefix 재전송·손실 미확인; 연속성 조정 후속').replace('다음은 Central process 재기동·연속성 reconciliation/clear와 다른 native 고장 조합·원인 연결/복구다.', 'Central process 재기동도 명시적 issuer 구간과 fresh collector에 연결했다. 생존 Front/Rear의\n원본 producer/sequence는 유지하며 실제 Epoch2/credit 뒤 원형 prefix를 재전송한다. 이전 저장소와\nsuffix를 보존하고 새 Central의 SD-5001은 정상 복귀/replay 뒤에도 clear를 막는다.\n[Central 재기동·원본·분모·실패](test-plan/evidence/m9_central_restart/README.md)를 따른다.\n다음은 연속성 reconciliation/clear와 다른 native 고장 조합·원인 연결/복구다.');p.write_text(s)
