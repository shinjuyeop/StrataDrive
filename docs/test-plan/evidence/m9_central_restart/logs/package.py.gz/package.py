from pathlib import Path
import datetime,gzip,hashlib,json,platform,runpy,shutil,subprocess,sys,tarfile,xml.etree.ElementTree as ET
root=Path.cwd();raw=root/'build/m9-central-restart';out=root/'docs/test-plan/evidence/m9_central_restart'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def junit(name):
 rows=ET.parse(raw/name).getroot().findall('.//testcase');bad=[r.attrib['name'] for r in rows if any(r.find(k) is not None for k in ('failure','error','skipped'))]
 return {'passed':len(rows)-len(bad),'total':len(rows),'failed':bad}
def archive(src):
 with (out/(src.name+'.tar.gz')).open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:
   with tarfile.open(mode='w',fileobj=z) as t:t.add(src,arcname=src.name)
def gzcopy(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 with dst.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(src.read_bytes())
sys.path.insert(0,str(root/'tests/integration/diagnostics'))
auditors={k:runpy.run_path(str(root/'tests/integration/diagnostics'/file)) for k,file in [('routing','audit_native_routing.py'),('adoption','audit_native_adoption.py'),('central','audit_central_restart.py')]}
results={'scope':'Actual Central full ECU/SDK SIGKILL; explicit trusted issuer succession; committed predecessor prefix import into fresh stores; surviving source replay; unverified continuity stays uncleared. Reconciliation/clear/native4ms/Target/TBD08/M9/learner acceptance OPEN','core_nonwall':junit('core.xml'),'wall':junit('wall.xml'),'asan_ubsan':junit('asan.xml'),'component':{'passed':40,'total':40},'static':{'clang_tidy_tus':5,'cppcheck_tus':5,'result':'PASS','clang_standard_headers':'GCC11 matches actual compiler'},'release_build_testing_off':'PASS with explicit SDK pilot opt-in retained','fingerprint_tests':2,'functional':{},'attempts':[]}
results['central_outcomes']=json.loads((raw/'central-outcomes.json').read_text())
for mode in ('normal','asan','tsan'):
 directory=raw/('final-'+mode);rows=json.loads((directory/'results.json').read_text());reports=[];store_counts={}
 for row in rows:
  kind='central' if row['case']=='central-process-rejoin' else 'adoption' if row['case'].endswith('process-rejoin') else 'routing'
  case='central-rejoin-1' if kind=='central' else 'restart-live-1' if kind=='adoption' else 'normal-1' if row['case']=='normal' else 'command-loss-1'
  p=directory/row['case']/case;result=json.loads((p/'result.json').read_text());original=Path(result['diagnostic_storage']['path']);copy=p/'native-diagnostics';count=0
  for f in original.rglob('*'):
   if f.is_file():assert sha(f)==sha(copy/f.relative_to(original)),f;count+=1
  assert count==sum(f.is_file() for f in copy.rglob('*'));store_counts[row['case']]=count
  plan=json.loads((directory/row['case']/'plan.json').read_text())
  for name,expected in plan['source_sha256'].items():assert sha(root/name)==expected,(mode,row['case'],name)
  assert sha(root/f'build/m5-someip-{mode}/project/tests/integration/someip/someip_front_adapter')==plan['binary_sha256']
  if row['exit']==row['audit_exit']==0:
   api=auditors[kind];data=api['load'](p);report=api['judge'](data);report.update(mutations_rejected=api['mutations'](data),case=row['case'],original_store_files_compared=count);reports.append(report)
  results['attempts'].append({'cohort':'final-'+mode,**{k:row[k] for k in ('case','exit','audit_exit')}})
 results['functional'][mode]={'passed':len(reports),'total':len(rows),'reports':reports,'archive':directory.name+'.tar.gz','all_case_original_store_files_compared':store_counts}
 archive(directory)
for name in ('probe-central','probe-ingress','before-build-fix','before-ingress-fix','before-runner-validation'):archive(raw/name)
for name in ('probe-central','probe-ingress'):
 r=json.loads((raw/name/'central-rejoin-1/result.json').read_text());results['attempts'].append({'cohort':name,'case':r['case'],'pass':r['pass'],'error':r.get('error'),'forced_cleanup':r['forced_cleanup']})
results['mutations_rejected']=sum(r['mutations_rejected'] for c in results['functional'].values() for r in c['reports'])
results['prior_evidence']={}
for sums in sorted((root/'docs/test-plan/evidence').glob('m9_*/SHA256SUMS')):
 if sums.parent==out:continue
 lines=sums.read_text().splitlines()
 for line in lines:
  expected,name=line.split('  ',1);assert sha(sums.parent/name)==expected,(sums,name)
 results['prior_evidence'][sums.parent.name]=len(lines)
(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
for p in raw.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.xml','.py'):gzcopy(p,out/'logs'/(p.name+'.gz'))
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
names={n for n in changed if not n.startswith('docs/test-plan/evidence/')};names.update(['docs/development-guide.md','tests/integration/diagnostics/audit_control_diagnostics.py','tests/integration/diagnostics/audit_someip_diagnostics.py','tests/integration/diagnostics/audit_native_routing.py','tests/integration/diagnostics/audit_native_adoption.py','interfaces/someip/owner_transport.hpp'])
overlay={}
for name in sorted(names):
 p=root/name
 if p.is_file():
  dest=out/'sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);overlay[name]=sha(p)
configs={};binaries={};sdk={}
for mode,directory in [('core-normal','build/m1-angle'),('core-asan','build/m1-angle-sanitized'),('release','build/m9-someip-release')]+[(f'sdk-{m}',f'build/m5-someip-{m}/project') for m in ('normal','asan','tsan')]:
 p=root/directory/'CMakeCache.txt';gzcopy(p,out/f'CMakeCache-{mode}.txt.gz');configs[mode]=sha(p)
for mode in ('normal','asan','tsan'):
 p=root/f'build/m5-someip-{mode}/project/tests/integration/someip/someip_front_adapter';binaries[str(p.relative_to(root))]=sha(p)
 lib=(root/f'build/m5-someip-{mode}/install/lib/libvsomeip3.so').resolve();symbols=subprocess.check_output(['nm','-D',str(lib)],text=True);sdk[mode]={'library':str(lib),'sha256':sha(lib),'tsan_instrumented':'__tsan_' in symbols,'asan_instrumented':'__asan_' in symbols}
assert sdk['asan']['asan_instrumented'] and sdk['tsan']['tsan_instrumented']
for name in ('build/m1-angle/diagnostics_delivery_test','build/m1-angle/remote_diagnostics_context_test','build/m1-angle-sanitized/diagnostics_delivery_test','build/m1-angle-sanitized/remote_diagnostics_context_test','build/m9-someip-release/libremote_diagnostics_context.a'):binaries[name]=sha(root/name)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_overlay_sha256':overlay,'build_inputs_fingerprint':runpy.run_path(str(root/'tests/integration/runtime/check_m4_async.py'))['fingerprint'](),'binary_sha256':binaries,'sdk':sdk,'sdk_source_commit':subprocess.check_output(['git','-C','build/m5-someip-deps/vsomeip','rev-parse','HEAD'],text=True).strip(),'cmake_cache_sha256':configs,'platform':platform.platform(),'tools':{cmd[0]:subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT).strip() for cmd in [['c++','--version'],['cmake','--version'],['clang-tidy','--version'],['cppcheck','--version'],['python3','--version']]},'scope':results['scope'],'asan_selector':'Diagnostic|^NativePower\\.|ControlRecoverySil|Session|M4|RemoteLeaf|RemoteZone|SomeipRearBinding|PeerFixture|RemoteIssuer|RemoteEgress','clang_tidy_header_args':['-nostdinc++','-isystem/usr/include/c++/11','-isystem/usr/include/x86_64-linux-gnu/c++/11','-isystem/usr/include/c++/11/backward']}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(out/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(out)}\n' for p in files))
print(json.dumps({'files':len(files),'overlay':len(overlay),'native':{k:(v['passed'],v['total']) for k,v in results['functional'].items()},'attempts':len(results['attempts']),'mutations':results['mutations_rejected'],'core':results['core_nonwall'],'wall':results['wall'],'asan':results['asan_ubsan']}))
