import copy
import errno
import json
import os
import resource
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from endurance_host_v1 import ENV,command,validate,owner_command,check_owner


class HostTests(unittest.TestCase):
    def test_model_setup_restores_observer_and_workers_inherit_pipeline(self):
        import threading
        from endurance_host_v1 import pipeline_setup
        allowed = os.sched_getaffinity(0)
        cpu = max(allowed)
        plan = dict(renderer=[cpu])
        try:
            with patch.dict(os.environ, {ENV: json.dumps(plan)}):
                with self.assertRaisesRegex(RuntimeError, 'fixture'):
                    with pipeline_setup() as selected:
                        self.assertEqual(selected, [cpu])
                        observed = []
                        thread = threading.Thread(target=lambda: observed.append(os.sched_getaffinity(0)))
                        thread.start(); thread.join(2)
                        self.assertFalse(thread.is_alive())
                        self.assertEqual(observed, [{cpu}])
                        raise RuntimeError('fixture')
                self.assertEqual(os.sched_getaffinity(0), allowed)
        finally:
            os.sched_setaffinity(0, allowed)

    def test_explicit_thread_policy_overrides_completed_backend_initialization(self):
        import cv2
        from types import SimpleNamespace
        from endurance_host_v1 import configure_pipeline_threads
        before=cv2.getNumThreads()
        try:
            cv2.setNumThreads(4)
            backend=SimpleNamespace(resize=SimpleNamespace(threads=4))
            configure_pipeline_threads(backend,2,1)
            self.assertEqual(cv2.getNumThreads(),2);self.assertEqual(backend.resize.threads,1)
            with self.assertRaises(ValueError):configure_pipeline_threads(backend,16,1)
        finally:cv2.setNumThreads(before)

    def test_pipeline_can_be_separate_but_cannot_share_an_smt_core(self):
        topology={c:(0,c%8) for c in range(16)}
        plan=dict(owner=[2,3,10,11],native=[1,9],renderer=[4,5,12,13],observer=[0,8],pipeline=[6,7,14,15])
        self.assertEqual(validate(plan,set(range(16)),topology),plan)
        with self.assertRaises(ValueError):validate(dict(plan,pipeline=[4,14]),set(range(16)),topology)
        with patch.dict(os.environ,{ENV:json.dumps(plan)}):
            self.assertEqual(command('pipeline',['worker'])[2],'6,7,14,15')
        del plan['pipeline']
        with patch.dict(os.environ,{ENV:json.dumps(plan)}):
            self.assertEqual(command('pipeline',['worker'])[2],'4,5,12,13')

    def test_owner_scheduler_is_explicit_and_verified(self):
        resources=dict(owner_scheduler=dict(policy='SCHED_RR',priority=8))
        self.assertEqual(owner_command({},['server']),['server'])
        self.assertEqual(owner_command(resources,['server']),['chrt','-r','8','server'])
        with patch('endurance_host_v1.os.sched_getscheduler',return_value=os.SCHED_OTHER):
            with self.assertRaises(ValueError):check_owner(resources,os.getpid())

    @unittest.skipUnless(resource.getrlimit(resource.RLIMIT_RTPRIO)[0]>=8,'host does not grant owned RR8')
    def test_optional_owned_realtime_exec(self):
        resources=dict(owner_scheduler=dict(policy='SCHED_RR',priority=8))
        command=owner_command(resources,[sys.executable,'-c','import os,json;print(json.dumps([os.sched_getscheduler(0),os.sched_getparam(0).sched_priority]))'])
        self.assertEqual(json.loads(subprocess.check_output(command,text=True)),[os.SCHED_RR,8])

    def test_roles_cannot_share_a_core_even_through_smt(self):
        plan=dict(owner=[0,4],native=[1,5],renderer=[2,6],observer=[3,7])
        topology={c:(0,c%4) for c in range(8)}
        self.assertEqual(validate(plan,set(range(8)),topology),plan)
        for invalid in (dict(plan,observer=[4]),dict(plan,observer=[3,6]),
                        dict(plan,observer=[8]),dict(plan,observer=[])):
            with self.assertRaises(ValueError):validate(invalid,set(range(8)),topology)
        invalid=copy.deepcopy(plan);del invalid['native']
        with self.assertRaises(ValueError):validate(invalid,set(range(8)),topology)

    def test_exec_placement_preserves_arguments_and_applies_affinity(self):
        cpu=min(os.sched_getaffinity(0));argv=[sys.executable,'-c','import os;print(sorted(os.sched_getaffinity(0)))']
        with patch.dict(os.environ,{ENV:json.dumps(dict(native=[cpu]))}):
            actual=command('native',argv)
            self.assertEqual(actual[3:],argv)
            self.assertEqual(json.loads(subprocess.check_output(actual,text=True)),[cpu])
        with patch.dict(os.environ,{},clear=True):self.assertEqual(command('native',argv),argv)

    def test_cross_device_seal_verifies_and_retains_original(self):
        from endurance_recording_v1 import ShardRecorder
        from seal_endurance_v1 import seal
        from check_endurance_archive_v1 import checked_members
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);run=root/'run';folder=run/'capture/paired/renderer'
            recorder=ShardRecorder(folder,2,1_000_000)
            recorder.offer(dict(frame=1,width=4,height=4),bytes(64));self.assertTrue(recorder.close())
            (folder/'result.json').write_text(json.dumps(dict(raw=recorder.report()['records'])))
            prior=root/'prior.json';prior.write_text(json.dumps(dict(count=0,rgb_sha256=[])))
            bundle=root/'bundle'
            with patch('seal_endurance_v1.os.link',side_effect=OSError(errno.EXDEV,'fixture')):
                self.assertEqual(seal(run,bundle,prior)['raw_packets'],1)
            manifest=json.loads((bundle/'raw-manifest.json').read_text())['archives'][0]
            source=run/manifest['original'];target=bundle/manifest['archive']
            self.assertNotEqual(source.stat().st_ino,target.stat().st_ino)
            self.assertEqual(source.read_bytes(),target.read_bytes());checked_members(target,manifest)


if __name__=='__main__':unittest.main()
