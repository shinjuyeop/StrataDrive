from pathlib import Path
import hashlib,json,tarfile
base=Path('build/milestone-followup');out=Path('docs/test-plan/evidence/milestone-followup')
root=base/'native';rows=json.loads((root/'results.json').read_text());assert len(rows)==3 and all(r['passed'] for r in rows)
files={str(p.relative_to(root)):dict(size=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob('*')) if p.is_file()}
with tarfile.open(out/'native.tar.gz','w:gz') as tar:
 for name in files:tar.add(root/name,arcname=name,recursive=False)
with tarfile.open(out/'native.tar.gz','r:gz') as tar:
 for m in tar:
  data=tar.extractfile(m).read();assert len(data)==files[m.name]['size'] and hashlib.sha256(data).hexdigest()==files[m.name]['sha256']
(out/'native-files.json').write_text(json.dumps(files,indent=2)+'\n');(out/'native-results.json').write_text(json.dumps(rows,indent=2)+'\n')
print('native files verified:',len(files),flush=True)
