from pathlib import Path
import json
out=Path('docs/test-plan/evidence/milestone-followup');a=json.loads((out/'acceptance.json').read_text());assert a['status']=='PASS_BOUNDED_M8_BRAKING_M9_STORAGE'
p=out/'README.md';s=p.read_text().replace('**Host component/native 검증 PASS; 새 CARLA S03 판정 진행 중.**','**PASS — 방향별 배분 피드백의 고정 S03 기능 검증과 유한 journal 오류/중단 검증.**')
s=s.replace('| 새 CARLA S03 | 진행 중 |','| 새 CARLA S03 | 새 서버1회·physics/EV각8000·schema3·route손상28/selection손상18 거부·서버130 종료 |')
s=s.replace('## 보존한 개발 실패','''새 CARLA의 body plateau 최대오차는30km/h에서0.077184km/h,20km/h에서0.027828km/h,
정지 window 오차0, 양수 목표 최대 overspeed3.483045%다. 경로1333표본·누락0,
횡오차P95 0.034105m·heading P95 0.534945°로 기존 기준을 통과했다.
8000개 solver-work와 단일 EV 정산·원본 native Actual/권한 감사 및 각각의 손상 거부를
통과했다. 이 실행의 실제 음수 적분 보류는2회다. [경로 감사](carla/audit_m8_route.json),
[PI/배분 감사](carla/audit_m8_saturation-mutations.json), [work/EV 감사](carla/audit_m7_1r_work.json)를
따른다. S03의 terminal wheel hold를 NormalStop/HV-off 수용으로 해석하지 않는다.
기존 renderer/cold-load 원인이 해결됐다고 주장하지 않는다.

## 보존한 개발 실패''')
s=s.replace('CARLA 결과와 전체 checksum은 실행 완료 후 기록한다.','''`carla/S03/trace.jsonl.gz`는 Git LFS의 실제 새 physics 원본이며 result/events/route와
server report·독립 감사를 함께 보존했다. `carla-runtime.tar.gz`에는 실행된 native binary와
probe snapshot·server/client/readiness 로그가 있다. 원본 raw 파일과 archive member를
다시 비교했으며 [최종 판정](acceptance.json)과 [SHA256SUMS](SHA256SUMS)를 따른다.
`sources.json`은 모델 v3와 정확한 Git 추적 예외도 포함한다. 원래 runtime capture는
`runtime-sources.json`에 보존하고 모델 SHA를 실제 비교 verdict와 대조했다.
`documentation.json`/`documentation.tar.gz`는 최종 문서 snapshot이다.''');p.write_text(s)
p=Path('docs/project-status.md');s=p.read_text().replace('독립 모델 동등성, 실제 allocator 연결, 저장 오류/프로세스 중단과\n복원 실패 경계는','독립 모델 동등성, 실제 allocator 연결, 저장 오류/프로세스 중단과\n복원 실패 경계·새 CARLA S03 8000구간은')
s=s.replace('저장된 S03의 native 재생은 새 CARLA 물리 실행이 아니며, 실제 전원 차단/자동 용량 회수와','저장된 S03의 native 재생과 새 서버 S03 실제 실행을 따로 기록했다. 실제 전원 차단/자동 용량 회수와')
s=s.replace('제동 피드백 v3는 component/원본 입력 재생까지 검증했으며 새 CARLA 물리 수용은 별도다.','제동 피드백 v3는 component/원본 입력 재생과 새 고정 S03 실행을 통과했다. 전체 ODD 수용은 별도다.');p.write_text(s)
p=Path('docs/roadmap.md');s=p.read_text().replace('제동 피드백 v3의 component/입력 재생','제동 피드백 v3의 component/입력 재생·새 S03').replace('동적 가용력 기반 참조·v3 새 물리 수용 OPEN','동적 가용력 기반 참조·전체 ODD OPEN');p.write_text(s)
p=Path('docs/interfaces/simple-vehicle-model.md');s=p.read_text().replace('[component·원본 입력 재생 근거]','[component·원본 입력 재생·새 S03 근거]').replace('전체 도로/동적 참조 또는 새 CARLA 물리 실행의 수용이 아니다.','새 CARLA 고정 S03 8000구간도 기존 기준을 통과했다. 전체 도로/동적 참조 수용은 별도다.');p.write_text(s)
p=Path('docs/interfaces/carla-plant-adapter.md');s=p.read_text().replace('아래 기존 S03 실제 주행 근거는 schema2이며, v3 입력 재생과 새 물리 수용을 구분한다.','아래 기존 S03 실제 주행 근거는 schema2다. [v3 후속](../test-plan/evidence/milestone-followup/README.md)은\n입력 재생과 새 서버의 고정 S03 8000구간을 각각 검증했으며 전체 ODD로 확대하지 않는다.');p.write_text(s)
p=Path('docs/archive/design-decisions.md');s=p.read_text().replace('Trace/result schema3와 독립 감사로 변경을 명시한다. 새 CARLA 물리 수용은 별도다.','Trace/result schema3와 독립 감사로 변경을 명시한다. 새 CARLA 고정 S03 8000구간도\n기존 기준으로 검증했으며 전체 Reference/ODD 수용으로 확대하지 않는다.');p.write_text(s)
p=Path('docs/test-plan/component-traceability.csv');s=p.read_text().replace('speed_pi_braking_equivalence;S03-offline-directional-replay','speed_pi_braking_equivalence;S03-offline-directional-replay;S03-v3-actual-8000');p.write_text(s)
p=Path('docs/test-plan/requirements-traceability.md');s=p.read_text().replace('실제 전원 차단·무제한 보존·전체 Reference의 TC 판정은 변경하지 않는다.','새 CARLA 고정 S03 8000구간도 별도로 검증했으며 실제 전원 차단·무제한 보존·전체\nReference의 TC 판정은 변경하지 않는다.');p.write_text(s)
