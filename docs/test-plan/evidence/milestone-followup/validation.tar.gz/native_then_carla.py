from pathlib import Path
import hashlib,json,subprocess,sys,time
base=Path('build/milestone-followup')
for name in ('debug-final.log','asan-final.log'):
 assert '100% tests passed, 0 tests failed' in (base/name).read_text(),name
assert '\nOK\n' in (base/'python-final.log').read_text()
assert 'error:' not in (base/'static/cppcheck-final.log').read_text()
assert 'warning:' not in (base/'static/cppcheck-final.log').read_text()
changed=subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
sources={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(set(changed)) if not p.startswith('docs/') and Path(p).is_file()}
identity=dict(baseline=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),sources=sources)
(base/'sources.json').write_text(json.dumps(identity,indent=2)+'\n')
binary=Path('build/m5-someip-normal/project/tests/integration/someip/someip_front_adapter');digest=hashlib.sha256(binary.read_bytes()).hexdigest()
out=base/'native';out.mkdir(exist_ok=False);cases=[('normal',None,0),('ack-loss','ack-loss',1),('stop-ack-loss','stop-ack-loss',1)]
(out/'protocol.json').write_text(json.dumps(dict(cases=cases,sources=identity,binary_sha256=digest,scope='journal intent followup; fixed three-case native functional smoke'),indent=2)+'\n')
rows=[]
for name,fault,expected in cases:
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
 command=[sys.executable,'tests/integration/someip/front_run.py',str(out/name),'--profile','normal','--three','--simple-vehicle','--diagnostics','--diagnostic-service','--isolated-ecus','--cases','central-rejoin','--split-owner-io','--separate-aux-io','--owner-fifo','--sdk-fifo','--sdk-io-threads','2']
 if fault:command+=['--service-fault',fault]
 with (out/(name+'.runtime.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(name=name,command=command,runtime_exit=code,expected_runtime_exit=expected,audits=[]));(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,'runtime',code,'expected',expected,flush=True)
(out/'runtime-complete.json').write_text(json.dumps(dict(runtimes=3,monotonic_ns=time.monotonic_ns()))+'\n')
for row in rows:
 readers=['audit_native_service' if row['name']=='normal' else 'audit_native_service_faults','audit_service_ordering','audit_service_timing','audit_service_response']
 for reader in readers:
  command=[sys.executable,'tests/integration/diagnostics/'+reader+'.py',str(out/row['name']/'central-rejoin-1'),'--mutations']
  with (out/(row['name']+'.'+reader+'.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
  row['audits'].append(dict(tool=reader,exit=code))
 row['passed']=row['runtime_exit']==row['expected_runtime_exit'] and all(r['exit']==0 for r in row['audits']);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['name'],'audits',row['passed'],flush=True)
carla=base/'carla';carla.mkdir(exist_ok=False)
command=[sys.executable,'tests/integration/carla/m7_1o_run.py','--engine','/d/shin/stratadrive-tools/UnrealEngine_4.26','--source','/d/shin/stratadrive-tools/m7-source/carla-0.9.16','--python','/d/shin/stratadrive-tools/m7-source/m7-nodrive-venv/bin/python','--fixture','/d/shin/stratadrive-tools/m7-source/m7-1m-fixture','--runtime',str(carla/'runtime'),'--output',str(carla/'S03'),'--native-actual','build/m7-functional/tests/integration/carla/m7_1g/m7_wheel_shadow','--vehicle-substeps','320','--solver-work','--held-steer-sleep','--simulation-continuous','--route-profile','tests/integration/carla/scenarios/m8_combined_v2.json','--route-startup-seconds','600','--ticks','8000','--propulsion-aware']
record=dict(command=command,sources=identity,started_ns=time.monotonic_ns(),native_sha256=hashlib.sha256(Path('build/m7-functional/tests/integration/carla/m7_1g/m7_wheel_shadow').read_bytes()).hexdigest())
(carla/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print('CARLA S03 starting',flush=True)
with (carla/'runner.log').open('w') as log:record['runtime_exit']=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
record['completed_ns']=time.monotonic_ns();record['audits']=[]
(carla/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print('CARLA runtime',record['runtime_exit'],flush=True)
for reader,args in [('audit_m8_route',['--case','nominal']),('check_m8_route_corruptions',[]),('audit_m8_saturation',['--mutations']),('audit_m7_1r_work',[])]:
 name=reader+('-mutations' if '--mutations' in args else '')
 cmd=[sys.executable,'tests/integration/carla/'+reader+'.py',str(carla/'S03'),'--output',str(carla/(name+'.json')),*args]
 with (carla/(name+'.log')).open('w') as log:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 record['audits'].append(dict(command=cmd,exit=code));(carla/'execution.json').write_text(json.dumps(record,indent=2)+'\n');print(name,code,flush=True)
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==v for p,v in sources.items()),'source changed during runtime'
raise SystemExit(not (all(row['passed'] for row in rows) and record['runtime_exit']==0 and all(r['exit']==0 for r in record['audits'])))
