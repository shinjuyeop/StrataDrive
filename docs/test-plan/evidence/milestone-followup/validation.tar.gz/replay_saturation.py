from pathlib import Path
import copy,gzip,hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tests/integration/carla').resolve()))
from evidence_io import json_rows
from audit_m8_saturation import audit,mutations
base=Path('build/milestone-followup');out=base/'saturation-replay';out.mkdir(exist_ok=False)
source=Path('docs/test-plan/evidence/m8_saturation/S03');result=json.loads((source/'result.json').read_text());result['allocation_feedback_schema']=3
result['followup_scope']='offline original acquisition replay; no new physics execution'
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n')
binary=Path('build/m7-functional/tests/integration/carla/m7_1g/m7_wheel_shadow').resolve()
command=[str(binary),'--native-solver-work','1','42','7',str(result['binding']['actor']),'--sim-horizon-ms','80000','--route',str((source/'route.txt').resolve())]
keys=('now_ns','speed_control','allocation_selection','speed_selection','saturation_used','braking_saturation_used','allocation_feedback_schema','native_export')
count=changed=0;original=hashlib.sha256();actual=hashlib.sha256()
canonical=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n'
with (out/'stderr.txt').open('w') as err,gzip.open(out/'trace.jsonl.gz','wt') as saved:
 p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
 try:
  for row in json_rows(source/'trace.jsonl'):
   for key in ('work_input','pose_input','native_input'):
    if row.get(key):p.stdin.write(row[key]+'\n')
   p.stdin.flush();received=json.loads(p.stdout.readline());prior=copy.deepcopy(received)
   for key in ('allocation_feedback_schema','braking_saturation_used'):prior.pop(key,None)
   for key in ('allocation_selection','speed_selection'):
    if prior.get(key):
     for k in ('requested_braking_nm','selected_braking_nm','braking_limited'):prior[key].pop(k)
   before=canonical(row['native']);after=canonical(prior);original.update(before);actual.update(after);changed+=before!=after;count+=1
   saved.write(json.dumps(dict(native={k:received[k] for k in keys if k in received}),allow_nan=False)+'\n')
  p.stdin.close();code=p.wait(timeout=10)
  if code!=0 or count!=8001:raise ValueError((code,count))
 finally:
  if p.poll() is None:p.kill();p.wait()
report=dict(command=command,binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),source=str(source),
 source_trace_sha256=hashlib.sha256((source/'trace.jsonl.gz').read_bytes()).hexdigest(),observations=count,
 changed_legacy_observations=changed,original_canonical_sha256=original.hexdigest(),replayed_legacy_canonical_sha256=actual.hexdigest(),
 audit=audit(out),mutations=mutations(out),legacy_audit=audit(source),scope='offline only')
(base/'saturation-replay.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
