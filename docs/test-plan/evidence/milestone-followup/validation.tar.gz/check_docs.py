from pathlib import Path
import re,subprocess,json,unicodedata
files=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
files=sorted(Path(p) for p in files if p.endswith('.md') and (not p.startswith('docs/test-plan/evidence/') or p.startswith('docs/test-plan/evidence/milestone-followup/')))
def anchors(path):
 text=path.read_text();seen={};result=set(re.findall(r'<a\s+(?:id|name)=["\x27]([^"\x27]+)',text))
 for heading in re.findall(r'^#{1,6}\s+(.+)',text,re.M):
  slug=re.sub(r'[^\w\s-]','',heading.strip().lower()).replace(' ','-')
  n=seen.get(slug,0);seen[slug]=n+1;result.add(slug+(f'-{n}' if n else ''))
 return result
bad=[];checked=0
for path in files:
 for dest in re.findall(r'\]\(([^)]+)\)',path.read_text()):
  if '://' in dest or dest.startswith(('mailto:','data:')):continue
  name,sep,anchor=dest.partition('#');target=path.parent/name if name else path
  checked+=1
  if not target.exists():bad.append(dict(source=str(path),target=dest,error='missing file'))
  elif anchor and target.suffix=='.md' and anchor not in anchors(target):bad.append(dict(source=str(path),target=dest,error='missing anchor'))
report=dict(files=len(files),links=checked,errors=bad);Path('build/milestone-followup/docs-links.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n');print(json.dumps(report,ensure_ascii=False));raise SystemExit(bool(bad))
