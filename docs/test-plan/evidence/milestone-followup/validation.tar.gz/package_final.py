from pathlib import Path
import hashlib,json,shutil,tarfile,subprocess
base=Path('build/milestone-followup');out=Path('docs/test-plan/evidence/milestone-followup')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
execution=load(base/'carla/execution.json');assert execution['runtime_exit']==0 and len(execution['audits'])==4 and all(r['exit']==0 for r in execution['audits'])
server=load(base/'carla/server-S03.json');assert server['server_exit']==130 and server['status']=='COMPLETE_ISOLATED_RUN' and 'forced_stop' not in server
route=load(base/'carla/audit_m8_route.json');saturation=load(base/'carla/audit_m8_saturation-mutations.json');work=load(base/'carla/audit_m7_1r_work.json')
assert route['status'].startswith('PASS') and not route['failures'] and work['intervals']==8000 and work['independently_verified_settlements']==8000
assert saturation['baseline']['schema']==3 and len(saturation['mutations'])==18
runtime_identity=load(base/'sources.json');assert all(sha(p)==v for p,v in runtime_identity['sources'].items())
shutil.copyfile(base/'sources.json',out/'runtime-sources.json');identity=dict(runtime_identity);identity['sources']=dict(identity['sources'])
for p in ('models/longitudinal/model_v3.py','.gitignore','.gitattributes'):identity['sources'][p]=sha(p)
model=load(next((base/'braking').glob('*/verdict.json')));assert model['model_sha256']==identity['sources']['models/longitudinal/model_v3.py']
(out/'sources.json').write_text(json.dumps(identity,indent=2)+'\n')
with tarfile.open(out/'sources.tar.gz','w:gz') as tar:
 for p in sorted(identity['sources']):tar.add(p,arcname=p,recursive=False)
carla=out/'carla';carla.mkdir(exist_ok=False);(carla/'S03').mkdir()
for p in (base/'carla/S03').iterdir():
 if p.is_file():shutil.copyfile(p,carla/'S03'/p.name)
for p in (base/'carla').iterdir():
 if p.is_file():shutil.copyfile(p,carla/p.name)
# Preserve the executed snapshot, server/client/readiness logs and binary.
with tarfile.open(out/'carla-runtime.tar.gz','w:gz') as tar:
 for p in sorted((base/'carla/runtime').rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(base/'carla/runtime')),recursive=False)
with tarfile.open(out/'validation.tar.gz','w:gz') as tar:
 for p in sorted(base.rglob('*')):
  if p.is_file() and p.relative_to(base).parts[0] not in ('native','carla') and '__pycache__' not in p.parts:
   tar.add(p,arcname=str(p.relative_to(base)),recursive=False)
checks={}
for directory,archive in ((base/'carla/runtime','carla-runtime.tar.gz'),):
 with tarfile.open(out/archive,'r:gz') as tar:
  for member in tar:
   data=tar.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==sha(directory/member.name)
   checks[archive]=checks.get(archive,0)+1
for p in (base/'carla/S03').iterdir():
 if p.is_file():assert sha(p)==sha(carla/'S03'/p.name)
for name in ('debug-final.log','asan-final.log'):assert '100% tests passed, 0 tests failed' in (base/name).read_text()
assert '\nOK\n' in (base/'python-final.log').read_text()
native=load(out/'native-results.json');assert len(native)==3 and all(r['passed'] for r in native)
result=dict(status='PASS_BOUNDED_M8_BRAKING_M9_STORAGE',baseline=identity['baseline'],tests=dict(debug=1478,asan_ubsan=137,python=280,syscall_boundaries=23),
 model_comparison_events=model['comparison']['events'],model_max_absolute_errors=model['comparison']['max_absolute_errors'],synthetic_braking=model['synthetic_plant'],
 native=dict(cases=3,expected_refusals=2,responses=load(out/'native-response-summary.json'),archived_files=len(load(out/'native-files.json'))),
 carla=dict(actual_server_runs=1,physics_intervals=8000,ev_settlements=8000,server_exit=130,route=route,saturation=saturation['baseline'],saturation_mutations=18,work_status=work['status'],native_audit=work['native_actual_audit']),
 runtime_archive_verified_files=checks,remaining=['historical M3/M4 causal evidence and nonselected DDS','general CARLA renderer/GC/cold shutdown','dynamic force reference and full ODD','automatic journal rollover/state transfer/reclamation','real power-cut/media/other-kernel/Target','whole wall real time and learner final review'])
(out/'acceptance.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],archive_checks=checks,carla=result['carla'])),flush=True)
