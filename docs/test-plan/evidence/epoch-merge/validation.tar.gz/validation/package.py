from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil,xml.etree.ElementTree as ET
root=Path('.').resolve();work=root/'build/epoch-merge-recovery';out=root/'docs/test-plan/evidence/epoch-merge'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def archive(path,items):
    with tarfile.open(path,'w:gz') as tar:
        for item,name in items:tar.add(item,arcname=str(name))
files=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
sources=sorted(p for p in files if not p.startswith('docs/') and (root/p).is_file())
meta=[dict(path=p,sha256=sha(root/p)) for p in sources]
(out/'sources.json').write_text(json.dumps(meta,indent=2)+'\n')
archive(out/'sources.tar.gz',[(root/p,p) for p in sources])
shutil.copyfile(work/'merge-audit-final.json',out/'merge-audit.json')
archive(out/'someip.tar.gz',[(work/p,p) for p in ('someip','someip-frozen','someip-backoff','someip-final')])
logs=[(p,Path('validation')/p.name) for p in sorted(work.iterdir()) if p.is_file()]
for build in ('m1-angle','m1-angle-sanitized','m5-someip-normal/project'):
    for name in ('CMakeCache.txt','compile_commands.json'):
        p=root/'build'/build/name
        if p.exists():logs.append((p,Path('build-config')/build/name))
archive(out/'validation.tar.gz',logs)
reg=ET.parse(work/'regression.xml').getroot();assert int(reg.attrib['tests'])==1538 and int(reg.attrib['failures'])==0
san=list(work.glob('asan-*.xml'));assert all(int(ET.parse(p).getroot().attrib['failures'])==0 for p in san)
count=sum(int(ET.parse(p).getroot().attrib['tests']) for p in san);assert count==99
assert all(r['exit']==0 for r in json.loads((work/'asan-results.json').read_text()))
assert all(r['exit']==0 for r in json.loads((work/'tidy-results.json').read_text()))
assert all('warning:' not in p.read_text() and 'error:' not in p.read_text() for p in work.glob('tidy-*.log'))
assert 'Ran 280 tests' in (work/'python.log').read_text() and (work/'python.log').read_text().rstrip().endswith('OK')
cohorts=[dict(name=p,result=json.loads((work/p/'epoch-merge-restart/result.json').read_text())) for p in ('someip','someip-frozen','someip-backoff','someip-final')]
assert [c['result']['pass'] for c in cohorts]==[False,False,True,True]
binaries=['build/m1-angle/diagnostics_delivery_test','build/m1-angle/remote_diagnostics_context_test','build/m5-someip-normal/project/tests/integration/someip/someip_epoch_merge_live']
acceptance=dict(passed=True,base_commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
    scope='Fixed-membership epoch merge and frozen native Central/Front/Rear original events over real SOME/IP',
    debug=dict(tests=1538,failures=0,excluded_label='runtime.wall'),sanitized=dict(tests=count,asan=True,ubsan=True,tsan=False),
    python_tests=280,clang_tidy_units=4,someip=json.loads((out/'merge-audit.json').read_text()),cohorts=cohorts,
    binaries=[dict(path=p,sha256=sha(root/p)) for p in binaries],
    remaining=['Dynamic producer membership and old-prefix closure evidence','Live native runtime Central spool/context/family migration',
               'CARLA supervised recovery driving and application epoch transition','Single-epoch rollover and disk lifecycle','Whole ODD/wall/Target and trained model'])
(out/'acceptance.json').write_text(json.dumps(acceptance,indent=2)+'\n')
print(json.dumps(dict(source_files=len(meta),sanitized=count,artifacts=[dict(name=p.name,bytes=p.stat().st_size) for p in sorted(out.iterdir())]),indent=2))
