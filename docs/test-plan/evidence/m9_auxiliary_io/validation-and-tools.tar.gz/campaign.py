from pathlib import Path
import csv,hashlib,json,os,subprocess,threading,time,tarfile
root=Path.cwd();base=root/'build/m9-aux-io';out=base/'subscribed-campaign'
assert not out.exists()
meta={'clock':'CLOCK_MONOTONIC','observer_cpu':0,'sample_interval_ns':10000000,'limit':500000,'cpu':{}}
for i in range(1,8):
 p=Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq')
 meta['cpu'][i]={n:(p/n).read_text().strip() for n in ['scaling_driver','scaling_governor','scaling_min_freq','scaling_max_freq','energy_performance_preference']}
meta['command']=['python3','tests/integration/someip/service_timing_campaign.py','--split-owner-io','--owner-fifo','--separate-aux-io','--tsan-repeats','3','--response-audit','--defer-audits',str(out)]
samples=[];errors=[];stopped=threading.Event()
def observe():
 try:
  os.sched_setaffinity(0,{0});meta['actual_observer_cpus']=sorted(os.sched_getaffinity(0))
  while not stopped.is_set() and not (out/'runtime-complete.json').exists():
   begin=time.monotonic_ns();values=[int(Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_cur_freq').read_text()) for i in range(1,8)]
   values+=[int(Path('/sys/devices/system/cpu/cpu0/thermal_throttle/package_throttle_count').read_text()),int(Path('/sys/class/hwmon/hwmon4/temp1_input').read_text())]
   if len(samples)==meta['limit']:raise RuntimeError('host observation capacity')
   samples.append([begin,time.monotonic_ns(),*values]);stopped.wait(.01)
 except BaseException as e:errors.append(str(e))
observer=threading.Thread(target=observe);observer.start()
try:
 with (base/'subscribed-campaign.log').open('w') as log:result=subprocess.run(meta['command'],stdout=log,stderr=subprocess.STDOUT)
finally:
 stopped.set();observer.join()
 with (base/'subscribed-frequency.csv').open('w') as f:
  w=csv.writer(f);w.writerow(['begin_ns','end_ns',*['cpu'+str(i)+'_khz' for i in range(1,8)],'package_throttle_count','package_millidegrees']);w.writerows(samples)
 meta['errors']=errors;meta['samples']=len(samples);meta['campaign_exit']=result.returncode
 (base/'subscribed-host.json').write_text(json.dumps(meta,indent=2)+'\n')
if (out/'manifest.json').exists():
 manifest=json.loads((out/'manifest.json').read_text())
 with tarfile.open(out/'sources.tar.gz','w:gz') as t:
  for p,digest in manifest['sources'].items():
   assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest,p
   t.add(p,arcname=p)
raise SystemExit(result.returncode or int(bool(errors)))
