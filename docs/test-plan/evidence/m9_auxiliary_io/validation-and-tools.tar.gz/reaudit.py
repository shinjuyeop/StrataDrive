from pathlib import Path, PurePosixPath
import json, subprocess, sys, tarfile, tempfile

root=Path.cwd();out=root/'docs/test-plan/evidence/m9_auxiliary_io'
logs=out/'archive-reaudit';logs.mkdir(exist_ok=False);results=[]
with tempfile.TemporaryDirectory(prefix='sd-aux-archive-') as directory:
    extracted=Path(directory)
    selections={'subscribed-campaign':['normal-normal','tsan-normal'],
                'subscribed-regressions':['normal-close-full']}
    for cohort,names in selections.items():
        with tarfile.open(out/(cohort+'.tar.gz'),'r:gz') as archive:
            selected=[]
            for member in archive:
                path=PurePosixPath(member.name)
                if len(path.parts)<2 or path.parts[1] not in names:continue
                assert not path.is_absolute() and '..' not in path.parts
                assert member.isfile() or member.isdir()
                selected.append(member)
            archive.extractall(extracted,members=selected)
    for case,reader,expected in [('normal-normal','audit_native_service.py',0),
                                 ('normal-normal','audit_service_timing.py',0),
                                 ('normal-normal','audit_service_response.py',0),
                                 ('tsan-normal','audit_native_service.py',1),
                                 ('tsan-normal','audit_service_timing.py',0)]:
        command=[sys.executable,str(root/'tests/integration/diagnostics'/reader),
                 str(extracted/'subscribed-campaign'/case/'central-rejoin-1'),'--mutations']
        with (logs/(case+'-'+reader+'.log')).open('w') as stream:
            result=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT)
        results.append({'case':case,'reader':reader,'expected_exit':expected,'actual_exit':result.returncode})
        assert result.returncode==expected,(case,reader,result.returncode)
    sys.path.insert(0,str(root/'tests/integration/someip'))
    from sdk_outcomes import sdk_outcomes
    folder=extracted/'subscribed-regressions/normal-close-full/close-full-1'
    original=json.loads((folder/'result.json').read_text());expected,unexpected=sdk_outcomes(folder,original)
    assert expected==original['expected_sdk_faults'] and unexpected==original['unexpected_sdk_errors'] and unexpected
    results.append({'case':'normal-close-full','unexpected_sdk_error_reproduced':True,'original_pass':original['pass'],'errors':unexpected})
(out/'archive-reaudit.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
