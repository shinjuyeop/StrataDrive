from pathlib import Path
import csv, hashlib, json, os, subprocess, sys, tarfile, threading, time

root=Path.cwd();base=root/'build/m9-aux-io';out=base/'placement-comparison'
out.mkdir(exist_ok=False)
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()
files+=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files+=['interfaces/someip/owner_transport.hpp','tests/integration/someip/fixture_signals.hpp',
        'tests/integration/diagnostics/audit_native_service_faults.py',
        'tests/integration/diagnostics/audit_service_ordering.py',
        'tests/integration/diagnostics/audit_service_response.py']
files=sorted(set(files));binary=root/'build/m5-someip-tsan/project/tests/integration/someip/someip_front_adapter'
cases=[(fault,delay,layout,slot) for fault,delay in [('normal',0),('ack-loss',0),('actual-loss',0),('normal',250)]
       for slot,layout in enumerate(('shared','separate','separate','shared'),1)]
manifest={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'cases':cases,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
          'sources':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'sources.tar.gz','w:gz') as archive:
    for p in files:archive.add(root/p,arcname=p)
samples=[];errors=[];stop=threading.Event()
meta={'observer_cpu':0,'requested_interval_ns':10000000,'clock':'CLOCK_MONOTONIC',
      'sample_limit':200000,'cpu':{}}
for cpu in range(8):
    folder=Path(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq')
    meta['cpu'][cpu]={key:(folder/key).read_text().strip() for key in
                     ('scaling_driver','scaling_governor','scaling_min_freq','scaling_max_freq','energy_performance_preference')}
def observe():
    try:
        os.sched_setaffinity(0,{0});meta['actual_observer_cpus']=sorted(os.sched_getaffinity(0))
        while not stop.is_set():
            begin=time.monotonic_ns()
            values=[int(Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_cur_freq').read_text()) for i in range(8)]
            values += [int(Path('/sys/devices/system/cpu/cpu0/thermal_throttle/package_throttle_count').read_text()),
                       int(Path('/sys/class/hwmon/hwmon4/temp1_input').read_text())]
            if len(samples)>=meta['sample_limit']:raise RuntimeError('observation capacity')
            samples.append([begin,time.monotonic_ns(),*values]);stop.wait(.01)
    except BaseException as error:errors.append(repr(error))
observer=threading.Thread(target=observe);observer.start();rows=[]
try:
    for fault,delay,layout,slot in cases:
        assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binary_sha256']
        for p,digest in manifest['sources'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==digest,p
        name=f'{fault}-{delay}-{slot}-{layout}';directory=out/name
        command=[sys.executable,'tests/integration/someip/front_run.py',str(directory),'--profile','tsan',
                 '--three','--simple-vehicle','--diagnostics','--diagnostic-service','--isolated-ecus',
                 '--split-owner-io','--owner-fifo','--fixed-layout','--cases','central-rejoin']
        if layout=='separate':command+=['--separate-aux-io']
        if fault!='normal':command+=['--service-fault',fault]
        if delay:command+=['--signal-write-delay-ms',str(delay)]
        begin=time.monotonic_ns()
        with (out/(name+'.runtime.log')).open('w') as log:
            result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
        row={'name':name,'layout':layout,'fault':fault,'delay_ms':delay,'command':command,
             'begin_ns':begin,'end_ns':time.monotonic_ns(),'runtime_exit':result.returncode}
        rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
finally:
    stop.set();observer.join()
    with (out/'frequency.csv').open('w') as stream:
        writer=csv.writer(stream);writer.writerow(['begin_ns','end_ns',*[f'cpu{i}_khz' for i in range(8)],'package_throttle_count','package_millidegrees']);writer.writerows(samples)
    meta.update(errors=errors,samples=len(samples),runtime_complete_ns=time.monotonic_ns())
    (out/'host.json').write_text(json.dumps(meta,indent=2)+'\n')
for row in rows:
    scripts=['audit_native_service.py' if row['fault']=='normal' else 'audit_native_service_faults.py',
             'audit_service_ordering.py','audit_service_timing.py','audit_service_response.py']
    row['audits']={}
    for script in scripts:
        with (out/(row['name']+'.'+script+'.log')).open('w') as log:
            result=subprocess.run([sys.executable,'tests/integration/diagnostics/'+script,
                                   str(out/row['name']/'central-rejoin-1'),'--mutations'],stdout=log,stderr=subprocess.STDOUT)
        row['audits'][script]=result.returncode
    row['qualified']=not any(row['audits'].values())
    (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
raise SystemExit(int(bool(errors) or any(not row['qualified'] for row in rows)))
