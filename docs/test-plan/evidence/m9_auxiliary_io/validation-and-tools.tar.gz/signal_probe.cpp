#include "tests/integration/someip/fixture_signals.hpp"
#include <iostream>
#include <pthread.h>
#include <sched.h>
#include <time.h>
#include <unistd.h>
int main(int argc,char**) {
    std::string pattern="/tmp/sd-signal-cost-XXXXXX";auto* name=mkdtemp(pattern.data());if(!name)return 2;
    std::filesystem::path folder=name;std::atomic<clockid_t> clock{0};
    auto cpu=[&]{timespec value{};if(clock_gettime(clock.load(),&value))throw std::runtime_error("worker clock");return std::uint64_t(value.tv_sec)*1000000000+value.tv_nsec;};
    std::uint64_t used=0;
    {
        stratadrive::someip::test::FixtureSignals signals(folder,"central-2",[&]{
            cpu_set_t mask;CPU_ZERO(&mask);CPU_SET(8,&mask);if(sched_setaffinity(0,sizeof(mask),&mask))throw std::runtime_error("worker affinity");
            clockid_t id{};if(pthread_getcpuclockid(pthread_self(),&id))throw std::runtime_error("worker clock id");clock=id;
        },{},argc>1?stratadrive::someip::test::fixture_observations("central"):std::vector<std::string>{});
        while(!clock.load() && !signals.failed())std::this_thread::yield();if(signals.failed())return 3;
        const auto begin=cpu();std::this_thread::sleep_for(std::chrono::seconds(2));used=cpu()-begin;
        signals.finish();if(signals.failed())return 4;
    }
    std::cout<<"{\"worker_cpu_ns\":"<<used<<",\"wall_seconds\":2,\"observed\":"<<(argc>1?8:34)<<"}\n";
    std::filesystem::remove_all(folder);
}
