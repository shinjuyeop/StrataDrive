from pathlib import Path
import csv, hashlib, json, shutil, subprocess, tarfile

root=Path.cwd();base=root/'build/m9-aux-io';out=root/'docs/test-plan/evidence/m9_auxiliary_io'
out.mkdir(parents=True,exist_ok=False)
cohorts=('placement-comparison','subscribed-campaign','subscribed-regressions')
results={};snapshot_checks=[]
for cohort in cohorts:
    folder=base/cohort
    rows=json.loads((folder/'results.json').read_text());manifest=json.loads((folder/'manifest.json').read_text())
    results[cohort]={'manifest':manifest,'results':rows}
    with tarfile.open(folder/'sources.tar.gz','r:gz') as archive:
        for name,digest in manifest['sources'].items():
            assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest,(cohort,name)
    snapshot_checks.append({'cohort':cohort,'sources_verified':len(manifest['sources'])})
    with tarfile.open(out/(cohort+'.tar.gz'),'w:gz',compresslevel=6) as archive:archive.add(folder,arcname=cohort)
final=json.loads((base/'subscribed-campaign/manifest.json').read_text())
for name,digest in final['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for profile,digest in final['binaries'].items():
    assert hashlib.sha256((root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==digest,profile
regression=json.loads((base/'subscribed-regressions/manifest.json').read_text())
assert all(final['binaries'][profile]==digest for profile,digest in regression['binaries'].items())
for name in ('analysis.json','probe-results.json','static-results.json'):
    shutil.copy2(base/name,out/name)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(out/'identity-checks.json').write_text(json.dumps({'source_snapshots':snapshot_checks,'final_sources_match':True,'final_binaries_match':True,'service_and_regression_binaries_match':True},indent=2)+'\n')
with tarfile.open(out/'validation-and-tools.tar.gz','w:gz',compresslevel=6) as archive:
    for path in sorted(base.iterdir()):
        if path.is_file() and path.suffix in ('.py','.cpp','.json','.csv','.log','.txt'):
            archive.add(path,arcname=path.name)
with tarfile.open(out/'build-configurations.tar.gz','w:gz',compresslevel=6) as archive:
    for profile in ('normal','asan','tsan'):
        for part in ('project','sdk'):
            for name in ('CMakeCache.txt','compile_commands.json'):
                path=root/f'build/m5-someip-{profile}'/part/name
                if path.exists():archive.add(path,arcname=f'{profile}/{part}/{name}')
(out/'source-final-manifest.json').write_text(json.dumps(final['sources'],indent=2)+'\n')
with tarfile.open(out/'source-final.tar.gz','w:gz') as archive:
    for name in final['sources']:archive.add(root/name,arcname=name)
print(json.dumps({p.name:p.stat().st_size for p in out.iterdir()},indent=2))
