import sys,pathlib,os,subprocess,fcntl,json,signal,shutil,time
root=pathlib.Path('/d/shin/StrataDrive');sys.path.insert(0,str(root/'tests/integration/middleware'))
import check_dds_lifecycle as d
import check_dds_operating_profile as op
out=root/'build/m5-dds-operating-audit/readiness-v2';out.mkdir()
rows=[{'id':'normal-A-ready-'+str(i),'profile':'normal','config':'A','case':'normal','withhold':False,'verdict':'NOT RUN'} for i in range(1,4)]
rows += [{'id':p+'-D-ready','profile':p,'config':'D','case':'normal','withhold':False,'verdict':'NOT RUN'} for p in ['asan-ubsan','tsan']]
rows += [{'id':'normal-withheld-ready','profile':'normal','config':'D','case':'normal','withhold':True,'verdict':'NOT RUN'}]
(out/'sources').mkdir()
for p in d.HERE.iterdir():
 if p.is_file():shutil.copy2(p,out/'sources'/p.name)
shutil.copy2(__file__,out/'runner.py')
shutil.copy2(root/'docs/test-plan/evidence/m5_dds_operating_profile/readiness-protocol.md',out/'protocol.md')
d.save(out/'plan.json',{'trials':rows,'per_case_timeout_s':35,'campaign_timeout_s':600,'storage_cap':536870912,'env':op.SANITIZERS})
d.save(out/'results.json',rows)
d.save(out/'metadata.json',{'sources':{p.name:d.sha(p) for p in (out/'sources').iterdir()},'sdk_libraries':{k:d.sha(root/v[0]/'lib/libddsc.so.11') for k,v in d.PROFILES.items()}})
with (root/'build/.m4-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 rc=d.build_probes(out)
 if rc:sys.exit(rc)
 d.save(out/'binaries.json',{k:d.sha(out/k/'lifecycle-probe') for k in d.PROFILES})
 began=time.monotonic()
 for row in rows:
  folder=out/row['id'];folder.mkdir();cc,cz,period,observer=op.CONFIGS[row['config']]
  env={k:v for k,v in os.environ.items() if not k.startswith('SD_')}
  env.update(op.SANITIZERS,SD_TRANSPORT_READY='1',SD_CENTRAL_CPU=str(cc),SD_ZONE_CPU=str(cz),SD_PERIOD_MS=str(period),SD_OBSERVER=observer,SD_LIFETIME_TRACE='off' if observer=='minimal' else 'full')
  if row['withhold']:env['SD_TEST_WITHHOLD_READY']='1'
  cmd=['unshare','-Urnm',sys.executable,str(d.HERE/'check_dds_lifecycle.py'),'--inside',str(folder),str(out/row['profile']/'lifecycle-probe'),'normal']
  if row['profile']=='tsan':cmd=['setarch','x86_64','-R',*cmd]
  d.save(folder/'command.json',{'argv':cmd,'env':{k:v for k,v in env.items() if k.startswith('SD_') or k in op.SANITIZERS}})
  with (folder/'run.log').open('w') as log:
   p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   try:rc=p.wait(timeout=35)
   except subprocess.TimeoutExpired:
    try:os.killpg(p.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    p.wait();rc=124
  detail=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
  logs='\n'.join(p.read_text(errors='replace') for p in [folder/'run.log',*folder.glob('*.stderr')])
  bad=any(s in logs for s in ['WARNING: ThreadSanitizer','FATAL: ThreadSanitizer','ERROR: AddressSanitizer','ERROR: LeakSanitizer','runtime error:'])
  errors=op.evidence_errors(folder,row,detail) if not row['withhold'] else []
  functional=detail.get('functional','FAIL')
  row.update(exit=rc,result=detail,functional=functional,evidence_errors=errors,tsan_warnings=logs.count('WARNING: ThreadSanitizer'),sanitizer_verdict=op.sanitizer_verdict(row['profile'],'normal',bad))
  row['verdict']='PASS' if rc==0 and functional=='PASS' and not bad and not errors else 'FAIL'
  if row['withhold']:
   ready=json.loads((folder/'central-42.transport-ready.json').read_text())
   row['negative_control_pass']=rc!=0 and ready['received'] is False and not (folder/'go').exists() and all(p.get('exit') is not None for p in detail.get('processes',[])) and len(detail.get('processes',[]))==2
  d.save(out/'results.json',rows);print(json.dumps({k:v for k,v in row.items() if k!='result'}),flush=True)
  if time.monotonic()-began>600 or sum(p.stat().st_size for p in out.rglob('*') if p.is_file())>536870912:sys.exit(2)
 before=json.loads((out/'metadata.json').read_text())['sources'];d.save(out/'source-stability.json',{'unchanged':all(d.sha(d.HERE/k)==v for k,v in before.items())})
