import pathlib,subprocess,json,os,fcntl,hashlib
root=pathlib.Path('/d/shin/StrataDrive');out=root/'build/m5-dds-operating-audit/protection';out.mkdir()
filters={'remote_contract_test':'RemoteWire.DelayedDecodedCommandKeepsOriginalExclusiveExpiryAtZone:RemoteProtection.*', 'remote_leaf_test':'RemoteLeafTest.ArmedOriginalFrameProducesOriginalActualAndCompositeExpiryProtects:RemoteLeafTest.ExpiredStopLeaseCannotBeRestampedByTransport:RemoteLeafTest.NormalFifoOverflowLatchesSessionAndNewEpochCannotRepairFailedLink:RemoteLeafTest.ExpiredProtectionCannotRenewAndNewEpochClearsIdentityRecords:RemoteZoneIntegration.ActualProducedEnvelopeExpiresExclusivelyWithoutRestamping:RemoteZoneIntegration.DelayedPowerAndPermissionKeepOriginalExpiryAndCannotReachActor:RemoteZoneIntegration.ExpiredArmAndStopResponsesRemainBoundToTheOriginalOperation'}
env={**os.environ,'TSAN_OPTIONS':'halt_on_error=0:exitcode=66:history_size=7','ASAN_OPTIONS':'detect_leaks=1:exitcode=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
rows=[]
for profile,build in [('asan-ubsan','m1-angle-sanitized'),('tsan','m4-tsan')]:
 for binary,filter in filters.items():
  exe=root/'build'/build/binary;cmd=[str(exe),'--gtest_filter='+filter,'--gtest_output=xml:'+str(out/(profile+'-'+binary+'.xml'))]
  if profile=='tsan':cmd=['setarch','x86_64','-R',*cmd]
  rows.append({'profile':profile,'binary':binary,'sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'argv':cmd,'timeout_s':30,'verdict':'NOT RUN'})
(out/'plan.json').write_text(json.dumps(rows,indent=2)+'\n')
with (root/'build/.m4-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for row in rows:
  r=subprocess.run(row['argv'],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
  (out/(row['profile']+'-'+row['binary']+'.log')).write_text(r.stdout)
  bad=any(x in r.stdout for x in ['WARNING: ThreadSanitizer','FATAL: ThreadSanitizer','ERROR: AddressSanitizer','runtime error:'])
  row.update(exit=r.returncode,verdict='PASS' if r.returncode==0 and not bad else 'FAIL');print(row['profile'],row['binary'],row['verdict']);print(r.stdout.splitlines()[-1:])
  (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')
