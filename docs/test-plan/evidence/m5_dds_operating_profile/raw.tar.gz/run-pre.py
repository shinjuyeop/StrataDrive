import sys,pathlib,os,subprocess,fcntl,json,signal
root=pathlib.Path('/d/shin/StrataDrive');sys.path.insert(0,str(root/'tests/integration/middleware'))
import check_dds_lifecycle as d
out=root/'build/m5-dds-operating-audit/pre-fix';folder=out/'normal/partial';folder.mkdir()
env={**os.environ,'SD_CENTRAL_CPU':'1','SD_ZONE_CPU':'2','SD_PERIOD_MS':'20','SD_OBSERVER':'minimal','SD_LIFETIME_TRACE':'off'}
cmd=['unshare','-Urnm',sys.executable,str(d.HERE/'check_dds_lifecycle.py'),'--inside',str(folder),str(out/'normal/lifecycle-probe'),'partial']
d.save(folder/'command.json',{'argv':cmd,'env':{k:v for k,v in env.items() if k.startswith('SD_')}})
with (root/'build/.m4-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 with (folder/'run.log').open('w') as log:
  p=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=35)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();rc=124
 result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
 d.save(out/'results.json',[{'case':'partial','exit':rc,'legacy_verdict':result.get('functional','FAIL'),'result':result}])
 print(json.dumps(result,indent=2))
