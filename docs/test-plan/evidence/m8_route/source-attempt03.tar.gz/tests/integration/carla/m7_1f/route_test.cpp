#include "functional_rig.hpp"
#include "native_admission.hpp"
#include <gtest/gtest.h>

namespace stratadrive::m7_functional {
namespace {
TEST(M8CarlaRoute, OriginalPoseAndWheelSupportAdmissionUntilStalePoseBlocksAdvance) {
    FunctionalRig rig({1,42,7},99,PlantMode::ExternalSolverWork,true,60000);
    std::vector<central::RoutePoint> route;
    for(int i=0;i<=720;++i)route.push_back({i*.5,0});
    rig.route_profile(route);
    std::unique_ptr<m7_native::Admission> admission;
    m7_native::Output prior;Time previous=0;unsigned controls=0;
    for(unsigned i=0;i<=200;++i) {
        const double seconds=3.997146773152053+i*.009999999776482582;
        const auto now=static_cast<Time>(std::llround(seconds*1e9));
        const Observation o{{1,42,7},domain,100+i,seconds,.01};
        const WheelSample wheel{99,100+i,now,{0,0,0,0}};
        rig.pose({42,100+i,now-(i==200?10*ms:0),0,0,0},99);
        m7_external::SolverWork w;
        if(i) {
            w.frame=100+i;w.begin=previous;w.end=now;w.oldest=prior.empty?previous:prior.oldest_actuator;
            w.torque=prior.torque;w.dt=double(.01f*(1.f/320.f));w.wheel={0,{7,99+i,previous},previous};
        }
        if(i==200) {EXPECT_THROW(rig.observe(o,wheel,w),std::runtime_error);break;}
        const auto r=i?rig.observe(o,wheel,w):rig.observe(o,wheel);
        if(!admission)admission=std::make_unique<m7_native::Admission>(42,now);
        const auto& e=*r.native_export;m7_native::Input in;
        in.observed=e.observed;in.enable=e.enable;in.normal=e.normal;in.actual=e.actual;in.commands=e.commands;
        in.release=e.release;in.credit=e.credit;in.permission=e.permission;
        in.service_mask=r.service_mask;in.credit_mask=r.credit_mask;in.release_mask=r.release_mask;
        ASSERT_TRUE(admission->accept(in,now,prior))<<admission->error();
        if(r.speed_control) {
            ASSERT_TRUE(r.lateral_control);++controls;
            EXPECT_DOUBLE_EQ(r.lateral_control->curvature_inv_m,0);
            EXPECT_LE(r.lateral_control->source_ns,r.speed_control->release_ns);
        }
        previous=now;
    }
    EXPECT_GT(controls,50U);
}
TEST(M8CarlaRoute, MissingPoseAndUnboundActorRejected) {
    FunctionalRig rig({1,42,7},99,PlantMode::ExternalSolverWork,true,60000);
    rig.route_profile({{0,0},{5,0}});
    EXPECT_THROW(rig.pose({42,100,1000000000,0,0,0},98),std::runtime_error);
    EXPECT_THROW(rig.observe({{1,42,7},domain,100,1,.01},{99,100,1000000000,{0,0,0,0}}),std::runtime_error);
}
} // namespace
} // namespace stratadrive::m7_functional
