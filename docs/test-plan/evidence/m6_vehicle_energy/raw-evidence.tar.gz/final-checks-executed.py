from pathlib import Path
import subprocess,json,time,fcntl,sys
root=Path.cwd();out=root/'build/m6-vehicle-energy';rows=[];source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def run(name,argv,timeout=300,lock=True):
    r={'name':name,'source':source,'argv':argv,'start_ns':time.time_ns()};rows.append(r)
    with (out/(name+'.txt')).open('w') as log:
        try:
            with (root/'build/.m4-exclusive.lock').open('a') as guard:
                if lock:fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
                r['exit']=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except Exception as e:r.update(exit=1,error=repr(e))
    r['end_ns']=time.time_ns();(out/'final-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r['exit'],flush=True)
    return r['exit']==0
base=['python3','tests/integration/someip/front_run.py']
flags=['--three','--fault-zone','rear','--native-watch','--fifo','--simple-vehicle']
run('normal-cycle',base+[str(out/'final-normal-cycle'),*flags,'--energy-cycle','nominal','--profile','normal','--cases','normal'],35,False)
run('normal-zero',base+[str(out/'final-normal-zero'),*flags,'--energy-cycle','no-charge','--profile','normal','--cases','normal'],35,False)
run('normal-faults',base+[str(out/'final-normal-faults'),*flags,'--energy-cycle','nominal','--profile','normal','--cases','command-loss','owner-pause','restart-live'],85,False)
for label in ['asan','tsan']:
    if run('sdk-'+label+'-build',['cmake','--build',f'build/m5-someip-{label}/project','--target','someip_front_adapter','--parallel','4']):
        argv=base+[str(out/('final-'+label)),*flags,'--energy-cycle','nominal','--profile',label,'--cases','normal','restart-live']
        if label=='tsan':argv+=['--fixed-layout']
        run('sdk-'+label,argv,60,False)
for label,path in [('normal','build/m4-readiness'),('asan','build/m1-angle-sanitized')]:
    if run('full-'+label+'-build',['cmake','--build',path,'--parallel','4']):
        run('full-'+label,['ctest','--test-dir',path,'--output-on-failure','--output-junit',str(out/('full-'+label+'.xml'))])
if run('boundary-tsan-build',['cmake','--build','build/m4-contract-tsan-final','--target','vehicle_energy_test','async_owner_test','--parallel','4']):
    run('boundary-tsan',['setarch','x86_64','-R','ctest','--test-dir','build/m4-contract-tsan-final','-R','^(VehicleEnergy\.|EnergyScenario\.|AsyncOwnerTest\.|AsyncZoneOwner\.)','--output-on-failure','--output-junit',str(out/'boundary-tsan.xml')])
for suite in ['m6_energy','m6_model','someip_pilot']:
    run('python-'+suite,['python3',f'tests/unit/{suite}_test.py'])
raise SystemExit(1 if any(r.get('exit',1) for r in rows) else 0)
