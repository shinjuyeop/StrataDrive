from pathlib import Path
import subprocess,json,csv,hashlib,platform,resource,os,xml.etree.ElementTree as ET
from datetime import datetime,timezone,timedelta
root=Path.cwd();out=root/'build/m6-vehicle-energy';ev=root/'docs/test-plan/evidence/m6_vehicle_energy'
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cmd(a,**kw):return subprocess.check_output(a,text=True,**kw).strip()
source=cmd(['git','rev-parse','HEAD'])
save(out/'environment.json',{'source':source,'kernel':platform.platform(),'python':platform.python_version(),'compiler':cmd(['c++','--version']).splitlines()[0],'cmake':cmd(['cmake','--version']).splitlines()[0],'rtprio':resource.getrlimit(resource.RLIMIT_RTPRIO),'affinity':sorted(os.sched_getaffinity(0)),'uid':os.getuid()})
(out/'lscpu.txt').write_text(cmd(['lscpu']))
old=json.loads(Path('build/m6-simple-vehicle/instrumentation.json').read_text());meta={'sdk_head':cmd(['git','-C','build/m5-someip-deps/vsomeip','rev-parse','HEAD']),'sdk_status':cmd(['git','-C','build/m5-someip-deps/vsomeip','status','--porcelain']),'profiles':{}}
for profile in ['normal','asan','tsan']:
 b=root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter';libs=[]
 for lib in old['profiles'][profile]['libraries']:
  p=Path(lib['path']);sym=cmd(['nm','-D',str(p)]);libs.append({'path':str(p),'sha256':sha(p),'same_as_previous_m6':sha(p)==lib['sha256'],'asan':'__asan_' in sym,'ubsan':'__ubsan_' in sym,'tsan':'__tsan_' in sym})
 sym=cmd(['nm',str(b)]);meta['profiles'][profile]={'binary':str(b.relative_to(root)),'sha256':sha(b),'asan':'__asan_' in sym,'ubsan':'__ubsan_' in sym,'tsan':'__tsan_' in sym,'libraries':libs}
 commands=json.loads((root/f'build/m5-someip-{profile}/project/compile_commands.json').read_text());save(out/(profile+'-compile-commands.json'),[r for r in commands if any(s in r['file'] for s in ['simple_vehicle.cpp','vehicle_ev_model.cpp','ev_power_model.cpp','front_adapter.cpp','m4_owner_network.cpp','async_coordinator_port.cpp','async_zone_owner.cpp'])])
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/f'build/m5-someip-{profile}/install/lib'));(out/(profile+'-ldd.txt')).write_text(cmd(['ldd',str(b)],env=env)+'\n')
 p=root/f'build/m5-someip-{profile}/project/CMakeCache.txt';(out/(profile+'-build-options.txt')).write_text('\n'.join(x for x in p.read_text().splitlines() if x.startswith(('CMAKE_CXX_FLAGS','CMAKE_BUILD_TYPE','STRATADRIVE_','vsomeip')))+'\n')
save(out/'instrumentation.json',meta)
results=[];warnings=[];timeline=[];margins=[];energy=[];failure_axis={}
for cohort in sorted(out.iterdir()):
 if not (cohort/'results.json').is_file():continue
 final=cohort.name.startswith('final-')
 for attempt in json.loads((cohort/'results.json').read_text()):
  folder=cohort/(attempt['case']+'-'+str(attempt['repeat']));r=json.loads((folder/'result.json').read_text());renew=r.get('renewal',r.get('rear',{}).get('renewal'))
  results.append({'cohort':cohort.name,'case':attempt['case'],'raw_exit':attempt['exit'],'intended_final_source':final,'pass':r['pass'],'error':r.get('error'),'energy':r.get('energy'),'native':r.get('native'),'rear':r.get('rear'),'vehicle':r.get('vehicle'),'renewal':renew,'sdk_errors':r.get('unexpected_sdk_errors'),'sanitizer_diagnostics':r.get('sanitizer_diagnostics'),'forced_cleanup':r.get('forced_cleanup')})
  if not final:continue
  for proc in r['processes']:
   s=proc.get('summary',{})
   for k in ['armed_ns','normal_stop_started','normal_stop_complete','pre_shutdown_protection','selected_ns','stop_begin','stop_return','join_return']:
    if s.get(k):timeline.append(dict(cohort=cohort.name,case=attempt['case'],role=proc['role'],epoch=s.get('epoch',0),event=k,ns=s[k]))
  if renew:
   for l in renew.get('leaves',[]):margins.append(dict(cohort=cohort.name,case=attempt['case'],**l))
  if r.get('energy',{}).get('pass'):
   e=r['energy'];energy.append(dict(cohort=cohort.name,case=attempt['case'],runtime_pass=r['pass'],raw_exit=attempt['exit'],energy_ledger_pass=e['pass'],**{k:e[k] for k in ['max_combined_residual_j','max_coupling_residual_j','max_motion_residual_j','peak_speed_rad_s']},**e['final']))
  boundaries=[p.get('summary',{}).get(k,0) for p in r['processes'] for k in ['pre_shutdown_protection','normal_stop_started','stop_begin']];boundaries=[x for x in boundaries if x]
  if (folder/'inject').exists():boundaries.append(int((folder/'inject').read_text()))
  boundary=min(boundaries) if boundaries else 0;sample=r['clock_sample']
  for f in folder.glob('*.stdout'):
   for n,line in enumerate(f.read_text(errors='replace').splitlines(),1):
    if '[warning]' not in line and '[error]' not in line:continue
    dt=datetime.strptime(line[:26],'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=timezone(timedelta(seconds=sample['utc_offset_s'])))
    ns=int(dt.timestamp()*1e9)-sample['wall_ns']+sample['monotonic_ns'];txt=line.split(']',1)[-1].strip()
    classification='SDK ERROR retained as FAIL' if '[error]' in line else 'interface/route' if 'state changed: up' in txt else 'SD multicast lifecycle' if ('multicast' in txt or '550ms' in txt) else 'after fault/stop boundary' if boundary and ns>=boundary else 'other warning retained'
    warnings.append(dict(cohort=cohort.name,case=attempt['case'],file=f.name,line=n,ns=ns,boundary_ns=boundary,classification=classification,text=txt))
 if cohort.name=='final-normal-faults':
  f=cohort/'command-loss-1';inj=int((f/'inject').read_text());p=list(csv.DictReader((f/'physical.csv').open()));before=[x for x in p if int(x['ns'])<inj];after=[x for x in p if int(x['ns'])>=inj];complete=next(x for x in after if abs(float(x['torque']))<=1 and float(x['pressure'])>=100000);s=json.loads((f/'rear-1.json').read_text());faults=list(csv.DictReader((f/'rear-1.events.csv').open()))
  failure_axis['normal_command_loss']={'injection_ns':inj,'last_before':before[-1],'local_selected_ns':s['selected_ns'],'selected_after_ns':s['selected_ns']-inj,'first_sample_complete':complete,'sample_complete_after_ns':int(complete['ns'])-inj,'original_physical_gate_ns':100000000,'original_zero_rate_nm_s':2000,'physical_torque_at_approximately100ms':[x for x in after if 95e6<=int(x['ns'])-inj<=110e6],'fault_events':[x for x in faults if 'fault' in x['event'] or 'protection' in x['event']]}
save(ev/'results-summary.json',{'source':source,'raw_sdk_attempts':len(results),'raw_sdk_pass':sum(r['raw_exit']==0 for r in results),'intended_final_attempts':sum(r['intended_final_source'] for r in results),'intended_final_pass':sum(r['intended_final_source'] and r['raw_exit']==0 for r in results),'cpp':{f:ET.parse(out/f).getroot().attrib for f in ['full-normal.xml','full-asan.xml','boundary-tsan.xml']},'sdk':results})
for name,rows in [('results.csv',[{k:r[k] for k in ['cohort','case','raw_exit','intended_final_source','pass']} for r in results]),('sdk-warnings.csv',warnings),('timeline.csv',timeline),('renewal-margins.csv',margins),('energy-accounting.csv',energy)]:
 with (ev/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
save(ev/'failure-axis.json',failure_axis)
a={e.attrib['name'] for e in ET.parse('build/m6-simple-vehicle/full-normal.xml').iter('testcase')};b={e.attrib['name'] for e in ET.parse(out/'full-normal.xml').iter('testcase')};save(out/'test-name-preservation.json',{'previous':len(a),'current':len(b),'removed':sorted(a-b),'added':sorted(b-a)});assert not a-b
mapping=list(csv.DictReader(Path('docs/test-plan/component_traceability.csv').open()));assert all(r['test'] in b for r in mapping if r['id'].startswith('C-M6-E-'))
(out/'source.patch').write_text(cmd(['git','diff','f57e18c','d242861','--','.']))
save(out/'boundary-followup.json',{'source':source,'reason':'initial Make target was unknown before CMake regeneration; runtime was NOT RUN in that build stage','original_build_exit':2,'configure_exit':0,'build_exit':0,'ctest_exit':0,'tests':28,'commands':[['cmake','-S','.','-B','build/m4-contract-tsan-final'],['cmake','--build','build/m4-contract-tsan-final','--target','vehicle_energy_test','async_owner_test','--parallel','4'],['setarch','x86_64','-R','ctest','--test-dir','build/m4-contract-tsan-final','-R','^(VehicleEnergy\\.|EnergyScenario\\.|AsyncOwnerTest\\.|AsyncZoneOwner\\.)','--output-on-failure','--output-junit',str(out/'boundary-tsan.xml')]]})
print('raw SDK',len(results),'PASS',sum(r['raw_exit']==0 for r in results),'final',sum(r['intended_final_source'] for r in results),'PASS',sum(r['intended_final_source'] and r['raw_exit']==0 for r in results),'warnings',len(warnings),'SDK errors',sum(w['classification']=='SDK ERROR retained as FAIL' for w in warnings))
