from pathlib import Path
import csv,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('build/m6-vehicle-energy');ev=Path('docs/test-plan/evidence/m6_vehicle_energy')
def rows(p):
 with p.open() as f:return [{k:float(v) for k,v in x.items()} for x in csv.DictReader(f)]
nom=root/'final-normal-cycle/normal-1';zero=root/'final-normal-zero/normal-1'
arm=json.loads((nom/'central-1.json').read_text())['armed_ns'];r=rows(nom/'energy.csv');t=[(x['end_ns']-arm)/1e9 for x in r]
fig,ax=plt.subplots(4,1,figsize=(10,11),constrained_layout=True)
for d,label in [(nom,'Nominal charge acceptance'),(zero,'BMS charge acceptance 0 W')]:
 a=json.loads((d/'central-1.json').read_text())['armed_ns'];v=rows(d/'energy.csv');ts=[(x['end_ns']-a)/1e9 for x in v]
 ax[0].plot(ts,[x['wheel_speed_rad_s']*.3*3.6 for x in v],label=label)
ax[0].set(title='M6 actual three-ECU FIFO cycle (scenario demand, no C++ speed PI)',ylabel='Actual speed (km/h)');ax[0].legend()
ax[1].plot(t,[x['torque_nm'] for x in r],label='Actual Drive torque')
ax[1].plot(t,[x['pressure_pa']*.001 for x in r],label='Actual friction equivalent torque')
ax[1].text(.99,.04,'Gray band: after normal-stop completion / cleanup',transform=ax[1].transAxes,ha='right',fontsize=9)
ax[1].axhline(0,color='gray',linewidth=.5);ax[1].set(ylabel='Aggregate wheel Nm');ax[1].legend()
for k,label in [('kinetic_j','Kinetic'),('friction_j','Friction dissipation'),('received_dc_j','Battery received DC'),('road_j','Road dissipation')]:ax[2].plot(t,[x[k] for x in r],label=label)
ax[2].set(ylabel='Joules',xlabel='Seconds from actual arm');ax[2].legend(ncol=2)
completed=(json.loads((nom/'central-1.json').read_text())['normal_stop_complete']-arm)/1e9
for a in ax[:3]:
 a.axvspan(completed,max(t),color='gray',alpha=.15)
 for x in (2.,2.6,4.5):a.axvline(x,color='gray',linestyle=':',alpha=.6)
 a.set_xlim(0,max(t));a.grid(alpha=.25)
p=root/'final-normal-faults/command-loss-1';inj=int((p/'inject').read_text());v=rows(p/'physical.csv');ts=[(x['ns']-inj)/1e6 for x in v];selected=json.loads((p/'rear-1.json').read_text())['selected_ns']
ax[3].plot(ts,[x['torque'] for x in v],label='Actual torque after command loss')
ax[3].axvline(100,color='red',linestyle='--',label='Existing physical gate: 100 ms (FAIL)')
ax[3].axvline((selected-inj)/1e6,color='green',linestyle=':',label='Local zero-target selection')
ax[3].set(xlim=(-20,160),xlabel='Milliseconds from actual injection',ylabel='Nm',title='Selection succeeds; finite physical ramp exceeds the existing gate');ax[3].grid(alpha=.25);ax[3].legend()
fig.savefig(ev/'energy-and-protection.svg');fig.savefig(root/'energy-and-protection.png',dpi=120)
