from pathlib import Path
import subprocess,json,fcntl,os
root=Path.cwd();out=root/'build/m4-dds-lifetime';prefix=out/'asan-install';build=out/'wrapper-asan';build.mkdir()
flags=['-g','-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror','-pthread']
includes=['-I'+str(root/d) for d in ['tests/integration/middleware','interfaces/remote','interfaces/zone','interfaces/central','interfaces/steering','interfaces/common','interfaces/brake','interfaces/drive','interfaces/bms','interfaces/session','build/m4-probe-tsan/tests/integration/middleware']]+['-I'+str(prefix/'include')]
cmds=[]
for file,cc in [(root/'tests/integration/middleware/probe.cpp','g++'),(root/'tests/integration/middleware/dds_channel.c','gcc'),(root/'build/m4-probe-tsan/tests/integration/middleware/packet.c','gcc')]:
 cmds.append([cc,*flags,*(['-std=c++17'] if cc=='g++' else ['-std=c11']),*includes,'-c',str(file),'-o',str(build/(file.name+'.o'))])
libs=['owner_wire','zone_feedback_contract','steering_frame_codec','steering_angle_codec','brake_codec','drive_codec','bms_receiver','bms_codec','actuator_receiver_state','actuator_payload_codec','e2e_profile5']
cmds.append(['g++',*flags,*[str(build/(f+'.o')) for f in ['probe.cpp','dds_channel.c','packet.c']],*[str(root/'build/m1-angle-sanitized'/('lib'+lib+'.a')) for lib in libs],'-L'+str(prefix/'lib'),'-Wl,-rpath,'+str(prefix/'lib'),'-lddsc','-o',str(build/'dds_candidate_probe')])
(build/'plan.json').write_text(json.dumps(dict(hypothesis='Actual network proxy/receive teardown in the original two-process wrapper may expose an ASan lifetime error not exercised by a local Writer. Fixed normal/overflow once each; no timing acceptance.',commands=cmds,planned=2,timeout_seconds=30),indent=2)+'\n')
with (root/'build/.m4-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for i,cmd in enumerate(cmds):
  with (build/f'build-{i}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=60)
  assert r.returncode==0
 rows=[]
 for case in ['normal','overflow']:
  folder=out/('wrapper-asan-'+case);folder.mkdir()
  env={**os.environ,'LD_LIBRARY_PATH':str(prefix/'lib'),'ASAN_OPTIONS':'detect_leaks=1:exitcode=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
  cmd=['unshare','-Urnm','python3',str(root/'tests/integration/middleware/run_probe.py'),'--child',str(folder),str(build/'dds_candidate_probe'),case]
  (folder/'command.json').write_text(json.dumps(dict(argv=cmd,asan=env['ASAN_OPTIONS'],ubsan=env['UBSAN_OPTIONS'],sdk=env['LD_LIBRARY_PATH'],timeout=30),indent=2)+'\n')
  with (folder/'run.log').open('w') as log:
   try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=30).returncode
   except subprocess.TimeoutExpired:code=124
  result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
  rows.append(dict(case=case,exit=code,result=result));(out/'wrapper-asan-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
raise SystemExit(0 if all(r['exit']==0 and r['result'].get('verdict')=='PASS' for r in rows) else 1)
