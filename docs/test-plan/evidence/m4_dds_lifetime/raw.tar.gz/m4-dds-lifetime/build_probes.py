from pathlib import Path
import subprocess,json,fcntl,hashlib
root=Path.cwd();out=root/'build/m4-dds-lifetime'
src=root/'build/m4-communication-research/deps/cyclonedds-src/eclipse-cyclonedds-cyclonedds-e54e991'
normal=root/'build/m4-communication-research/install'
tsan=root/'build/m4-sdk-followup/dds-official/install'
asan=out/'asan-install'; cmds=[]
cmake=['cmake','-S',str(src),'-B',str(out/'asan-build'),'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_INSTALL_PREFIX='+str(asan),'-DBUILD_TESTING=OFF','-DBUILD_EXAMPLES=OFF','-DBUILD_DDSPERF=OFF','-DENABLE_SECURITY=OFF','-DENABLE_ICEORYX=OFF','-DBUILD_IDLC=OFF','-DSANITIZER=address,undefined','-DCMAKE_C_FLAGS=-fno-omit-frame-pointer','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
cmds.extend([cmake,['cmake','--build',str(out/'asan-build'),'-j4'],['cmake','--install',str(out/'asan-build')]])
for name,prefix,san in [('normal',normal,''),('tsan',tsan,'thread'),('asan-ubsan',asan,'address,undefined')]:
 cmd=['gcc','-std=c11','-O1','-g','-fno-omit-frame-pointer','-Wall','-Wextra','-Werror','-pthread','-I'+str(prefix/'include'),'-I'+str(src/'src/core/ddsc/src'),'-I'+str(src/'src/core/ddsi/src'),'-I'+str(root/'build/m4-probe-tsan/tests/integration/middleware'),str(root/'tests/integration/middleware/dds_writer_lifetime.c'),str(root/'build/m4-probe-tsan/tests/integration/middleware/packet.c'),'-L'+str(prefix/'lib'),'-Wl,-rpath,'+str(prefix/'lib'),'-lddsc','-o',str(out/(name+'-writer'))]
 if san:cmd.insert(1,'-fsanitize='+san)
 cmds.append(cmd)
(out/'build-plan.json').write_text(json.dumps(cmds,indent=2)+'\n')
with (root/'build/.m4-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for i,cmd in enumerate(cmds):
  with (out/f'build-{i}.log').open('w') as log:
   r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=300)
  print(i,r.returncode,flush=True)
  if r.returncode:raise SystemExit(r.returncode)
