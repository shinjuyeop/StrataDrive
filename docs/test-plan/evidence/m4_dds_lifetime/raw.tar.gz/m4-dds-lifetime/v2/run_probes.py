from pathlib import Path
import subprocess,json,fcntl,os,hashlib,time
root=Path.cwd();out=root/'build/m4-dds-lifetime/v2';rows=[]
xml='<CycloneDDS><Domain Id="51"><General><Interfaces><NetworkInterface name="lo"/></Interfaces><AllowMulticast>false</AllowMulticast></General><Discovery><ParticipantIndex>auto</ParticipantIndex></Discovery></Domain></CycloneDDS>'
plan=[(profile,mode,rep) for profile,mode in [('normal','correct'),('asan-ubsan','correct'),('tsan','correct'),('asan-ubsan','use-after-asleep')] for rep in range(1,4)]
with (root/'build/.m4-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for profile,mode,rep in plan:
  p=out/f'{profile}-{mode}-{rep}';p.mkdir(exist_ok=False)
  env={**os.environ,'CYCLONEDDS_URI':xml,'TSAN_OPTIONS':'halt_on_error=0:exitcode=66:history_size=7','ASAN_OPTIONS':'detect_leaks=1:exitcode=1','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1'}
  env.pop('LD_LIBRARY_PATH',None)
  command=([ 'setarch','x86_64','-R'] if profile=='tsan' else [])+[str(out/(profile+'-writer'))]+(['--use-after-asleep'] if mode!='correct' else [])
  (p/'command.json').write_text(json.dumps(dict(argv=command,xml=xml,tsan=env['TSAN_OPTIONS'],asan=env['ASAN_OPTIONS'],ubsan=env['UBSAN_OPTIONS'],timeout_seconds=15),indent=2)+'\n')
  with (p/'stdout.log').open('w') as stdout,(p/'stderr.log').open('w') as stderr:
   try:code=subprocess.run(command,stdout=stdout,stderr=stderr,env=env,timeout=15).returncode
   except subprocess.TimeoutExpired:code=124
  text=(p/'stderr.log').read_text();warnings=text.count('WARNING: ThreadSanitizer')
  data={}
  try:data=json.loads((p/'stdout.log').read_text())
  except ValueError:pass
  expected=mode!='correct'
  oracle=(code==1 and 'ERROR: AddressSanitizer: heap-use-after-free' in text) if expected else bool(data and code in (0,66) and not data.get('free_held',1))
  row=dict(profile=profile,mode=mode,repetition=rep,exit=code,tsan_warnings=warnings,oracle=oracle,sanitizer_clean=code==0 and not warnings and 'runtime error:' not in text,expected_positive_control=expected,**data)
  rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
raise SystemExit(0 if all(r['oracle'] for r in rows) else 1)
