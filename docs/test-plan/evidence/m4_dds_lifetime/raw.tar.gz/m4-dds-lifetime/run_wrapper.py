from pathlib import Path
import subprocess,fcntl,json,os
root=Path.cwd();out=root/'build/m4-dds-lifetime';rows=[]
with (root/'build/.m4-exclusive.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for case in ['normal','overflow']:
  folder=out/('wrapper-'+case);folder.mkdir()
  env={**os.environ,'LD_LIBRARY_PATH':str(root/'build/m4-sdk-followup/dds-official/install/lib'),'TSAN_OPTIONS':'halt_on_error=0:exitcode=66:history_size=7'}
  cmd=['unshare','-Urnm','setarch','x86_64','-R','python3',str(root/'tests/integration/middleware/run_probe.py'),'--child',str(folder),str(root/'build/m4-probe-tsan/tests/integration/middleware/dds_candidate_probe'),case]
  (folder/'command.json').write_text(json.dumps(dict(argv=cmd,tsan=env['TSAN_OPTIONS'],sdk=env['LD_LIBRARY_PATH'],timeout=30),indent=2)+'\n')
  with (folder/'run.log').open('w') as log:
   try:code=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=30).returncode
   except subprocess.TimeoutExpired:code=124
  result=json.loads((folder/'result.json').read_text()) if (folder/'result.json').exists() else {}
  warnings=sum(p.read_text().count('WARNING: ThreadSanitizer') for p in folder.glob('*.stderr'))
  rows.append(dict(case=case,exit=code,warnings=warnings,result=result))
  (out/'wrapper-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(rows[-1],flush=True)
raise SystemExit(0 if all(r['exit']==1 and r['warnings'] and r['result']['verdict']=='FAIL' for r in rows) else 1)
