from pathlib import Path
import json,re,collections,csv,hashlib,subprocess
root=Path.cwd();out=root/'build/m4-dds-lifetime';groups=collections.defaultdict(list)
for p in sorted((root/'build/m4-sdk-followup/dds-official').glob('*-*/*.stderr')):
 for index,block in enumerate(p.read_text().split('WARNING: ThreadSanitizer:')[1:],1):
  if 'gc_buckets_cb' in block:kind='GC-BUCKET'
  elif 'gc_delete_writer' in block:kind='GC-WRITER-WHC'
  elif 'ddsrt_chh_resize' in block:kind='PUB-BUCKET'
  else:kind='PUB-REMOTE-OBJECT'
  summary=re.search(r'SUMMARY: ThreadSanitizer: ([^\n]+)',block)
  funcs=[]
  for f in re.findall(r'^\s+#\d+ (\S+)',block,re.M):
   if f not in funcs:funcs.append(f)
  groups[kind].append(dict(file=str(p.relative_to(root)),warning_index=index,summary=summary[1] if summary else 'MISSING',functions=funcs,log_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
assert sum(map(len,groups.values()))==29
(out/'warning-groups.json').write_text(json.dumps(dict(total_warnings=29,groups=groups,note='Four analysis families, not four proven defects; no suppression'),indent=2)+'\n')
raw=json.loads((out/'v2/results.json').read_text());flat=[]
for r in raw:
 row={k:r[k] for k in ['profile','mode','repetition','exit','tsan_warnings','oracle','sanitizer_clean','expected_positive_control']}
 row.update({k:r.get(k,'') for k in ['acquired_ns','delete_ns','deleted_ns','last_access_ns','scope_end_ns','free_ns','reads','free_held']});flat.append(row)
with (out/'lifetime.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(flat[0]),lineterminator='\n');w.writeheader();w.writerows(flat)
inputs={};source=root/'build/m4-communication-research/deps/cyclonedds-src/eclipse-cyclonedds-cyclonedds-e54e991'
for rel in ['src/ddsrt/src/hopscotch.c','src/ddsrt/include/dds/ddsrt/atomics/gcc.h','src/core/ddsi/include/dds/ddsi/ddsi_thread.h','src/core/ddsi/src/ddsi_gc.c','src/core/ddsi/src/ddsi_entity_index.c','src/core/ddsi/src/ddsi_endpoint.c','src/core/ddsi/src/ddsi_proxy_endpoint.c','src/core/ddsi/src/ddsi_entity.c','src/core/ddsi/src/ddsi_receive.c','src/core/ddsi/src/ddsi_lease.c','src/core/ddsc/src/dds_writer.c','src/core/ddsc/src/dds_whc.c']:
 inputs[rel]=hashlib.sha256((source/rel).read_bytes()).hexdigest()
profiles={}
for name in ['normal','tsan','asan-ubsan']:
 binary=out/'v2'/(name+'-writer');ldd=subprocess.check_output(['ldd',str(binary)],text=True)
 (out/('ldd-'+name+'.txt')).write_text(ldd)
 libline=next(line for line in ldd.splitlines() if 'libddsc.so' in line)
 lib=Path(libline.split('=>')[1].strip().split()[0]);nm=subprocess.check_output(['nm','-D',str(lib)],text=True)
 profiles[name]=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),library=str(lib),library_sha256=hashlib.sha256(lib.read_bytes()).hexdigest(),asan_imports=len(set(re.findall('__asan_\\w+',nm))),tsan_imports=len(set(re.findall('__tsan_\\w+',nm))))
(out/'provenance.json').write_text(json.dumps(dict(base_commit='c52445a',sdk='11.0.1 e54e991',source_sha256=inputs,profiles=profiles,probe_sha256=hashlib.sha256((root/'tests/integration/middleware/dds_writer_lifetime.c').read_bytes()).hexdigest(),first_harness_source_hash='NOT RECORDED at first compilation; original binaries and logs retained. v1 waited for synchronous dds_delete before allowing reader quiescence, an invalid harness cycle.',not_performance_acceptance=True),indent=2)+'\n')
up=[]
for file in out.glob('*.json'):
 if file.stem not in ['pr2162','pr2162-issue','pr2162-files','issue2039-comments','issue1417-comments','release-latest']:continue
 data=json.loads(file.read_text())
 if isinstance(data,list):
  for item in data:
   up.append({k:item[k] for k in ['html_url','filename','sha','status'] if k in item})
 else:up.append({k:data[k] for k in ['html_url','title','tag_name','merged','state','closed_at','merge_commit_sha'] if k in data})
(out/'upstream-review.json').write_text(json.dumps(up,indent=2)+'\n')
print({k:len(v) for k,v in groups.items()});print(profiles)
