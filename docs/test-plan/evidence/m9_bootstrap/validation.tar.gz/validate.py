import hashlib,json,os,subprocess,sys
from pathlib import Path
out=Path('build/m9-bootstrap').resolve();rows=[]

def run(name,cmd,env=None,timeout=180):
 with (out/(name+'.log')).open('w') as log:
  try:code=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
  except subprocess.TimeoutExpired:code=124
 row=dict(name=name,command=cmd,exit=code);rows.append(row);(out/'validation-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
 if code:raise SystemExit(code)

for profile,directory in [('debug','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 binary=Path(directory).resolve()/'bootstrap_journal_test';xml=out/(profile+'-final.xml')
 env=dict(os.environ,STRATADRIVE_BOOT_EVIDENCE=str(out/(profile+'-final-raw')),ASAN_OPTIONS='halt_on_error=1:detect_leaks=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1',TSAN_OPTIONS='halt_on_error=1:exitcode=66')
 (out/(profile+'-final-binary.json')).write_text(json.dumps(dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))+'\n')
 run(profile+'-final',(['setarch','x86_64','-R'] if profile=='tsan' else [])+[str(binary),'--gtest_output=xml:'+str(xml)],env,120)
run('native-final',[sys.executable,'tests/integration/someip/bootstrap_incidents_run.py',str(out/'native-final'),'--binary','build/m5-someip-normal/project/tests/integration/someip/someip_front_adapter'])
for i,source in enumerate(['central/diagnostics/bootstrap_journal.cpp','tests/integration/someip/front_adapter.cpp','tests/integration/someip/native_diagnostic_routes.cpp']):
 cmd=['clang-tidy','-p',str(out),source]
 if i==1:
  for include in ['/usr/include/c++/11','/usr/include/x86_64-linux-gnu/c++/11','/usr/include/c++/11/backward']:cmd+=['--extra-arg=-isystem','--extra-arg='+include]
 run('tidy-final-'+str(i),cmd)
run('cppcheck-final',['cppcheck','--project='+str(out/'compile_commands.json'),'--enable=warning,performance,portability','--error-exitcode=1','--inline-suppr','--suppress=missingIncludeSystem'])
for name in ['bootstrap_incidents','someip_pilot','service_validation']:
 run(name+'-final',[sys.executable,'tests/unit/'+name+'_test.py'])
run('native-service',[sys.executable,'tests/integration/someip/front_run.py',str(out/'native-service'),'--profile','normal','--three','--simple-vehicle','--diagnostics','--diagnostic-service','--isolated-ecus','--cases','central-rejoin','--split-owner-io','--separate-aux-io','--owner-fifo','--sdk-io-threads','2'],timeout=60)
for name in ['native_service','service_ordering','service_timing','service_response']:
 run('audit-'+name,[sys.executable,'tests/integration/diagnostics/audit_'+name+'.py',str(out/'native-service/central-rejoin-1'),'--mutations'])
