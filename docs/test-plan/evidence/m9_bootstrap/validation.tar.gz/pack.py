import hashlib,json,os,shutil,subprocess,sys,tarfile,tempfile,xml.etree.ElementTree as ET
from pathlib import Path
root=Path.cwd();work=root/'build/m9-bootstrap';dest=root/'docs/test-plan/evidence/m9_bootstrap';dest.mkdir(parents=True,exist_ok=True)
sys.path.insert(0,str(root/'tests/integration/diagnostics'))
from audit_bootstrap_incidents import audit
from service_sanitizer_suite import judge_xml

def save(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
# Include the originally retained, separate filesystem inputs, also failed/partial stores.
for path in sorted(work.glob('*/**/storage.json')):
 if 'persistent-stores' in path.parts:continue
 original=Path(json.loads(path.read_text())['path'])
 copy=work/'persistent-stores'/path.parent.relative_to(work)
 copy.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(original,copy,dirs_exist_ok=True)
unit={profile:judge_xml(work/(profile+'-final.xml'),0,(work/(profile+'-final.log')).read_text()) for profile in ('debug','asan','tsan')}
assert all(x['pass'] and x['tests']==11 for x in unit.values())
startup=json.loads((work/'startup-results.json').read_text());assert len(startup)==3 and all(x['exit']==0 for x in startup)
validation=json.loads((work/'validation-results.json').read_text());assert len(validation)==16 and all(x['exit']==0 for x in validation)
service=json.loads((work/'native-service/central-rejoin-1/result.json').read_text());assert service['pass'] and service['bootstrap_audit']['all_succeeded']
plan=json.loads((work/'native-service/plan.json').read_text())
different=[p for p,digest in plan['source_sha256'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=digest]
assert different==['tests/integration/someip/bootstrap_incidents_run.py'],different
acceptance={'scope':'Linux Host pre-proposal EpochStore/journal incident persistence; not all M9',
 'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
 'component':unit,'component_spool_audits':33,'expected_invalid_spools':6,
 'native_startup':{'profiles':['normal','asan','tsan'],'conditions_per_profile':7,'explicit_retry_per_profile':1,'processes_per_profile':17,'pass':True},
 'quiet_service':{'runs':1,'pass':True,'bootstrap_attempts':9,'auditors':4,'mutations_rejected':29,'unchanged_deadlines':True},
 'related_ctest':{'passed':32,'failed':0,'scope':'initial bootstrap tests plus existing journal/startup regression; strengthened epoch nonreuse test rerun in final component suite'},
 'python_tests':43,'reader_mutations_rejected':17,
 'static':{'translation_units':3,'clang_tidy_exit':0,'cppcheck_exit':0,'front_adapter_analysis_headers':'libstdc++11 compatibility workaround for clang14; production compiler retains libstdc++13'},
 'service_source_changes_after_run':{'files':different,'reason':'standalone startup failure runner gained sanitizer launch options; not used by service runtime','cpp_and_service_launcher_unchanged':True},
 'previous_attempts_retained':['initial GTest compile failed: two EXPECT_THROW macros shared a line; fixed','initial clang14/libstdc++13 chrono parse error; rerun with existing libstdc++11 analysis include workaround','initial cppcheck string_view passedByValue finding; changed to const reference','initial 3-profile component and 5-case/7-case native startup passes retained separately'],
 'limits':['No physical power-cut or whole-disk redundancy claim','No startup spool rotation/remote reconciliation/long-term capacity policy','First issue failure injected at real EpochStore component; native full-service regression exercises successful issue/re-INIT','Clock recovery, CARLA silent-loss subinterval, five remaining Power vehicle causes, loaded/long-duration timing and retention remain open']}
save(dest/'acceptance.json',acceptance)
shutil.copy2(work/'sources.json',dest/'sources.json');shutil.copy2(work/'sources.tar.gz',dest/'sources.tar.gz')
# Check captured source bytes before packaging.
source=json.loads((work/'sources.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==digest for p,digest in source['files'].items())
files=sorted(p for p in work.rglob('*') if (p.is_file() or p.is_symlink()) and p.name not in ('sources.tar.gz',))
with tarfile.open(dest/'validation.tar.gz','w:gz') as archive:
 for path in files:archive.add(path,arcname=path.relative_to(work),recursive=False)
checked=0;links=0
with tempfile.TemporaryDirectory(prefix='stratadrive-boot-replay-',dir='/var/tmp') as temp:
 replay=Path(temp)
 with tarfile.open(dest/'validation.tar.gz') as archive:
  for member in archive.getmembers():
   original=work/member.name
   if member.issym():assert member.linkname==os.readlink(original);links+=1;continue
   assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
   data=archive.extractfile(member).read();assert data==original.read_bytes();checked+=1
   path=replay/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
 audits=0
 for profile in ('normal','asan','tsan'):
  for folder in (replay/('startup-'+profile)).glob('*/incidents'):
   result=audit(folder);expected=json.loads((folder.parent/'audit.json').read_text());assert result==expected;audits+=1
 for profile in ('debug','asan','tsan'):
  for case in (replay/(profile+'-final-raw')).iterdir():
   invalid=case.name in ('MissingOrCorruptSpoolStopsBeforeOperation','FailedOutcomeCommitCannotReturnAnEpochOrOverwriteEvidence')
   try:result=audit(case/'incidents');assert not invalid
   except ValueError:assert invalid
   audits+=1
 replay_results=[]
 for name in ('native_service','service_ordering','service_timing','service_response'):
  command=[sys.executable,str(root/'tests/integration/diagnostics'/('audit_'+name+'.py')),str(replay/'native-service/central-rejoin-1'),'--mutations']
  result=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=180)
  assert result.returncode==0,(name,result.stdout[-1500:]);replay_results.append({'name':name,'exit':result.returncode})
 with tarfile.open(dest/'sources.tar.gz') as archive:
  for member in archive.getmembers():assert hashlib.sha256(archive.extractfile(member).read()).hexdigest()==source['files'][member.name]
 save(dest/'archive-verification.json',{'regular_files_byte_matched':checked,'symlink_targets_matched_without_following':links,'spool_replays':audits,'service_replays':replay_results,'source_hashes_checked':len(source['files'])})
print(json.dumps({'pass':True,'files':checked,'links':links,'audits':audits,'sources':len(source['files'])}))
