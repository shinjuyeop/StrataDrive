/* Keep SDK C-private headers out of the C++ transport diagnostic. */
#define _POSIX_C_SOURCE 200809L
#include <dds/dds.h>
#include <dds/ddsi/ddsi_entity_index.h>
#include <dds/ddsi/ddsi_whc.h>
#include "dds__entity.h"
#include <stdint.h>
#include <assert.h>
void lifecycle_snapshot(dds_entity_t writer,uint64_t out[6]) {
    dds_entity *entity;assert(dds_entity_pin(writer,&entity)==0);
    struct ddsi_writer *wr=((dds_writer *)entity)->m_wr;
    struct ddsi_thread_state *ts=ddsi_lookup_thread_state();ddsi_thread_state_awake(ts,&entity->m_domain->gv);
    ddsrt_mutex_lock(&wr->e.lock);struct ddsi_whc_state state;wr->whc->ops->get_state(wr->whc,&state);
    out[0]=(uintptr_t)wr;out[1]=(uintptr_t)wr->whc;out[2]=wr->seq;
    out[3]=state.min_seq;out[4]=state.max_seq;out[5]=state.unacked_bytes;
    ddsrt_mutex_unlock(&wr->e.lock);ddsi_thread_state_asleep(ts);dds_entity_unpin(entity);
}
