import csv,json,re,subprocess,hashlib
from pathlib import Path
root=Path('build/m5-dds-qualification')
symbols={}
def frames(stack,maps):
 resolved=[]
 for item in stack.split(';'):
  if not item:continue
  ip=int(item,16)
  for lo,hi,offset,path in maps:
   if lo<=ip<hi:
    offset=ip-lo+offset-1;key=(path,offset)
    if key not in symbols:
     output=subprocess.check_output(['addr2line','-f','-C','-e',path,hex(offset)],text=True).strip().splitlines()
     symbols[key]={'function':output[0],'location':output[1] if len(output)>1 else '?','binary':path,'offset':hex(offset)}
    resolved.append(symbols[key]);break
 return resolved
objects=[];packets=[];warnings=[]
for cohort in ['cohort-v6','followup-v7','lifetimes-v8','final-v9']:
 out=root/cohort
 for profile in ['normal','asan-ubsan','tsan']:
  for folder in sorted((out/profile).iterdir()):
   if not folder.is_dir():continue
   for log in [folder/'run.log',*folder.glob('*.stderr')]:
    if not log.exists():continue
    for i,b in enumerate(x for x in log.read_text(errors='replace').split('==================') if 'WARNING: ThreadSanitizer' in x):
     funcs=re.findall(r'^\s*#\d+ (.*?) (?:/d/|\.\./|<null>|\([^)]*\+0x)',b,re.M)
     family='OTHER-OPEN'
     for name,marker in [('BUCKET-GC','gc_buckets_cb'),('BUCKET-PUBLISH','ddsrt_chh_resize'),('WHC-GC','whc_free'),('WRITER-GC','gc_delete_writer'),('REMOTE-LEASE','ddsi_lease_renew'),('REMOTE-PUBLISH','ddsi_new_proxy'),('TKMAP','dds_tk_equals')]:
      if marker in b:family=name;break
     warnings.append({'cohort':cohort,'profile':profile,'case':folder.name,'file':str(log),'index':i,'family':family,'summary':next((s for s in b.splitlines() if s.startswith('SUMMARY:')),''),'functions':funcs})
   for f in folder.glob('*.csv'):
    if f.name.endswith(('.objects.csv','.proxy.csv','.alloc.csv')):continue
    for row in csv.DictReader(f.open()):
     if row['event'] in ['ingress','result']:
      packets.append({'cohort':cohort,'profile':profile,'case':folder.name,'role':f.stem,'epoch':int(row['epoch']),'token':int(row['token']),'source_ns':int(row['source_ns']),'deadline_ns':int(row['deadline_ns']),'received_ns':int(row['time_ns']),'latency_ns':int(row['time_ns'])-int(row['source_ns']),'accepted':row['accepted']=='1'})
  if cohort not in ('lifetimes-v8','final-v9'):continue
  folder=out/profile/'lifetime'
  for f in folder.glob('*.objects.csv'):
   prefix=str(f)[:-len('.objects.csv')];alloc=list(csv.DictReader(open(prefix+'.alloc.csv')))
   maps=[]
   for line in Path(prefix+'.maps').read_text().splitlines():
    fields=line.split()
    if len(fields)>=6 and fields[-1].startswith('/'):
     lo,hi=(int(x,16) for x in fields[0].split('-'));maps.append((lo,hi,int(fields[2],16),fields[-1]))
   targets={}
   for r in csv.DictReader(f.open()):
    for kind in ['writer','whc']:
     key=(kind,int(r[kind],16));t=int(r['time_ns']);targets.setdefault(key,[]).append((t,t))
   for r in csv.DictReader(open(prefix+'.proxy.csv')):
    for kind in ['proxy','participant','lease']:
     key=(kind,int(r[kind]));targets.setdefault(key,[]).append((int(r['last_access_ns']),int(r['scope_end_ns'])))
   for (kind,ptr),times in targets.items():
    if not ptr:continue
    first=min(t[0] for t in times);last=max(t[0] for t in times);scope=max(t[1] for t in times)
    allocations=[r for r in alloc if int(r['pointer'],16)==ptr and r['event'] in ['M','C','N'] and int(r['time_ns'])<=first]
    frees=[r for r in alloc if int(r['pointer'],16)==ptr and r['event']=='F' and int(r['time_ns'])>=first]
    created=max(allocations,key=lambda r:int(r['time_ns'])) if allocations else None
    freed=min(frees,key=lambda r:int(r['time_ns'])) if frees else None
    objects.append({'cohort':cohort,'profile':profile,'role':f.stem.split('.')[0],'kind':kind,'pointer':hex(ptr),'first_access_ns':first,'last_observed_access_ns':last,'scope_end_ns':scope,'allocation_ns':int(created['time_ns']) if created else None,'free_entry_ns':int(freed['time_ns']) if freed else None,'free_after_observed_scope':scope<=int(freed['time_ns']) if freed else None,'allocation_frames':frames(created['stack'],maps) if created else [],'free_frames':frames(freed['stack'],maps) if freed else [],'limit':'last OBSERVED diagnostic access, not a claim of last access by all SDK threads'})
(root/'objects.json').write_text(json.dumps(objects,indent=2)+'\n')
(root/'warnings.json').write_text(json.dumps(warnings,indent=2)+'\n')
with (root/'packets.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(packets[0]),lineterminator='\n');w.writeheader();w.writerows(packets)
counts={p:{'objects':sum(r['profile']==p for r in objects),'missing_allocation':sum(r['profile']==p and r['allocation_ns'] is None for r in objects),'missing_free':sum(r['profile']==p and r['free_entry_ns'] is None for r in objects),'observed_scope_violations':sum(r['profile']==p and r['free_after_observed_scope'] is False for r in objects)} for p in ['normal','asan-ubsan','tsan']}
summary={'cohorts':{},'object_observations':counts,'warning_families':{},'packet_observations':len(packets),'interpretation':'No source/binary identity conflation; warnings count is not defect count. Observed scope ordering does not prove all remote/lease callback interleavings safe.'}
for cohort in ['cohort-v6','followup-v7','lifetimes-v8','final-v9']:
 rows=json.loads((root/cohort/'results.json').read_text());summary['cohorts'][cohort]={p:{'PASS':sum(r['profile']==p and r['verdict']=='PASS' for r in rows),'FAIL':sum(r['profile']==p and r['verdict']=='FAIL' for r in rows),'warnings':sum(r['profile']==p and r['tsan_warnings'] for r in rows)} for p in ['normal','asan-ubsan','tsan']}
for r in warnings:summary['warning_families'][r['family']]=summary['warning_families'].get(r['family'],0)+1
(root/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
