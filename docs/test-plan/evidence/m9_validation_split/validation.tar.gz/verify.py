from pathlib import Path
import hashlib,tarfile,json,subprocess
base=Path('build/m9-validation-split');out=Path('docs/test-plan/evidence/m9_validation_split');rows=[]
for archive in sorted(out.glob('normal-r*.tar.gz')):
 count=0
 with tarfile.open(archive) as tar:
  for member in tar:
   if not member.isfile():continue
   data=tar.extractfile(member).read();original=base/member.name
   assert original.is_file(),member.name
   assert hashlib.sha256(data).digest()==hashlib.sha256(original.read_bytes()).digest(),member.name
   count+=1
 rows.append({'archive':archive.name,'files_compared':count,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()})
rechecks=[]
for index,(archive,case,reader) in enumerate([('normal-r1.tar.gz','normal-normal','audit_native_service.py'),('normal-r3.tar.gz','normal-stop-ack-loss-r3','audit_native_service_faults.py')]):
 root=base/'archive-recheck'/str(index);root.mkdir(parents=True,exist_ok=False);prefix='service-campaign/'+case
 with tarfile.open(out/archive) as tar:
  for member in tar:
   if member.name==prefix or member.name.startswith(prefix+'/'):
    assert not member.name.startswith('/') and '..' not in Path(member.name).parts
    tar.extract(member,root)
 command=['python3','tests/integration/diagnostics/'+reader,str(root/prefix/'central-rejoin-1'),'--mutations']
 with (root/'audit.log').open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 rechecks.append({'archive':archive,'case':case,'reader':reader,'exit':r.returncode});assert r.returncode==0
report={'native_archives':rows,'file_count':sum(r['files_compared'] for r in rows),'archive_rechecks':rechecks}
(base/'archive-verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
