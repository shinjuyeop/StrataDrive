from pathlib import Path
import sys,json,hashlib
root=Path.cwd();sys.path[:0]=[str(root/'tests/integration/someip'),str(root/'tests/integration/diagnostics')]
from sdk_outcomes import sdk_outcomes
import audit_native_service as normal
import audit_native_service_faults as fault
base=root/'build/m9-validation-split';old=root/'build/m9-egress/service-campaign';rows=[]
for prior in json.loads((old/'results.json').read_text()):
 directory=old/prior['name']/'central-rejoin-1';path=directory/'result.json';digest=hashlib.sha256(path.read_bytes()).hexdigest()
 result=json.loads(path.read_text());expected,unexpected=sdk_outcomes(directory,result)
 reader=normal if prior['fault']=='normal' else fault
 row={'name':prior['name'],'original_runtime_pass':result['pass'],'original_sdk_errors':result['sdk_errors'],
      'original_audit_exit':prior['audit_exit'],'new_expected':expected,'new_unexpected':unexpected,'original_result_sha256':digest}
 try:
  data=reader.load(directory)
  data['result']=dict(data['result'],expected_sdk_faults=expected,unexpected_sdk_errors=unexpected,sdk_errors=bool(unexpected))
  row['new_audit_report']=reader.judge(data);row['new_audit_exit']=0
 except (ValueError,KeyError,OSError,IndexError) as error:row.update(new_audit_exit=1,new_audit_error=str(error))
 assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
 rows.append(row);(base/'reclassification.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'cases':len(rows),'original_audit_pass':sum(r['original_audit_exit']==0 for r in rows),
                  'new_audit_pass':sum(r['new_audit_exit']==0 for r in rows),'changed':[r['name'] for r in rows if r['original_audit_exit']!=r['new_audit_exit']]},indent=2))
