from pathlib import Path
import importlib.util,json,subprocess,sys,time
base=Path('build/m9-validation-split')
spec=importlib.util.spec_from_file_location('suite','tests/integration/diagnostics/service_sanitizer_suite.py');suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
rows=[]
def run(name,cmd):
 (base/'phase.json').write_text(json.dumps({'phase':name,'ns':time.monotonic_ns()})+'\n')
 with (base/(name+'.log')).open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'preflight.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for profile,directory in [('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 run(profile+'-build',['cmake','--build',directory,'--parallel','2','--target',*suite.TARGETS])
for profile,directory in [('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 run(profile+'-suite',['python3','tests/integration/diagnostics/service_sanitizer_suite.py',str(base/(profile+'-suite')),'--build',directory,'--profile',profile])
run('normal-wall',['build/m1-angle/m4_async_runtime_test','--gtest_filter=M4AsyncWall.*','--gtest_output=xml:'+str((base/'normal-wall.xml').resolve())])
for file in ('service_validation_test.py','someip_pilot_test.py','sdk_stages_test.py'):
 run(file,['python3','tests/unit/'+file])
(base/'phase.json').write_text(json.dumps({'phase':'preflight-complete'})+'\n')
