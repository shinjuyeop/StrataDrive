from pathlib import Path
import json,subprocess,hashlib,sys
base=Path('build/m9-validation-split')
pre=json.loads((base/'preflight.json').read_text());assert len(pre)==8 and all(r['exit']==0 for r in pre),pre
for name,command in [
 ('reclassification',['python3',str(base/'reclassify.py')]),
 ('source-snapshot',['python3',str(base/'snapshot.py')]),
 ('native-campaign',['python3','tests/integration/someip/service_timing_campaign.py',str(base/'service-campaign'),'--validation-profile','split-v1','--split-owner-io','--separate-aux-io','--owner-fifo','--response-audit','--defer-audits'])]:
 (base/'phase.json').write_text(json.dumps({'phase':name})+'\n')
 with (base/(name+'.log')).open('w') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
(base/'phase.json').write_text(json.dumps({'phase':'validation-complete'})+'\n')
