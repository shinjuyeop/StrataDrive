from pathlib import Path
import json,hashlib,tarfile,shutil,xml.etree.ElementTree as ET
root=Path.cwd();base=root/'build/m9-validation-split';out=root/'docs/test-plan/evidence/m9_validation_split';out.mkdir(exist_ok=False)
source=json.loads((base/'runtime-sources.json').read_text())
for p,h in source.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==h,p
campaign=base/'service-campaign';manifest=json.loads((campaign/'manifest.json').read_text());rows=json.loads((campaign/'results.json').read_text())
assert len(rows)==18 and len({r['name'] for r in rows})==18
binary=root/'build/m5-someip-normal/project/tests/integration/someip/someip_front_adapter'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binaries']['normal']
old=json.loads((root/'build/m9-egress/service-campaign/manifest.json').read_text())
assert manifest['binaries']['normal']==old['binaries']['normal']
cpp=json.loads((root/'build/m9-egress/runtime-sources.json').read_text())
cpp={p:h for p,h in cpp.items() if Path(p).suffix in ('.cpp','.hpp','.cmake') or Path(p).name=='CMakeLists.txt'}
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in cpp.items())
for repeat in (1,2,3):
 group=[r for r in rows if (r['name'].endswith('-r'+str(repeat)) if repeat>1 else not r['name'].endswith(('-r2','-r3')))]
 assert len(group)==6
 with tarfile.open(out/('normal-r'+str(repeat)+'.tar.gz'),'w:gz',compresslevel=6) as tar:
  for row in group:
   name=row['name'];tar.add(campaign/name,arcname='service-campaign/'+name)
   for p in sorted(campaign.glob(name+'.*.log')):tar.add(p,arcname='service-campaign/'+p.name)
with tarfile.open(out/'validation.tar.gz','w:gz',compresslevel=6) as tar:
 for p in sorted(base.iterdir()):
  if p.is_file() and p.suffix!='.gz':tar.add(p,arcname=p.name)
 for name in ('asan-suite','tsan-suite'):tar.add(base/name,arcname=name)
 for p in sorted(campaign.glob('*.json')):tar.add(p,arcname='service-campaign/'+p.name)
reports={}
for profile in ('asan','tsan'):
 directory=root/('build/m1-angle-sanitized' if profile=='asan' else 'build/m9-service-timing/tsan-unit')
 recorded=json.loads((base/(profile+'-suite/manifest.json')).read_text())['binaries']
 assert all(hashlib.sha256((directory/target).read_bytes()).hexdigest()==digest for target,digest in recorded.items())
 result=json.loads((base/(profile+'-suite/results.json')).read_text())
 reports[profile]={'targets':len(result),'tests':sum(r.get('tests',0) for r in result),'pass':all(r['pass'] for r in result),'result':result}
wall=ET.parse(base/'normal-wall.xml').getroot()
summary={'scope':'M9 Host quiet native service, separate sanitizer component/logical gates; not whole M9/Target',
         'native_cases':18,'native_pass':sum(not any(r[f] for f in ('audit_exit','ordering_exit','timing_exit','response_exit')) for r in rows),
         'sanitizers':reports,'noninstrumented_wall_tests':int(wall.get('tests')),'noninstrumented_wall_failures':int(wall.get('failures')),
         'unchanged_cpp_cmake_files':len(cpp),'unchanged_native_binary':True,'sources_verified':len(source)}
for name in ('runtime-sources.json','runtime-sources.tar.gz','preflight.json','reclassification.json','harness-timeout-review.json'):
 shutil.copy2(base/name,out/name)
(out/'results.json').write_text(json.dumps({'manifest':manifest,'results':rows},indent=2)+'\n')
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='sanitizers'},indent=2))
