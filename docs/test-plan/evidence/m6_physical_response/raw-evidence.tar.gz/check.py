from pathlib import Path
import subprocess,json,time,fcntl
root=Path.cwd();out=root/'build/m6-physical-response';rows=[]
def run(name,argv,timeout=300,lock=True):
    row={'name':name,'argv':argv,'start_ns':time.time_ns(),'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()};rows.append(row)
    with (out/(name+'.txt')).open('w') as log:
        try:
            with (root/'build/.m4-exclusive.lock').open('a') as guard:
                if lock:fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
                row['exit']=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except Exception as e:row.update(exit=1,error=repr(e))
    row['end_ns']=time.time_ns();(out/'checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,row['exit'],flush=True)
    return row['exit']==0
if not run('dev-configure',['cmake','-S','.','-B','build/m4-readiness']):raise SystemExit(1)
if not run('dev-contract-build',['cmake','--build','build/m4-readiness','--target','m6_physical_response_test','--parallel','4']):raise SystemExit(1)
run('dev-contract',['ctest','--test-dir','build/m4-readiness','-R','^M6PhysicalResponse\.','--output-on-failure'])
run('dev-sdk-build',['cmake','--build','build/m5-someip-normal/project','--target','someip_front_adapter','--parallel','4'])
