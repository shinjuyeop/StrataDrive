exec(open('build/m6-physical-response/check.py').read().split("if not run('dev-configure'")[0])
for label,path in [('normal','build/m4-readiness'),('asan','build/m1-angle-sanitized')]:
    if run('final-'+label+'-configure',['cmake','-S','.','-B',path]) and run('final-'+label+'-build',['cmake','--build',path,'--parallel','4']):
        run('final-full-'+label,['ctest','--test-dir',path,'--output-on-failure','--output-junit',str(out/('full-'+label+'.xml'))],360)
if run('tsan-configure',['cmake','-S','.','-B','build/m4-contract-tsan-final']) and run('tsan-build',['cmake','--build','build/m4-contract-tsan-final','--target','m6_physical_response_test','vehicle_energy_test','async_owner_test','--parallel','4']):
    run('final-boundary-tsan',['setarch','x86_64','-R','ctest','--test-dir','build/m4-contract-tsan-final','-R','^(M6PhysicalResponse\.|VehicleEnergy\.|EnergyScenario\.|AsyncOwnerTest\.|AsyncZoneOwner\.)','--output-on-failure','--output-junit',str(out/'boundary-tsan.xml')])
for suite in ['m6_physical_response','m6_energy','m6_model','someip_pilot']:
    run('final-python-'+suite,['python3',f'tests/unit/{suite}_test.py'])
raise SystemExit(1 if any(r.get('exit',1) for r in rows) else 0)
