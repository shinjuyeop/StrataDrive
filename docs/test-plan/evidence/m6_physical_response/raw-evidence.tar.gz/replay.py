exec(open('build/m6-physical-response/check.py').read().split("if not run('dev-configure'")[0])
if not run('replay-build',['cmake','--build','build/m4-readiness','--target','m6_physical_response_test','--parallel','4']):raise SystemExit(1)
run('replay-old100',['env','STRATADRIVE_M6_REPLAY_DEADLINE_NS=100000000','build/m4-readiness/m6_physical_response_test','--gtest_filter=M6PhysicalResponse.ModelCompletionAgainstSelectedDeadline'])
from sys import path
path.insert(0,'tests/integration/someip')
from physical_response import contract
run('replay-new230',['env','STRATADRIVE_M6_REPLAY_DEADLINE_NS='+str(contract()['selection_to_observed_complete_ns']),'build/m4-readiness/m6_physical_response_test','--gtest_filter=M6PhysicalResponse.ModelCompletionAgainstSelectedDeadline'])
