exec(open('build/m6-physical-response/check.py').read().split("if not run('dev-configure'")[0])
if not run('fixed-sdk-build',['cmake','--build','build/m5-someip-normal/project','--target','someip_front_adapter','--parallel','4']):raise SystemExit(1)
run('fixed-sdk-command-loss',['python3','tests/integration/someip/front_run.py',str(out/'fixed-sdk-command-loss'),'--three','--fault-zone','rear','--native-watch','--fifo','--simple-vehicle','--energy-cycle','nominal','--profile','normal','--cases','command-loss'],35,False)
