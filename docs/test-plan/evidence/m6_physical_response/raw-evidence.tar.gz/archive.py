from pathlib import Path
import hashlib,json,tarfile
raw=Path('build/m6-physical-response');out=Path('docs/test-plan/evidence/m6_physical_response')
files=sorted(p for p in raw.rglob('*') if p.is_file());manifest=[{'path':str(p.relative_to(raw)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
(out/'raw-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=out/'raw-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(raw)),recursive=False)
with tarfile.open(archive) as tar:
 assert len(tar.getmembers())==len(files)
 for row in manifest:assert hashlib.sha256(tar.extractfile(row['path']).read()).hexdigest()==row['sha256']
(out/'archives.json').write_text(json.dumps({'file':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(files),'verified_all_members':True},indent=2)+'\n')
print(archive.stat().st_size,len(files))
