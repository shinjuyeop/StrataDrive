exec(open('build/m6-physical-response/check.py').read().split("if not run('dev-configure'")[0])
if not run('final-sdk-normal-build',['cmake','--build','build/m5-someip-normal/project','--target','someip_front_adapter','--parallel','4']):raise SystemExit(1)
flags=['--three','--fault-zone','rear','--native-watch','--fifo','--simple-vehicle','--energy-cycle','nominal','--profile','normal']
for case in ['command-loss','normal']:
    run('final-sdk-'+case,['python3','tests/integration/someip/front_run.py',str(out/('final-sdk-'+case)),*flags,'--cases',case],35,False)
