exec(open('build/m6-physical-response/check.py').read().split("if not run('dev-configure'")[0])
import tempfile
for suite in ['m6_physical_response','m6_energy','m6_model','someip_pilot']:
    run('oracle-final-'+suite,['python3',f'tests/unit/{suite}_test.py'])
with tempfile.TemporaryDirectory(prefix='stratadrive-m6-response-') as folder:
    archive=subprocess.Popen(['git','archive','HEAD'],stdout=subprocess.PIPE)
    subprocess.run(['tar','-x','-C',folder],stdin=archive.stdout,check=True);archive.stdout.close()
    if archive.wait():raise RuntimeError('git archive failed')
    assert not (Path(folder)/'build').exists()
    for suite in ['m6_physical_response','m6_energy','m6_model','someip_pilot']:
        run('fresh-'+suite,['python3',folder+f'/tests/unit/{suite}_test.py'])
    (out/'fresh-checkout.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'method':'complete git archive HEAD; no build/ initially','suites':['m6_physical_response','m6_energy','m6_model','someip_pilot'],'build_created_by_lock_regression':(Path(folder)/'build').exists(),'sdk_executed':False},indent=2)+'\n')
