from pathlib import Path
import json,csv,hashlib,subprocess,sys,os,resource,xml.etree.ElementTree as E
root=Path.cwd();raw=root/'build/m6-physical-response';out=root/'docs/test-plan/evidence/m6_physical_response';out.mkdir(exist_ok=True)
def load(p):return json.loads(p.read_text())
def save(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):return list(csv.DictReader(p.open()))
def write(name,rs):
 with (out/name).open('w') as f:w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
sys.path.insert(0,str(root/'tests/integration/someip'));from physical_response import contract,response_oracle
sdk=[]
for name,case in [('final-sdk-command-loss','command-loss'),('final-sdk-normal','normal'),('fixed-sdk-command-loss','command-loss')]:
 p=raw/name/(case+'-1');r=load(p/'result.json');plan=load(raw/name/'plan.json');sdk.append({'cohort':name,'case':case,'source':plan['source'],'binary_sha256':plan['binary_sha256'],'exit':load(raw/name/'results.json')[0]['exit'],'pass':r['pass'],'errors':r.get('rear',{}).get('errors',[]),'sdk_errors':len(r['unexpected_sdk_errors']),'sanitizer_diagnostics':r['sanitizer_diagnostics'],'forced_cleanup':r['forced_cleanup'],'native_misses':sum(x['misses'] for x in r['native']['processes']),'normal_prerequisite':True,'raw':name+'/'+case+'-1/result.json'})
write('results.csv',[{k:v if not isinstance(v,(dict,list)) else json.dumps(v) for k,v in r.items()} for r in sdk])
checks={}
for label in ['development','replay','first-sdk','fixed-sdk','final-regression']:
 checks[label]=load(raw/(label+'-checks.json'))
checks['final-bookkeeping']=load(raw/'final-bookkeeping-checks.json')
checks['actual-tsan']=load(raw/'checks.json')
unit={}
for label in ['normal','asan','tsan']:
 f=raw/('actual-boundary-tsan.xml' if label=='tsan' else 'full-'+label+'.xml');cases=E.parse(f).getroot().findall('.//testcase');unit[label]={'tests':len(cases),'failed':sum(c.find('failure') is not None or c.find('error') is not None for c in cases),'xml':f.name}
 for oldlabel in ([label] if label!='tsan' else []):
  old=E.parse(root/'build/m6-vehicle-energy'/('full-'+oldlabel+'.xml')).getroot().findall('.//testcase');names=lambda cs:{c.get('name') for c in cs};unit[label]['previous_1011_names_preserved']=names(old)<=names(cases)
p=raw/'fixed-sdk-command-loss/command-loss-1';r=load(p/'result.json');verdict=response_oracle(p,r);assert verdict['pass'],verdict
save(out/'response-result.json',verdict);save(out/'old-reanalysis.json',load(raw/'old-reanalysis.json'));save(out/'offline-reanalysis.json',load(raw/'final-offline-reanalysis.json'))
# Complete event timeline; model crossings are brackets, not interpolated exact times.
timeaxis=[]
def event(cohort,name,ns,origin,note=''):
 timeaxis.append({'cohort':cohort,'event':name,'ns':ns,'from_injection_ms':(ns-origin)/1e6 if ns is not None else None,'meaning':note})
injection=verdict['injection_ns'];event('new','injection',injection,injection)
for name,key in [('last_valid_rx','last_valid_rx_ns'),('original_source','source_ns'),('original_expiry','original_expiry_ns'),('loss_detected','detected_ns')]:event('new',name,verdict['loss'][key],injection)
for leaf in ['drive','brake']:
 d=verdict[leaf]
 for name,ns in [('detection_service_enter',d['detection_interval_ns'][0]),('fault_observed_after_service',d['detection_interval_ns'][1]),('target_selected_output',d['selection_observed_ns']),('selection_ack',d['selection_ack_ns']),('application_step_begin',d['application_interval_ns'][0]),('application_step_return',d['application_interval_ns'][1])]:event('new',leaf+'_'+name,ns,injection)
rs=rows(p/'physical-response.csv')
for leaf,predicate in [('torque',lambda r:abs(float(r['torque_nm']))<=1),('brake',lambda r:float(r['pressure_pa'])>=1000000)]:
 selected=verdict['drive' if leaf=='torque' else 'brake']['selection_observed_ns'];matches=[(i,row) for i,row in enumerate(rs) if int(row['model_ns'])>=selected and predicate(row)]
 i,row=matches[0];event('new',leaf+'_last_incomplete_model_sample',int(rs[i-1]['model_ns']) if i else None,injection,'lower crossing bound');event('new',leaf+'_first_complete_model_sample',int(row['model_ns']),injection,'upper crossing bound; actual sampled model output')
for name,key in [('combined_first_model_complete','first_model_complete_ns'),('combined_first_10ms_CSV_complete','first_10ms_complete_ns')]:event('new',name,verdict[key],injection)
oldp=root/'build/m6-vehicle-energy/final-normal-faults/command-loss-1';oldr=load(oldp/'result.json');oi=int((oldp/'inject').read_text());ev=rows(oldp/'rear-1.leaf-events.csv');ex=[e for e in ev if e['event']=='command-expired' and int(e['owner'])==4 and int(e['ns'])>=oi][0];rx=[e for e in ev if e['event']=='valid-input' and int(e['owner'])==4 and int(e['detail'])==1 and e['source']==ex['source'] and e['deadline']==ex['deadline']][-1]
for name,ns in [('injection',oi),('last_valid_rx',int(rx['ns'])),('original_expiry',int(ex['deadline'])),('loss_detected',int(ex['ns'])),('rear_selection_ack',next(x['summary']['selected_ns'] for x in oldr['processes'] if x['role']=='rear')),('first_100kPa_and_zero_10ms_observation',611255445394924),('first_1MPa_complete',None)]:event('old',name,ns,oi,'historical raw exit1 unchanged')
write('timeline.csv',timeaxis)
oldsummary={'rx_to_detection_ms':(int(ex['ns'])-int(rx['ns']))/1e6,'injection_to_detection_ms':(int(ex['ns'])-oi)/1e6,'injection_to_selection_ack_ms':(next(x['summary']['selected_ns'] for x in oldr['processes'] if x['role']=='rear')-oi)/1e6}
save(out/'results-summary.json',{'implementation_sources':['5f1ef49','02d78ec','a32de13'],'contract':contract(),'sdk_runs':sdk,'sdk_denominator':{'total':3,'pass':2,'fail':1,'retained_first_observer_failure':1,'post_fix_changed_case':{'command_loss':{'pass':1,'total':1}},'unaffected_normal':{'pass':1,'total':1}},'cpp':unit,'excluded_uninstrumented_tsan':{'tests':35,'raw_pass':True,'eligible_for_tsan':False,'reason':'actual CMake option OFF/no instrumentation symbols'},'python':{'final':{'tests':54,'pass':54},'fresh_no_build':{'tests':54,'pass':54}},'checks':checks,'old_timing':oldsummary,'scoped_open01':'resolved model/deadline mismatch; old raw FAIL remains; old1MPa completion not observed','open02':'retained: sanitizer full SDK functionality incomplete; no new full SDK sanitizer runs','not_run':['charge-zero','owner-pause','restart-live','new load combinations','48 timing','whole SDK ASan/TSan','M7','M8','Jetson'],'acceptance':'M6 Host quiet functional SIL vehicle/EV energy + modeled physical protection limited acceptance; not whole M6 exit'})
# CPU/policy/netns snapshots and mapped SDK libraries remain in each raw case.
oldinst=load(root/'build/m6-vehicle-energy/instrumentation.json');libs=[]
for lib in oldinst['profiles']['normal']['libraries']:
 f=Path(lib['path']);libs.append({'path':str(f),'sha256':sha(f),'same_as_previous':sha(f)==lib['sha256']})
bins={}
for label,build in [('normal','m4-readiness'),('asan','m1-angle-sanitized'),('tsan','m6-response-tsan')]:
 f=root/'build'/build/'m6_physical_response_test';undefined=subprocess.check_output(['nm','-u',str(f)],text=True);cache=(f.parent/'CMakeCache.txt').read_text();flags={}
 for line in cache.splitlines():
  if line.startswith(('CMAKE_BUILD_TYPE:','CMAKE_CXX_COMPILER:','CMAKE_CXX_FLAGS')):k,v=line.split('=',1);flags[k]=v
 bins[label]={'flags_make':(f.parent/'CMakeFiles/m6_physical_response_test.dir/flags.make').read_text(),'link_txt':(f.parent/'CMakeFiles/m6_physical_response_test.dir/link.txt').read_text(),'path':str(f.relative_to(root)),'sha256':sha(f),'asan':'__asan_' in undefined,'ubsan':'__ubsan_' in undefined,'tsan':'__tsan_' in undefined,'cmake':flags,'sdk_linked':False}
save(out/'instrumentation.json',{'sdk_version':'vSomeIP3.7.6','sdk_commit':subprocess.check_output(['git','-C','build/m5-someip-deps/vsomeip','rev-parse','HEAD'],text=True).strip(),'sdk_worktree':subprocess.check_output(['git','-C','build/m5-someip-deps/vsomeip','status','--short'],text=True),'actual_sdk_profile':'Normal only this campaign; Normal SDK/Boost are not instrumented','sdk_libraries':libs,'boundary_binaries':bins,'system_dependencies':'system libc/libstdc++ not instrumented; C++ tests do not link vSomeIP. Prior instrumented SDK failures unchanged','excluded_initial_tsan':'build/m4-contract-tsan-final had STRATADRIVE_TSAN=OFF;35/35 functional only, raw kept', 'compiler':subprocess.check_output(['c++','--version'],text=True).splitlines()[0]})
save(out/'environment.json',{'uname':subprocess.check_output(['uname','-a'],text=True).strip(),'lscpu':subprocess.check_output(['lscpu','-e=CPU,CORE,SOCKET,ONLINE'],text=True),'allowed_cpus':sorted(os.sched_getaffinity(0)),'uid':os.getuid(),'rtprio':resource.getrlimit(resource.RLIMIT_RTPRIO),'timezone':'Asia/Seoul','changes':'none; existing user RT20 permission retained','runtime_policy_records':'raw: each SDK case central/front/rear/plant.runtime.json and *.maps/sockets/network/capture'})
# Independent curves from raw model observations, no interpolation as evidence.
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,axes=plt.subplots(2,1,sharex=True,figsize=(9,6))
for tag,folder in [('old 10ms sample',oldp),('new model sample',p)]:
 source=rows(folder/('physical.csv' if folder==oldp else 'physical-response.csv'));inj=oi if folder==oldp else injection
 nskey='ns' if folder==oldp else 'model_ns';tkey='torque' if folder==oldp else 'torque_nm';pkey='pressure' if folder==oldp else 'pressure_pa'
 source=[x for x in source if -20<= (int(x[nskey])-inj)/1e6<=280]
 x=[(int(y[nskey])-inj)/1e6 for y in source]
 axes[0].plot(x,[float(y[tkey]) for y in source],label=tag);axes[1].plot(x,[float(y[pkey])/1e6 for y in source],label=tag)
for a in axes:a.axvline(100,color='r',linestyle=':',label='old injection+100ms');a.axvline((verdict['origin_ns']-injection)/1e6+230,color='g',linestyle='--',label='new selection+230ms');a.grid();a.legend(fontsize=8)
axes[0].set_ylabel('Actual torque [Nm]');axes[1].set_ylabel('Actual brake [MPa]');axes[1].set_xlabel('From injection [ms]');axes[1].axhline(1,color='k',linestyle=':');fig.tight_layout();fig.savefig(out/'physical-response.svg');plt.close(fig)
