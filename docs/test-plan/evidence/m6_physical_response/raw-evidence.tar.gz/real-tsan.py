exec(open('build/m6-physical-response/check.py').read().split("if not run('dev-configure'")[0])
build='build/m6-response-tsan'
if run('actual-tsan-configure',['cmake','-S','.','-B',build,'-DSTRATADRIVE_TSAN=ON','-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_CXX_FLAGS=-fno-pie','-DCMAKE_EXE_LINKER_FLAGS=-no-pie']) and run('actual-tsan-build',['cmake','--build',build,'--target','m6_physical_response_test','vehicle_energy_test','async_owner_test','--parallel','4']):
    run('actual-boundary-tsan',['setarch','x86_64','-R','ctest','--test-dir',build,'-R','^(M6PhysicalResponse\.|VehicleEnergy\.|EnergyScenario\.|AsyncOwnerTest\.|AsyncZoneOwner\.)','--output-on-failure','--output-junit',str(out/'actual-boundary-tsan.xml')])
