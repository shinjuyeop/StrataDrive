#pragma once
#include "diagnostics_journal.hpp"

namespace stratadrive::diagnostics {
struct EpochRetention {
    Limits limits{};
    std::uint32_t rotate_after_entries{256}, maximum_segments{1024};
};
// Opt-in local single-writer journal family. Auto rollover at a NEW application
// epoch; retained DTCs survive while the active event/receipt window is reclaimed.
// Predecessor bytes are immutable and remain required for duplicate receipts and
// restart verification. No RT IO, silent deletion, synthetic epoch or authority.
class EpochRecorder {
public:
    static void initialize(const std::string& root,std::uint64_t store_id,EpochRetention = {});
    explicit EpochRecorder(const std::string& root);
    ~EpochRecorder();
    EpochRecorder(const EpochRecorder&)=delete;
    EpochRecorder& operator=(const EpochRecorder&)=delete;
    Receipt record(const Event&);
    Receipt clear(const Clear&);
    Receipt review(const ContinuityReview&);
    std::size_t drain(EventQueue&,std::size_t budget=EventQueue::kCapacity);
    void recording_gap() noexcept;
    const Ledger& ledger() const noexcept;
    std::uint64_t segment() const noexcept;
    std::uint64_t watermark() const noexcept;
    // Stable family identity and 1-based committed ordinals across rollover.
    // Cold reads verify retained segments; no flattened/unbounded event vector.
    std::uint64_t store_id() const noexcept;
    static constexpr std::uint32_t registry_revision() noexcept { return 4; }
    Entry committed(std::uint64_t ordinal) const;
    // Fixed merge membership, persisted before the first merged entry. A
    // restart cannot silently drop an unavailable source from its barrier.
    void bind_merge_sources(std::vector<std::uint64_t> streams);
    void restarted() noexcept;
private:
    struct Impl;std::unique_ptr<Impl> impl_;
};
} // namespace stratadrive::diagnostics
