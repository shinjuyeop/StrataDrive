from pathlib import Path

def replace(name, old, new):
 p=Path(name);s=p.read_text();assert old in s,(name,old);p.write_text(s.replace(old,new))
replace('docs/interfaces/diagnostics.md','실제 native ECU의 서비스 요청 인증/인가·\nquiesce adapter·물리 표본 취득·remote clear/RPC·Target 연결은 후속이며, native 재합류만으로\n심사가 실행되지 않는다.', 'Linux 로컬 요청·인가·Actual adapter 연결은 아래 별도 계약을 따른다. 실제3-ECU의\nowner/SDK quiesce·물리 정지 조합·원격 서비스 운용/Target 연결은 후속이며, native 재합류만으로\n심사가 실행되지 않는다.')
replace('docs/interfaces/diagnostics.md','## 다음 구현 경계','''## Linux 로컬 서비스 요청과 Actual 취득 연결

`ContinuityService`는 별도 비실시간 단일 writer다. 연결된 AF_UNIX/SOCK_SEQPACKET의
SO_PEERCRED UID/PID와 provision된16-byte nonzero boot capability를 검사한다. Caller는 private
listener와 유한 accept scheduling을 소유한다. 원격 네트워크 인증·사용자 계정 체계가 아니며
수신 요청으로 actor/run/Session/incident/manifest를 만들지 않는다. 매 서비스 lifetime에 새 actor를
provision하고 같은 producer의 과거 event가 있으면 시작을 거절한다.

| 로컬 v1 packet | 규칙 |
| --- | --- |
| 요청76byte | SDS/version1, capability16, 요청번호 uint64, Session(run64/epoch32), incident EventId24, revision64, operation8, disposition8, reserved16=0. 다중 byte 정수는 LE |
| Review | operation1/AcceptUnknownHistory1. 요청번호 n의 proof/Review/Passed sequence는4n−3/4n−2/4n−1. 정확한 현재 revision만 수용 |
| Clear | 별도 operation2/disposition0. sequence4n. 이번 서비스의 성공한 Passed ID/현재 revision/동일 전체 stream cut와 새로운 정지 evidence를 요구 |
| 응답32byte | SDR/version1, 요청번호64, durable watermark64, revision64, status8, stage8, inspector block8, reserved8=0. Receipt는 과거 결과이며 현재 control 권한이 아님 |
| 유한 재요청 | 번호1..floor(UINT64_MAX/4), 최대32개 증가 요청. 동일 번호/bytes는 원래 receipt, 다른 bytes/역행은 거절. 부팅 capability/actor를 재사용하지 않으며 영속 재요청 DB는 아님 |

물리 evidence는 요청 packet에서 받지 않는다. Trusted `ContinuityCapture::acquire`가 반환한
`FrozenContinuity` guard가 전체 source/replica/queue/실제 ACK 경계를 검사부터 commit까지
소유한다. Normal dispatch 차단은 진단 guard 해제와 독립적으로 유지한다. 이 인터페이스만으로
다른 process의 RT/SDK 생산자를 정지시켰다고 주장하지 않는다. 실제 구성의 adapter가 그 책임을 진다.

`capture_service_evidence`에는 같은 owner cycle에서 받은 `feedback()`/`current_sample(now)`만
공급한다. last_accepted history를 최신 입력으로 재포장하지 않는다. Trusted run/epoch/enable/clock,
Actual kind와 wheel/torque/pressure의 존재·원래 acquisition timestamp를 검사한다. 취득 시각을
서비스 polling now로 대체하지 않고 기존 정지/age30ms/skew20ms를 적용한다. Proof/Review/Passed
각 commit 전, Clear의 cut 검사와 commit 전에 재취득하며 연속 취득 사이30ms 초과도 거절한다.

Review 성공은 Passed까지 기록하고 clear하지 않는다. 별도 clear가 전 manifest를 재검사하여
그 사이 source append를 거절한다. 재심사의 부분 commit 뒤 이전 Passed를 재사용하지 않는다.
Capture 예외/저장 실패는 해당 service lifetime의 후속 동작을 닫는다. 예외 응답의 stage/watermark는
전체 journal 상태를 보증하지 않으므로 복구 시 committed prefix가 기준이다. Guard는 실패 시에도
해제된다. 권한/범위/물리 거절을 새 normal dispatch/INIT/actuator 허가로 해석하지 않는다.

현재 검증은 실제 Linux peer/별도 writer process·SIGKILL4컷과 결정적 clock99/Actual 주입이다.
실제 codec/P05/application receiver의 current_sample을 통과한 원본11쌍 payload를 독립 감사한다.
실제3-ECU 서비스 운용·물리 plant 정지 검증과 구분한다.
[Protocol](../test-plan/diagnostics-protocol.md#linux-로컬-연속성-서비스-요청-fixture),
[근거·분모·초기 실패](../test-plan/evidence/m9_continuity_service/README.md)를 따른다.

## 다음 구현 경계''')
replace('docs/interfaces/diagnostics.md','Central/Front/Rear 재기동과 로컬 서비스 심사 뒤에는 실제 native 서비스 요청/인가·quiesce·\n최신 물리 evidence의 adapter와 미결정 고장 조합·원인 연결/복구를 검증한다.', 'Central/Front/Rear 재기동과 로컬 Linux 서비스 연결 뒤에는 실제3-ECU 서비스 owner/SDK\nquiesce·새 global Epoch와 물리 정지 취득 조합 및 미결정 고장 조합·원인 연결/복구를 검증한다.')
replace('docs/project-status.md','ECU 재기동·발행자 계승·로컬 연속성 심사/clear; native 서비스 연결 후속','ECU 재기동·발행자 계승·로컬 Linux 서비스 요청/심사/clear; 3-ECU 서비스 조합 후속')
replace('docs/project-status.md','다음은 실제 native 서비스 요청 인증/인가·quiesce·최신 물리 evidence adapter와 다른 고장 조합·원인 연결/복구다.', '''Linux 로컬 서비스는 SO_PEERCRED UID/PID·boot capability·정확한 Session/incident/revision을
인가한 뒤 frozen guard와 원본 Actual 취득을 연결한다. Review→Passed와 별도 clear 요청을 구분하고,
재심사 중단/스트림 변경/재요청 충돌·capture 예외/저장 실패 시 clear를 막는다.
[로컬 서비스 연결·원본·검증 범위](test-plan/evidence/m9_continuity_service/README.md)를 따른다.
다음은 실제3-ECU 서비스 owner/SDK quiesce·새 global Epoch 후 물리 정지 취득 조합과 다른 고장 원인/복구다.''')
replace('docs/roadmap.md','명시적 수용과 현재 recording Passed/clear를 분리한다. 다음은 실제 native 서비스 인증/인가·quiesce·\n최신 물리 evidence adapter와 native fault matrix/원인 연결·복구·', '''명시적 수용과 현재 recording Passed/clear를 분리한다.
[Linux 로컬 서비스 연결](test-plan/evidence/m9_continuity_service/README.md)은 kernel peer 인가·
frozen guard·원본 Actual adapter·별도 clear 요청을 연결한다. 다음은 실제3-ECU 서비스 owner/SDK
quiesce·새 global Epoch/물리 정지 조합과 native fault matrix/원인 연결·복구·''')
p=Path('docs/archive/design-decisions.md');p.write_text(p.read_text()+'''

## ADR-0093: Linux 로컬 서비스 인가와 frozen 검사·Actual 취득의 연결

상태: 로컬 peer/component 연결 구현. 실제3-ECU 서비스 owner/SDK quiesce·물리 정지 조합·
원격 서비스 운용·TBD-08·native4ms/Target·M9/학습자 수용 OPEN.

심사 API의 호출자를 실제 로컬 peer에 결속한다. Kernel SO_PEERCRED UID/PID와 boot capability,
고정 run/actor/Session/incident/manifest를 모두 확인한다. 요청에 물리 evidence나 임의 범위/actor를
싣지 않는다. Private listener/accept scheduling은 caller 책임이며 원격 인증으로 확대 해석하지 않는다.
새 actor와 최대32 증가 요청의 유한 cache로 동일 bytes의 receipt 재전송을 허용하고 다른 bytes나
번호 역행을 거절한다. 기존 Event/Clear/Review encoding·SOME/IP Event-only wire는 유지한다.

Acquire부터 모든 commit까지 같은 FrozenContinuity guard를 유지한다. Normal dispatch 차단은
별도 실제 owner 책임이며 guard 해제로 정상 운행을 재개하지 않는다. Trusted current_sample의
독립 wheel/torque/pressure acquisition을 보존하고 각 commit 전 재취득한다. 기존 정지/age/skew
예산을 유지하며 단계 사이30ms 초과도 거절한다. Review 성공은 별도 Passed까지만 기록한다.
Clear는 새 요청·그 Passed ID·정확한 revision·동일 전체 stream cut·새 물리 evidence를 요구한다.
부분 재심사/저장 실패/capture 예외 뒤에 이전 Passed를 재사용하지 않는다.

별도 Unix 서버 process와 다른 PID의 거부, 실제 fsynced commit4컷 SIGKILL·보수적 재개,
11쌍 codec/P05/application-current Actual payload·독립 감사/변조15종으로 부분 검증한다.
Clock/Actual은 결정적 fixture 주입이다. 이 결과를 실제3-ECU의 RT/SDK quiesce나 plant 물리 정지로
올리지 않는다. 다음 조합 시험은 실제 owner의 명시적 서비스 진입·새 global Epoch/정지·생산자
정지/드레인 ACK·fresh Actual 취득을 함께 고정한 뒤 시행한다. 정상 자동 clear는 만들지 않는다.
''')
p=Path('docs/test-plan/component-traceability.csv');p.write_text(p.read_text()+'''C-M9-SERVICE-01,SYS-DIAG-001,central/diagnostics/continuity_service.cpp#ContinuityService::serve,ContinuityServiceTest.WrongKernelPrincipalCapabilitySessionIncidentRevisionAndMalformedPacketsCannotCaptureOrWrite;ContinuityServiceTest.FiniteRequestBudgetDoesNotEvictRepliesAndStorageFailureNeverPublishesPassed,Kernel UID/PID and boot capability;fixed incident/session/revision;76-byte canonical local request;32 bounded cached replies;no capture on denial,m9_continuity_service/results.json
C-M9-SERVICE-02,SYS-DIAG-001,central/diagnostics/continuity_service.cpp#ContinuityService::apply,ContinuityServiceTest.AuthenticatedReviewAndSeparateClearKeepTheGuardAcrossAllDurableWrites;ContinuityServiceTest.FailedFreezeUnsafeOrStaleActualAndChangedSourceCutCannotClear;ContinuityServiceTest.InterruptedReplacementReviewCannotReuseAnOlderPassedAndCaptureExceptionsReleaseTheGuard,Frozen guard across commit;separate clear with exact successful Passed/revision/cuts;fresh samples at each stage;exceptions/storage fail closed,m9_continuity_service/results.json
C-M9-SERVICE-03,SYS-DIAG-001,central/diagnostics/service_evidence.cpp#capture_service_evidence,ContinuityServiceTest.CodecIsCanonicalBoundedAndActualAdapterRejectsForeignEpochClockCommandAndMissingWheel;ContinuityServiceTest.PhysicalEvidenceIsResampledBetweenCommitsAndRequestNumbersCannotBeReused,Trusted current Actual preserves independent wheel/torque/pressure acquisitions;clock/epoch/enable/kind/age/value/inhibition checks;no request-supplied evidence,m9_continuity_service/results.json
C-M9-SERVICE-04,SYS-DIAG-001,tests/unit/continuity_service_process_test.cpp;tests/integration/diagnostics/audit_continuity_service.py,ContinuityServiceTest.NativeUnixPeerAuthorizationAndFourSigkillCommitCutsPreserveTheSameFrozenOriginals;continuity-service-mutations15,Separate real Unix peer server and unauthorized PID;four fsynced SIGKILL cuts;immutable unknown history;11 original Actual pairs independently P05/value/time audited;logical fixture only,m9_continuity_service/results.json
''')
p=Path('docs/test-plan/requirements-traceability.md');s=p.read_text();marker='| SYS-DIAG-001 |';index=s.index(marker);s=s[:index]+s[index:];s=s.replace('quiesce/물리 evidence adapter와 SYS-DIAG-001/TC-DIAG-001 전체 수용은 OPEN이다.', '''quiesce/물리 evidence 조합과 SYS-DIAG-001/TC-DIAG-001 전체 수용은 OPEN이다.
C-M9-SERVICE-01–04는 [Linux 로컬 서비스 연결](evidence/m9_continuity_service/README.md)의
kernel peer/boot 인가·frozen guard·current Actual 취득·별도 clear·실제 Unix writer SIGKILL4컷을
검증한다. Clock/Actual 주입과 실제3-ECU 서비스 운용/plant 물리 정지 수용은 구분한다.''');p.write_text(s)
p=Path('docs/test-plan/README.md');s=p.read_text();needle='## Evidence 보관 규칙';s=s.replace(needle,'Linux 로컬 서비스 요청/심사/별도 clear는 [연결 근거](evidence/m9_continuity_service/README.md)와\n[고정 recipe](diagnostics-protocol.md#linux-로컬-연속성-서비스-요청-fixture)를 따른다. 실제3-ECU 서비스 운용은 후속이다.\n\n'+needle);p.write_text(s)
