from pathlib import Path
import datetime,gzip,hashlib,json,platform,runpy,shutil,subprocess,sys,tarfile,xml.etree.ElementTree as ET
root=Path.cwd();raw=root/'build/m9-continuity-service';out=root/'docs/test-plan/evidence/m9_continuity_service'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def junit(name):
 rows=ET.parse(raw/name).getroot().findall('.//testcase');bad=[r.attrib['name'] for r in rows if any(r.find(k) is not None for k in ('failure','error','skipped'))]
 return dict(passed=len(rows)-len(bad),total=len(rows),failed=bad)
def archive(src):
 with (out/(src.name+'.tar.gz')).open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:
   with tarfile.open(mode='w',fileobj=z) as t:t.add(src,arcname=src.name)
def gzcopy(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 with dst.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(src.read_bytes())
sys.path.insert(0,str(root/'tests/integration/diagnostics'));api=runpy.run_path(str(root/'tests/integration/diagnostics/audit_continuity_service.py'))
results=dict(scope='Linux local peer service only: kernel UID/PID plus boot capability, trusted frozen guard and validated current Actual adapter, separate Review/Passed and explicit clear. Injected clock99/Actuals, producers already stopped; live three-ECU RT/SDK quiesce/plant stop/remote authorization/TBD08/native4ms/Target/M9/learner acceptance OPEN',
 core_final=junit('core-final.xml'),wall=junit('wall.xml'),service_asan_final=junit('asan-final.xml'),service_tsan_final={'unit':junit('tsan-unit-final.xml'),'process':junit('tsan-process-final.xml')},
 before_release_and_binding_fix={'core':junit('core.xml'),'asan_broad':junit('asan.xml'),'service_component':junit('component-final.xml'),'tsan_unit':junit('tsan-unit-fixed.xml'),'tsan_process':junit('tsan-process-fixed.xml'),'source_archive':'before-release-and-binding-fix.tar.gz','binary_hash_log':'logs/before-release-and-binding-binaries.json.gz','note':'Broad ASan336 passed before fixed-size encoder header and immutable proof acquisition change; final affected service8 revalidated, other328 tests unchanged. Exact earlier intermediate iterations are retained as development logs, not final acceptance.'},
 initial={'compiler_exit':2,'component':junit('component-initial.xml'),'diagnostic_process_exit':1,'old_tsan_tree_missing_target_exit':2,'tsan_default_mapping_launch_exit':66,'release_warning_exit':2},
 static=json.loads((raw/'static-final.json').read_text()),release_build_testing_off='PASS',fingerprint_tests=2,service={},mutations_rejected=0,
 native_sdk_campaign='NOT RERUN: runtime/SDK composition unchanged, prior Normal Central failure remains in prior bundle; local service result does not close native service integration',prior_evidence=json.loads((raw/'prior-integrity.json').read_text()))
for mode,name in [('normal','process-core-final'),('asan','process-asan-final'),('tsan','process-tsan-final')]:
 data=api['load'](raw/name);report=api['judge'](data);report['mutations_rejected']=api['mutations'](data);results['service'][mode]={'archive':name+'.tar.gz','report':report};results['mutations_rejected']+=report['mutations_rejected']
for p in sorted(raw.iterdir()):
 if p.is_dir() and p.name.startswith('process-'):archive(p)
 elif p.is_file() and p.suffix in ('.log','.json','.xml','.py','.stderr'):gzcopy(p,out/'logs'/(p.name+'.gz'))
 elif p.is_file() and p.name.endswith('.tar.gz'):shutil.copy2(p,out/p.name)
(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
names={n for n in changed if not n.startswith('docs/test-plan/evidence/')}
names.update(['docs/development-guide.md','tests/unit/continuity_review_fixture.hpp','central/diagnostics/continuity_review.cpp','central/diagnostics/continuity_review.hpp','central/diagnostics/diagnostics.hpp','central/diagnostics/diagnostics.cpp','interfaces/common/actuator_payload_codec.cpp','interfaces/common/e2e_profile5.cpp','interfaces/drive/drive_frame_codec.cpp','interfaces/drive/drive_value_codec.hpp','interfaces/brake/brake_pressure_codec.hpp'])
names.update('tests/integration/diagnostics/'+n for n in ['audit_control_diagnostics.py','audit_continuity_review.py','audit_native_adoption.py','audit_native_routing.py','audit_someip_diagnostics.py'])
overlay={}
for name in sorted(names):
 p=root/name
 if p.is_file():
  dst=out/'sources'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst);overlay[name]=sha(p)
configs={};binaries={}
for name,path in [('normal','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-continuity-service/tsan'),('release','build/m9-continuity-service/release')]:
 p=root/path/'CMakeCache.txt';gzcopy(p,out/('CMakeCache-'+name+'.txt.gz'));configs[name]=sha(p)
 for binary in (['libcontinuity_review.a','actuator_demo'] if name=='release' else ['remote_diagnostics_context_test','diagnostics_delivery_process_test']):
  p=root/path/binary;binaries[str(p.relative_to(root))]=sha(p)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_overlay_sha256':overlay,'build_inputs_fingerprint':runpy.run_path(str(root/'tests/integration/runtime/check_m4_async.py'))['fingerprint'](),'binary_sha256':binaries,'cmake_cache_sha256':configs,'platform':platform.platform(),'tools':{cmd[0]:subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT).strip() for cmd in [['c++','--version'],['cmake','--version'],['clang-tidy','--version'],['cppcheck','--version'],['python3','--version']]},'scope':results['scope'],'asan_broad_selector':'Diagnostic|Continuity|^NativePower\\.|ControlRecoverySil|Session|M4|RemoteLeaf|RemoteZone|SomeipRearBinding|PeerFixture|RemoteIssuer|RemoteEgress','final_service_selector':'ContinuityServiceTest','tsan_launch':['setarch','x86_64','-R'],'wall_label':'runtime.wall','static_commands_log':'logs/static-final.json.gz','release_configure':['cmake','-S','.','-B','build/m9-continuity-service/release','-DCMAKE_BUILD_TYPE=Release','-DBUILD_TESTING=OFF'],'source_variants':{'before_release_and_binding_fix':'before-release-and-binding-fix.tar.gz; corresponding binary hashes preserved','early_failures':['before-compile-fix.tar.gz','before-process-fix.tar.gz','before-rejection-fix.tar.gz']}}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(out/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(out)}\n' for p in files))
print(json.dumps(dict(files=len(files),overlay=len(overlay),core=results['core_final'],wall=results['wall'],asan=results['service_asan_final'],tsan=results['service_tsan_final'],mutations=results['mutations_rejected'])))
