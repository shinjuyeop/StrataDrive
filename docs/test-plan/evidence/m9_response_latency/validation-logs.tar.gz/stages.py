from pathlib import Path
import csv,json,sys
root=Path(sys.argv[1]);by_packet={}
for path in root.glob('*.sdk-api.csv'):
 for r in csv.DictReader(path.open()):
  if r['event'] not in ['tx-queued','send-begin','send-return','rx-enter','rx-queued'] or int(r['method']) not in (32,128):continue
  key=int(r['crc']);events=by_packet.setdefault(key,{})
  if r['event'] in events:raise ValueError('ambiguous duplicate '+str(key))
  events[r['event']]={'ns':int(r['ns']),'file':path.name,'lane':r['lane'],'method':r['method']}
complete=[]
for crc,v in by_packet.items():
 if len(v)!=5:continue
 ts={k:r['ns'] for k,r in v.items()}
 complete.append({'crc':crc,'sender':v['tx-queued']['file'],'receiver':v['rx-enter']['file'],'method':int(v['tx-queued']['method']),**ts,
 'send_queue_ns':ts['send-begin']-ts['tx-queued'],'send_call_ns':ts['send-return']-ts['send-begin'],'sdk_to_callback_ns':ts['rx-enter']-ts['send-begin'],'decode_queue_ns':ts['rx-queued']-ts['rx-enter'],'total_ns':ts['rx-queued']-ts['tx-queued']})
metrics={}
for field in ['send_queue_ns','send_call_ns','sdk_to_callback_ns','decode_queue_ns','total_ns']:
 values=sorted(r[field] for r in complete);metrics[field]={'p50':values[len(values)//2],'p99':values[int((len(values)-1)*.99)],'max':values[-1]} if values else {}
print(json.dumps({'complete_packets':len(complete),'incomplete_packets':len(by_packet)-len(complete),'metrics':metrics,'worst':sorted(complete,key=lambda r:r['total_ns'],reverse=True)[:12]},indent=2))
