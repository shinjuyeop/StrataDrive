from pathlib import Path
import subprocess,sys,json,hashlib,tarfile
root=Path.cwd();out=root/'build/m9-response-latency'/sys.argv[1];out.mkdir(exist_ok=False)
fifo='--sdk-fifo' in sys.argv
files=['interfaces/someip/owner_transport.hpp','tests/integration/someip/front_adapter.cpp','tests/integration/someip/front_run.py','docs/test-plan/service-response-protocol.md','interfaces/common/monotonic_condition.hpp','tests/unit/monotonic_condition_test.cpp','cmake/CoreTests.cmake']
binary=root/'build/m5-someip-tsan/project/tests/integration/someip/someip_front_adapter'
manifest={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'sdk_fifo':fifo,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'sources':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in files}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'sources.tar.gz','w:gz') as t:
 for p in files:t.add(root/p,arcname=p)
import threading,time,os
samples=[];stopped=threading.Event()
def observe():
 os.sched_setaffinity(0,{0})
 while not stopped.is_set():
  begin=time.monotonic_ns();values=[int(Path(f'/sys/devices/system/cpu/cpu{i}/cpufreq/scaling_cur_freq').read_text()) for i in range(1,8)]
  values+=[int(Path('/sys/devices/system/cpu/cpu0/thermal_throttle/package_throttle_count').read_text()),int(Path('/sys/class/hwmon/hwmon4/temp1_input').read_text())]
  samples.append([begin,time.monotonic_ns(),*values]);stopped.wait(.002)
observer=threading.Thread(target=observe);observer.start()
rows=[]
for fault,delay in [('normal',0),('ack-loss',0),('actual-loss',0),('normal',250)]:
 name=fault+('-slow' if delay else '')
 cmd=[sys.executable,str(root/'tests/integration/someip/front_run.py'),str(out/name),'--profile','tsan','--three','--simple-vehicle','--diagnostics','--diagnostic-service','--isolated-ecus','--split-owner-io','--owner-fifo','--fixed-layout','--cases','central-rejoin']
 if fifo:cmd+=['--sdk-fifo']
 if fault!='normal':cmd+=['--service-fault',fault]
 if delay:cmd+=['--signal-write-delay-ms',str(delay)]
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==manifest['binary_sha256']
 with (out/(name+'.runtime.log')).open('w') as log:runtime=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode
 audit='audit_native_service.py' if fault=='normal' else 'audit_native_service_faults.py'
 with (out/(name+'.audit.log')).open('w') as log:qualified=subprocess.run([sys.executable,str(root/'tests/integration/diagnostics'/audit),str(out/name/'central-rejoin-1'),'--mutations'],stdout=log,stderr=subprocess.STDOUT).returncode
 row={'name':name,'command':cmd,'runtime_exit':runtime,'audit_exit':qualified};rows.append(row)
 (out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
stopped.set();observer.join()
with (out/'frequency.csv').open('w') as f:
 import csv
 w=csv.writer(f);w.writerow(['begin_ns','end_ns',*['cpu'+str(i)+'_khz' for i in range(1,8)],'package_throttle_count','package_millidegrees']);w.writerows(samples)
sys.exit(int(any(r['audit_exit'] for r in rows)))
