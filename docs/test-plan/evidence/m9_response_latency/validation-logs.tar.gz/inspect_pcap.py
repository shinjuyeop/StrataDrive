from pathlib import Path
import struct,json,csv
root=Path('build/m9-service-timing/fifo-campaign/tsan-normal/central-rejoin-1')
d=root.joinpath('traffic.pcap').read_bytes();result=json.loads((root/'result.json').read_text());sample=result['clock_sample'];offset=sample['wall_ns']-sample['monotonic_ns'];pos=24;streams={}
while pos<len(d):
 sec,usec,size,_=struct.unpack_from('<IIII',d,pos);pos+=16;p=d[pos:pos+size];pos+=size
 if len(p)<54 or p[12:14]!=b'\x08\x00' or p[23]!=6:continue
 ip=p[14:];ihl=(ip[0]&15)*4;tcp=ip[ihl:];src,dst,seq=struct.unpack_from('!HHI',tcp)
 if not (30501<=src<=30508 or 30501<=dst<=30508):continue
 key=(ip[12:16].hex(),ip[16:20].hex(),src,dst);payload=ip[ihl+(tcp[12]>>4)*4:int.from_bytes(ip[2:4],'big')]
 stream=streams.setdefault(key,{})
 for i,b in enumerate(payload,seq):
  if i in stream:assert stream[i][0]==b
  else:stream[i]=(b,sec*10**9+usec*1000-offset)
for flow,stream in streams.items():
 if not stream:continue
 start=min(stream);assert len(stream)==max(stream)-start+1
 data=bytes(stream[i][0] for i in range(start,max(stream)+1));cursor=0
 while cursor<len(data):
  sid,method,length=struct.unpack_from('!HHI',data,cursor);raw=data[cursor+16:cursor+length+8]
  ns=max(stream[i][1] for i in range(start+cursor,start+cursor+length+8));cursor+=length+8
  if method not in (0x20,0x80) or raw[:4]!=b'SDRV':continue
  epoch,token=struct.unpack_from('<IQ',raw,25)
  if epoch==2 and 310<=token<=319: print({'flow':flow,'method':method,'epoch':epoch,'token':token,'pcap_observed_ns':ns})
