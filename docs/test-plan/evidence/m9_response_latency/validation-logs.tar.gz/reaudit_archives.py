from pathlib import Path
import subprocess,tarfile,json,tempfile,hashlib,io
root=Path.cwd();out=root/'docs/test-plan/evidence/m9_response_latency';extracted=Path(tempfile.mkdtemp(prefix='m9-response-archive-'))
rows=[]
with tarfile.open(out/'capacity-campaign.tar.gz')as tar:
 selected=[m for m in tar.getmembers()if any(m.name=='capacity-campaign/'+n or m.name.startswith('capacity-campaign/'+n+'/')for n in ('normal-normal','normal-ack-loss','tsan-normal-r3'))]
 tar.extractall(extracted,members=selected)
checks=[('normal-normal','audit_native_service.py',0),('normal-normal','audit_service_ordering.py',0),('normal-normal','audit_service_timing.py',0),('normal-normal','audit_service_response.py',0),('normal-ack-loss','audit_native_service_faults.py',0),('normal-ack-loss','audit_service_response.py',0),('tsan-normal-r3','audit_native_service.py',1),('tsan-normal-r3','audit_service_response.py',0)]
logs=out/'archive-reaudit-logs';logs.mkdir(exist_ok=False)
for name,reader,expected in checks:
 cmd=['python3',str(root/'tests/integration/diagnostics'/reader),str(extracted/'capacity-campaign'/name/'central-rejoin-1'),'--mutations']
 p=logs/(name+'-'+Path(reader).stem+'.log')
 with p.open('w')as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
 row={'case':name,'reader':reader,'expected_exit':expected,'actual_exit':r.returncode};rows.append(row);print(row,flush=True)
 assert r.returncode==expected,row
sources=[]
for p in out.glob('*.tar.gz'):
 if p.stem in ('source-final.tar','watch-prototype.tar','validation-logs.tar','host-observations.tar','build-configurations.tar'):continue
 with tarfile.open(p)as tar:
  manifests=[m for m in tar.getmembers()if m.name.endswith('/manifest.json')and m.name.count('/')==1]
  if not manifests:continue
  manifest=json.load(tar.extractfile(manifests[0]));folder=manifests[0].name.rsplit('/',1)[0]
  raw=tar.extractfile(folder+'/sources.tar.gz').read()
  with tarfile.open(fileobj=io.BytesIO(raw))as source:
   for path,sha in manifest['sources'].items():
    actual=hashlib.sha256(source.extractfile(path).read()).hexdigest();assert actual==sha,(p,path)
  sources.append({'archive':p.name,'source_files':len(manifest['sources']),'match':True})
(out/'archive-reaudit.json').write_text(json.dumps({'extracted_to':str(extracted),'readers':rows,'source_snapshot_checks':sources},indent=2)+'\n')
