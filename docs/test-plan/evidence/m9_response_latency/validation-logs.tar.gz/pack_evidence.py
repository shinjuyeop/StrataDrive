from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
root=Path.cwd();base=root/'build/m9-response-latency';out=root/'docs/test-plan/evidence/m9_response_latency';out.mkdir(parents=True,exist_ok=True)
cohorts=['observed-other','observed-fifo','cpu-observed-fifo','frequency-observed-fifo','event-other','event-monotonic-other','final-campaign','quiet-campaign','capacity-campaign','regressions','capacity-regressions']
def archive(name,entries):
 p=out/name;assert not p.exists(),p
 with tarfile.open(p,'w:gz',compresslevel=6) as tar:
  for file,arc in entries:tar.add(file,arcname=arc)
 assert p.stat().st_size<95_000_000,(p,p.stat().st_size)
 print(name,p.stat().st_size,flush=True)
archive('watch-prototype.tar.gz',[(base/'watch-prototype','watch-prototype')])
summary={};attempts=0
for name in cohorts:
 folder=base/name;rows=json.loads((folder/'results.json').read_text());assert len(rows)==(12 if 'regressions' in name else 30 if 'campaign' in name else 4)
 fields=['exit'] if 'regressions'in name else ['audit_exit']+([k for k in ('ordering_exit','timing_exit','response_exit') if k in rows[0]])
 assert all(all(r[k]is not None for k in fields)for r in rows)
 summary[name]={'attempted':len(rows),'qualified':sum(all(r[k]==0 for k in fields)for r in rows),'qualification_fields':fields,'results':rows}
 attempts+=len(rows);archive(name+'.tar.gz',[(folder,name)])
(out/'results.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runtime_attempts':attempts,'cohorts':summary},indent=2)+'\n')
for name in ('failure-analysis.json','original-sdk-error-analysis.json','restored-identity.json'):
 shutil.copy2(base/name,out/name)
archive('host-observations.tar.gz',[(p,p.name)for p in base.iterdir()if p.name.endswith(('-frequency.csv','-host.json'))or p.name=='host-tools.json'])
archive('validation-logs.tar.gz',[(p,p.name)for p in base.iterdir()if p.is_file()and p.suffix in ('.py','.cpp','.hpp','.json','.log') and not p.name.endswith('-host.json') and p.name not in ('host-tools.json',)])
configs=[];artifacts={}
for profile in ('normal','asan','tsan'):
 home=root/f'build/m5-someip-{profile}'
 for sub in ('project','sdk'):
  for name in ('CMakeCache.txt','compile_commands.json'):
   p=home/sub/name;configs.append((p,f'{profile}/{sub}/{name}'))
 p=home/'project/tests/integration/someip/someip_front_adapter';artifacts[profile]={'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size}
 for p in sorted((home/'install/lib').glob('libvsomeip*.so*')):
  if p.is_file()and not p.is_symlink():artifacts[profile].setdefault('sdk_libraries',[]).append({'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
archive('build-configurations.tar.gz',configs)
(out/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
files=set(subprocess.check_output(['git','diff','--name-only'],text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
files=sorted(p for p in files if not p.startswith('docs/test-plan/evidence/') and Path(p).is_file())
manifest={p:hashlib.sha256(Path(p).read_bytes()).hexdigest()for p in files}
(out/'source-final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive('source-final.tar.gz',[(Path(p),p)for p in files])
