from pathlib import Path
import bisect,csv,json
base=Path(__file__).resolve().parent
reports={}
for cohort,prefix in [('final-campaign','final'),('quiet-campaign','quiet'),('capacity-campaign','capacity')]:
 samples=list(csv.DictReader((base/(prefix+'-frequency.csv')).open()));times=[int(r['begin_ns'])for r in samples]
 rows=json.loads((base/cohort/'results.json').read_text());bad=[]
 for row in rows:
  if all(row[k]==0 for k in ('audit_exit','ordering_exit','timing_exit','response_exit')):continue
  root=base/cohort/row['name']/'central-rejoin-1'
  events=[dict(r,file=p.name) for p in root.glob('central-*.events.csv')for r in csv.DictReader(p.open()) if r['event']in ('central-fault','central-allocation-fault','session-failed','central-protection')]
  events.sort(key=lambda r:int(r['ns']))
  # Ignore the declared Epoch1 crash's expected stale-input protection if a fresh Central exists.
  fresh=[r for r in events if r['file'].startswith('central-2') and r['event'] not in ('central-protection',)]
  first=(fresh or events)
  item={'name':row['name'],'audit_exit':row['audit_exit'],'events':first[:4]}
  if first:
   ns=int(first[0]['ns']);a=max(0,bisect.bisect_left(times,ns-25000000));b=bisect.bisect_right(times,ns+25000000);window=samples[a:b]
   if window:
    item['host_25ms_each_side']={'samples':len(window),'maximum_temperature_millidegrees':max(int(r['package_millidegrees'])for r in window),'thermal_count_delta':int(window[-1]['package_throttle_count'])-int(window[0]['package_throttle_count']),'minimum_cpu_khz':{str(c):min(int(r[f'cpu{c}_khz'])for r in window)for c in range(1,8)},'all_7_cpus_at_or_below_810mhz_samples':sum(all(int(r[f'cpu{c}_khz'])<=810000 for c in range(1,8))for r in window)}
  bad.append(item)
 groups={p:{'passed':sum(all(r[k]==0 for k in ('audit_exit','ordering_exit','timing_exit','response_exit'))for r in rows if r['name'].startswith(p+'-')),'attempted':sum(r['name'].startswith(p+'-')for r in rows)}for p in ('normal','asan','tsan')}
 stop=base/cohort/'runtime-complete.json';cut=json.loads(stop.read_text())['monotonic_ns'] if stop.exists()else times[-1];runtime=[r for r in samples if int(r['begin_ns'])<=cut]
 reports[cohort]={'results':groups,'host':{'samples':len(samples),'runtime_samples':len(runtime),'runtime_maximum_temperature_millidegrees':max(int(r['package_millidegrees'])for r in runtime),'maximum_temperature_millidegrees':max(int(r['package_millidegrees'])for r in samples),'thermal_counter_delta_all':int(samples[-1]['package_throttle_count'])-int(samples[0]['package_throttle_count']),'thermal_counter_delta_through_runtime':int(runtime[-1]['package_throttle_count'])-int(runtime[0]['package_throttle_count'])},'failures':bad}
(base/'failure-analysis.json').write_text(json.dumps(reports,indent=2)+'\n')
print(json.dumps(reports,indent=2))
