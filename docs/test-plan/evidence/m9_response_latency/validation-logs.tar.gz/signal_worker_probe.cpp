#include "tests/integration/someip/fixture_signals.hpp"
#include <atomic>
#include <iostream>
#include <sstream>
#include <sys/syscall.h>
#include <unistd.h>
int main(){
 std::string pattern="/tmp/signal-cost-XXXXXX";auto* name=mkdtemp(pattern.data());if(!name)return 2;
 std::filesystem::path folder=name;std::atomic<long> tid{0};long before=0,after=0;
 auto ticks=[&]{std::ifstream f("/proc/self/task/"+std::to_string(tid.load())+"/stat");std::string s;std::getline(f,s);std::istringstream in(s.substr(s.find_last_of(')')+2));std::string field;long sum=0;for(int i=3;i<=15;++i){in>>field;if(i>=14)sum+=std::stol(field);}return sum;};
 {stratadrive::someip::test::FixtureSignals signals(folder,"central-2",[&]{tid=syscall(SYS_gettid);});while(!tid.load())std::this_thread::yield();before=ticks();std::this_thread::sleep_for(std::chrono::seconds(2));after=ticks();signals.finish();if(signals.failed())return 3;}
 std::cout<<"{\"worker_cpu_seconds\":"<<double(after-before)/sysconf(_SC_CLK_TCK)<<",\"wall_seconds\":2}\n";std::filesystem::remove_all(folder);
}
