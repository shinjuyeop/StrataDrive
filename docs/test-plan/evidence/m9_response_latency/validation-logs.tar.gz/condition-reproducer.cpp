#include <condition_variable>
#include <mutex>
#include <thread>
#include <chrono>
#ifdef MONOTONIC_WAIT
#include "interfaces/common/monotonic_condition.hpp"
using Condition=stratadrive::runtime::MonotonicCondition;
#else
using Condition=std::condition_variable;
#endif
int main(){Condition cv;std::mutex m;int a=0,b=0;
std::thread t([&]{for(int n=1;n<=1000;++n){std::unique_lock<std::mutex> l(m);if(!cv.wait_for(l,std::chrono::seconds(2),[&]{return a==b;}))return;a=n;cv.notify_one();}});
{std::unique_lock<std::mutex> l(m);while(b<1000){if(!cv.wait_for(l,std::chrono::seconds(2),[&]{return a>b;}))break;b=a;cv.notify_one();}}t.join();return b==1000?0:1;}
