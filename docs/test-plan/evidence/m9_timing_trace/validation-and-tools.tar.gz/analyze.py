from pathlib import Path
import bisect, csv, json

base=Path(__file__).resolve().parent
reports={}
for cohort,frequency in [('service-campaign','service-frequency.csv')]:
    rows=json.loads((base/cohort/'results.json').read_text())
    samples=list(csv.DictReader((base/frequency).open()));times=[int(r['begin_ns']) for r in samples]
    def qualified(row):
        return row['qualified'] if 'qualified' in row else not any(row[k] for k in ('audit_exit','ordering_exit','timing_exit','response_exit'))
    failures=[]
    for row in rows:
        if qualified(row):continue
        root=base/cohort/row['name']/'central-rejoin-1'
        events=[dict(r,file=p.name) for p in root.glob('central-2*.events.csv') for r in csv.DictReader(p.open())
                if r['event'] in ('central-fault','central-allocation-fault','session-failed')]
        events.sort(key=lambda r:int(r['ns']))
        item={'name':row['name'],'first_faults':events[:4],'renewals':[]}
        if not events:failures.append(item);continue
        at=int(events[0]['ns'])
        window=samples[bisect.bisect_left(times,at-25000000):bisect.bisect_right(times,at+25000000)]
        if window:
            item['host_25ms_each_side']={
                'samples':len(window),'max_millidegrees':max(int(r['package_millidegrees']) for r in window),
                'thermal_count_delta':int(window[-1]['package_throttle_count'])-int(window[0]['package_throttle_count']),
                'minimum_khz':{str(cpu):min(int(r[f'cpu{cpu}_khz']) for r in window) for cpu in range(1,8)},
                'all_seven_at_or_below_810mhz':sum(all(int(r[f'cpu{cpu}_khz'])<=810000 for cpu in range(1,8)) for r in window)}
        for role in ('front','rear'):
            path=root/(role+'-1.transport.csv');trace=list(csv.DictReader(path.open()))
            received=[r for r in trace if r['event']=='zone-received' and r['operation']=='3' and at-25000000<=int(r['ns'])<=at+1000000]
            accepted=[r for r in trace if r['event']=='zone-result-enqueued' and r['operation']=='3' and r['decision']=='1']
            for packet in received[-2:]:
                old=[r for r in accepted if int(r['ns'])<int(packet['ns'])]
                previous=old[-1] if old else None
                result=next((r for r in trace if r['event']=='zone-result-enqueued' and r['token']==packet['token'] and r['epoch']==packet['epoch']),None)
                item['renewals'].append({'role':role,'received':packet,'result':result,'previous_success':previous,
                    'sent_to_received_ns':int(packet['ns'])-int(packet['sent']),
                    'arrival_after_previous_expiry_ns':int(packet['ns'])-int(previous['inner_deadline']) if previous else None})
        packets={};ambiguous=set()
        for path in root.glob('*.sdk-api.csv'):
            for r in csv.DictReader(path.open()):
                if r['event'] not in ('tx-queued','send-begin','send-return','rx-enter','rx-queued') or r['method'] not in ('32','112','128'):continue
                key=(r['method'],r['crc']);packet=packets.setdefault(key,{})
                if r['event'] in packet:ambiguous.add(key)
                packet[r['event']]={**r,'file':path.name}
        chains=[]
        for key,packet in packets.items():
            if len(packet)!=5 or key in ambiguous:continue
            stamps={k:int(v['ns']) for k,v in packet.items()}
            if not at-25000000<=stamps['rx-queued']<=at+1000000:continue
            chain={'method':int(key[0]),'crc':int(key[1]),'sender':packet['tx-queued']['file'],'receiver':packet['rx-enter']['file'],
                   'stamps':stamps,'send_queue_ns':stamps['send-begin']-stamps['tx-queued'],
                   'send_call_ns':stamps['send-return']-stamps['send-begin'],
                   'send_to_callback_ns':stamps['rx-enter']-stamps['send-begin'],
                   'callback_to_queue_ns':stamps['rx-queued']-stamps['rx-enter']}
            # Only subtract CPU clocks within one send call or one callback.
            # Event wall stamps precede trace locking; CPU reads are inside the
            # recorder, so these are diagnostic deltas, not exact blocked time.
            for name,start,end in [('send_call','send-begin','send-return'),('callback','rx-enter','rx-queued')]:
                chain[name+'_thread_cpu_delta_ns']=int(packet[end]['cpu_ns'])-int(packet[start]['cpu_ns'])
            chains.append(chain)
        item['longest_sdk_chains_near_fault']=sorted(chains,key=lambda r:r['send_to_callback_ns'],reverse=True)[:5]
        item['ambiguous_stage_keys']=len(ambiguous)
        failures.append(item)
    reports[cohort]={'attempted':len(rows),'qualified':sum(qualified(row) for row in rows),
        'host':{'samples':len(samples),'max_millidegrees':max(int(r['package_millidegrees']) for r in samples),
                'thermal_count_delta':int(samples[-1]['package_throttle_count'])-int(samples[0]['package_throttle_count'])},
        'failures':failures}
(base/'analysis.json').write_text(json.dumps(reports,indent=2)+'\n')
for cohort,report in reports.items():
    print(cohort,report['qualified'],report['attempted'],report['host'])
    for item in report['failures']:
        print(item['name'],'host',item.get('host_25ms_each_side'))
        print('renewals',[(r['role'],r['received']['epoch'],r['received']['token'],r['sent_to_received_ns'],r['arrival_after_previous_expiry_ns']) for r in item['renewals']])
        print('longest_sdk_chain',item['longest_sdk_chains_near_fault'][:1])
