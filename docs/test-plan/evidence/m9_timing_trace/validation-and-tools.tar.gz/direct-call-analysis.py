from pathlib import Path
import csv,json
base=Path('build/m9-trace-slots');out=[]
for case in sorted((base/'service-campaign').iterdir()):
 if not case.is_dir():continue
 calls=[]
 for path in case.glob('central-rejoin-1/*.sdk-api.csv'):
  pending={}
  for row in csv.DictReader(path.open()):
   if row['event']not in ('send-begin','send-return'):continue
   key=row['method'],row['crc']
   if row['event']=='send-begin':pending[key]=row
   else:
    start=pending.pop(key);wall=int(row['ns'])-int(start['ns']);cpu=int(row['cpu_ns'])-int(start['cpu_ns'])
    assert wall>=0 and cpu>=0
    calls.append({'file':path.name,'method':int(row['method']),'crc':int(row['crc']),'begin_ns':int(start['ns']),'wall_ns':wall,'thread_cpu_ns':cpu})
 if calls:out.append({'case':case.name,'complete_calls':len(calls),'worst_wall_calls':sorted(calls,key=lambda r:r['wall_ns'],reverse=True)[:3]})
(base/'direct-call-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print('complete calls',sum(r['complete_calls']for r in out));print('worst',max((c for r in out for c in r['worst_wall_calls']),key=lambda c:c['wall_ns']))
