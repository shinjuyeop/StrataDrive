from pathlib import Path
import fcntl,subprocess,json
base=Path('build/m9-trace-slots');rows=[]
def run(name,cmd):
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
with open('build/.m4-exclusive.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for p,d in [('normal','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
  run(p+'-configure',['cmake','-S','.','-B',d])
  run(p+'-unit-build',['cmake','--build',d,'--target','concurrent_trace_buffer_test','--parallel','2'])
  run(p+'-unit',(['setarch','x86_64','-R']if p=='tsan'else[])+['ctest','--test-dir',d,'-R','ConcurrentTraceBuffer','--output-on-failure'])
  run(p+'-adapter-build',['cmake','--build',f'build/m5-someip-{p}/project','--target','someip_front_adapter','--parallel','2'])
