from pathlib import Path
import hashlib,json,shutil,tarfile
root=Path.cwd();base=root/'build/m9-trace-slots';out=root/'docs/test-plan/evidence/m9_timing_trace'
out.mkdir(parents=True,exist_ok=False);results={};checks=[];sources={}
for cohort in ('functional-regressions','service-campaign'):
 folder=base/cohort;manifest=json.loads((folder/'manifest.json').read_text());rows=json.loads((folder/'results.json').read_text())
 results[cohort]={'manifest':manifest,'results':rows}
 with tarfile.open(folder/'sources.tar.gz','r:gz')as archive:
  for name,digest in manifest['sources'].items():
   assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest,(cohort,name)
   assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
   assert name not in sources or sources[name]==digest
   sources[name]=digest
 checks.append({'cohort':cohort,'sources_verified':len(manifest['sources'])})
 if cohort=='functional-regressions':
  with tarfile.open(out/(cohort+'.tar.gz'),'w:gz',compresslevel=6)as archive:archive.add(folder,arcname=cohort)
 else:
  with tarfile.open(out/'service-metadata.tar.gz','w:gz',compresslevel=6)as archive:
   for name in ('manifest.json','results.json','sources.tar.gz','runtime-complete.json'):archive.add(folder/name,arcname=cohort+'/'+name)
  for profile,repeat in [('normal',1),('asan',1),('tsan',1),('tsan',2),('tsan',3)]:
   group=[r for r in rows if r['name'].startswith(profile+'-')and (r['name'].endswith('-r'+str(repeat))if repeat>1 else not r['name'].endswith(('-r2','-r3')))]
   assert len(group)==6
   with tarfile.open(out/(profile+'-service-r'+str(repeat)+'.tar.gz'),'w:gz',compresslevel=6)as archive:
    for row in group:
     name=row['name'];archive.add(folder/name,arcname=cohort+'/'+name)
     for path in sorted(folder.glob(name+'.*.log')):archive.add(path,arcname=cohort+'/'+path.name)
final=results['service-campaign']['manifest'];reg=results['functional-regressions']['manifest']
for profile,digest in final['binaries'].items():
 assert hashlib.sha256((root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==digest
assert all(final['binaries'][p]==digest for p,digest in reg['binaries'].items())
for name in ('analysis.json','validation.json','static-results.json','cohorts.json'):
 shutil.copy2(base/name,out/name)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
(out/'identity-checks.json').write_text(json.dumps({'source_snapshots':checks,'final_sources_match':True,'final_binaries_match':True,'service_and_regression_binaries_match':True},indent=2)+'\n')
with tarfile.open(out/'validation-and-tools.tar.gz','w:gz',compresslevel=6)as archive:
 for p in sorted(base.iterdir()):
  if p.is_file()and p.suffix in ('.py','.json','.csv','.log','.txt'):archive.add(p,arcname=p.name)
with tarfile.open(out/'build-configurations.tar.gz','w:gz',compresslevel=6)as archive:
 for profile in ('normal','asan','tsan'):
  for part in ('project','sdk'):
   for name in ('CMakeCache.txt','compile_commands.json'):
    p=root/f'build/m5-someip-{profile}'/part/name
    if p.exists():archive.add(p,arcname=f'{profile}/{part}/{name}')
(out/'source-final-manifest.json').write_text(json.dumps(sources,indent=2)+'\n')
with tarfile.open(out/'source-final.tar.gz','w:gz')as archive:
 for name in sources:archive.add(root/name,arcname=name)
print(json.dumps({p.name:p.stat().st_size for p in out.iterdir()},indent=2))
