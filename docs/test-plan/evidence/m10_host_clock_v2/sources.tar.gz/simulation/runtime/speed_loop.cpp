#include "m4_owner_network.hpp"

namespace stratadrive::simulation::m4_detail {
namespace {
double target(std::uint64_t ns) {
    const double t=static_cast<double>(ns)*1e-9;
    if(t<20) return (30/3.6)*t/20;
    if(t<35) return 30/3.6;
    if(t<43) return 30/3.6-(10/3.6)*(t-35)/8;
    if(t<58) return 20/3.6;
    if(t<72) return (20/3.6)*(72-t)/14;
    return 0;
}
}
bool Network::speed_input_lost(std::uint64_t now) const noexcept {
    if(config.scenario!=M4Scenario::SpeedInputLoss || now<start) return false;
    const auto elapsed=now-start;
    return (elapsed>=config.injection_ns && (!config.speed_input_restore_ns || elapsed<config.speed_input_restore_ns)) ||
        (config.speed_input_reinject_ns && elapsed>=config.speed_input_reinject_ns);
}
void Network::speed_step(std::uint64_t now) {
    if(!result.speed_origin_ns) result.speed_origin_ns=now;
    const auto elapsed=now-result.speed_origin_ns;
    const auto in=port.feedback();
    const auto permission=port.current_permission();
    const auto* grant=permission?std::get_if<can::BmsDriveGrant>(&permission->message.content):nullptr;
    const bool permitted=permission && permission->message.epoch==active_epoch && grant &&
        grant->permission==can::BmsDrivePermission::AllowNormal && now<grant->expires_at_ns &&
        gate.allows(active_epoch) && core.decision().management.normal_allowed &&
        core.decision().fault==central::CoordinatorFault::None;
    const bool input_loss=speed_input_lost(now);
    std::optional<central::VehicleRequest> request;
    std::optional<central::VehicleInputDependency> dependency;
    if(config.supervised_speed) {
        const central::ClassicalSpeedProposal fallback{active_epoch,config.diagnostics_run,now,now+30*kMs+1,target(elapsed),true};
        const auto derived=supervised_control.step(now,std::nullopt,fallback,input_loss?std::nullopt:in.rear.drive_actual,
            force_estimator.estimate(in,now),permitted,core.decision().allocation.propulsion_selection);
        if(derived){request=derived->request;dependency=derived->input;}
    } else request=speed_control.step(now,target(elapsed),input_loss?std::nullopt:in.rear.drive_actual,permitted);
    const auto& controller=config.supervised_speed?supervised_control.controller():speed_control;
    next_speed_ns=now+central::SpeedPI::kPeriodNs;
    result.speed_fault=config.supervised_speed?static_cast<int>(supervised_control.decision().reason):static_cast<int>(speed_control.fault());
    if(!request) { core.request_protection(now); return; }
    const auto received=core.receive_vehicle(*request,now,dependency);
    if(received!=central::CoordinatorReceive::Accepted) { core.request_protection(now); return; }
    last_vehicle=now;
    const auto& state=controller.state();
    result.speed_trace.push_back({now,elapsed,request->source_time_ns,request->expires_at_ns,
        request->epoch,request->sequence,target(elapsed),state.sample->speed_mps,
        request->acceleration_mps2,state.integral});
}
} // namespace stratadrive::simulation::m4_detail
