#include "functional_rig.hpp"
#include "native_admission.hpp"
#include "wall_execution_watch.hpp"
#include "diagnostics_journal.hpp"
#include <algorithm>
#include <cerrno>
#include <poll.h>
#include <unistd.h>
#include <iomanip>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
using namespace stratadrive::m7_functional;
namespace {
// Bounded, interruptible input; std::getline can hide buffered WORK/WHEEL lines
// from poll(). Waiting here is NOT an owner execution opportunity.
class Input {
    std::string pending_;
    bool eof_=false;
public:
    enum class Result {Line,Wait,End};
    Result read(std::string& line) {
        auto take=[&] {
            const auto end=pending_.find('\n');
            if(end==std::string::npos)return false;
            if(end>20000)throw std::runtime_error("input line bound");
            line=pending_.substr(0,end);pending_.erase(0,end+1);return true;
        };
        if(take())return Result::Line;
        if(pending_.size()>20000)throw std::runtime_error("input line bound");
        if(eof_) {
            if(!pending_.empty())throw std::runtime_error("unterminated input");
            return Result::End;
        }
        pollfd fd{STDIN_FILENO,POLLIN,0};
        const int ready=::poll(&fd,1,1);
        if(ready<0 && errno!=EINTR)throw std::runtime_error("input poll");
        if(ready<=0)return Result::Wait;
        char bytes[4096];const auto size=::read(STDIN_FILENO,bytes,sizeof(bytes));
        if(size<0) {if(errno==EINTR)return Result::Wait;throw std::runtime_error("input read");}
        if(!size)eof_=true;else pending_.append(bytes,static_cast<std::size_t>(size));
        return take()?Result::Line:Result::Wait;
    }
};
void selection(const std::optional<stratadrive::central::PropulsionSelection>& s) {
    if(!s){std::cout<<"null";return;}
    std::cout<<"{\"epoch\":"<<s->epoch<<",\"request_sequence\":"<<s->request_sequence
        <<",\"selection_ns\":"<<s->selection_ns<<",\"requested_acceleration_mps2\":"<<s->requested_acceleration_mps2
        <<",\"requested_propulsion_nm\":"<<s->requested_propulsion_nm<<",\"selected_propulsion_nm\":"<<s->selected_propulsion_nm
        <<",\"limited\":"<<(s->limited?"true":"false")
        <<",\"requested_braking_nm\":"<<s->requested_braking_nm<<",\"selected_braking_nm\":"<<s->selected_braking_nm
        <<",\"braking_limited\":"<<(s->braking_limited?"true":"false")<<'}';
}
void audit(const std::optional<WheelAudit>& w) {
    if(w)std::cout<<"{\"source_ns\":"<<w->source<<",\"rad_s\":"<<w->rad_s<<'}';
    else std::cout<<"null";
}
void packet(const std::optional<stratadrive::remote::OwnerPacket>& p,std::ostream& out=std::cout) {
    if(!p){out<<"null";return;}
    out<<'"'<<std::hex<<std::setfill('0');
    for(std::size_t i=0;i<p->size;++i)out<<std::setw(2)<<unsigned(p->bytes[i]);
    out<<std::dec<<'"';
}
template<std::size_t N> void packets(const std::array<std::optional<stratadrive::remote::OwnerPacket>,N>& values,std::ostream& out=std::cout) {
    out<<'[';for(std::size_t i=0;i<N;++i){if(i)out<<',';packet(values[i],out);}out<<']';
}
}
int main(int argc,char** argv) {
    std::unique_ptr<WallExecutionWatch> wall_watch;
    std::string wall_path,response_path;
    try {
        if(argc==3 && std::string(argv[1])=="--record-diagnostics") {
            namespace d=stratadrive::diagnostics;
            d::FileJournal::initialize(argv[2],9401,{},4);d::FileJournal journal(argv[2]);d::Recorder recorder(journal);
            std::string line;std::size_t count=0;
            while(std::getline(std::cin,line)) {
                if(line.empty() || line.size()>8192 || line.size()%2 || line.find_first_not_of("0123456789abcdef")!=std::string::npos)throw std::runtime_error("canonical diagnostic input");
                std::vector<std::uint8_t> bytes;bytes.reserve(line.size()/2);
                for(std::size_t i=0;i<line.size();i+=2)bytes.push_back(static_cast<std::uint8_t>(std::stoul(line.substr(i,2),nullptr,16)));
                const auto entry=d::decode(bytes);const auto* event=std::get_if<d::Event>(&entry);
                if(!event || d::encode(entry)!=bytes || !recorder.record(*event).durable)throw std::runtime_error("diagnostic durable commit");
                std::cout<<++count<<std::endl;
            }
            return recorder.ledger().complete()?0:1;
        }
        if((argc<6 || argc>16 || argc%2!=0) || (std::string(argv[1])!="--wheel-shadow" && std::string(argv[1])!="--external-wheel-plant" && std::string(argv[1])!="--native-actual-export" && std::string(argv[1])!="--native-solver-work"))
            throw std::runtime_error("requires --wheel-shadow or --external-wheel-plant run application plant actor; no general driving acceptance");
        const auto run=std::stoull(argv[2]),app=std::stoull(argv[3]),plant=std::stoull(argv[4]),actor=std::stoull(argv[5]);
        if(!actor || actor>UINT32_MAX || app>UINT32_MAX || plant>UINT32_MAX)throw std::runtime_error("identity range");
        const bool solver_work=std::string(argv[1])=="--native-solver-work";
        const bool exporting=std::string(argv[1])=="--native-actual-export" || solver_work;
        const bool external=std::string(argv[1])=="--external-wheel-plant" || exporting;
        Time horizon=10000;bool horizon_set=false;
        for(int arg=6;arg<argc;arg+=2)if(std::string(argv[arg])=="--sim-horizon-ms") {
            if(horizon_set || !solver_work)throw std::runtime_error("duplicate/non-solver simulation horizon");
            std::string value=argv[arg+1];std::size_t used=0;horizon=std::stoull(value,&used);
            if(used!=value.size())throw std::runtime_error("invalid simulation horizon");
            horizon_set=true;
        }
        if(horizon_set && argc>16)throw std::runtime_error("simulation horizon option bound");
        FunctionalRig rig({run,static_cast<std::uint32_t>(app),static_cast<std::uint32_t>(plant)},static_cast<std::uint32_t>(actor),
            solver_work?PlantMode::ExternalSolverWork:(external?PlantMode::ExternalWheelZoh:PlantMode::StationaryFixture),exporting,horizon);
        bool scenario_loaded=false,sampled_actual=false,diagnostic_selected=false;
        for(int arg=6;arg<argc;arg+=2) {
            if(std::string(argv[arg])=="--sim-horizon-ms")continue;
            if(horizon_set && std::string(argv[arg])!="--scenario" && std::string(argv[arg])!="--speed-profile" && std::string(argv[arg])!="--route" && std::string(argv[arg])!="--diagnostic-fault" && std::string(argv[arg])!="--admission-profile" && std::string(argv[arg])!="--supervised-speed")throw std::runtime_error("simulation horizon excludes wall policy");
            if(!solver_work)throw std::runtime_error("options require solver-work mode");
            if(std::string(argv[arg])=="--admission-profile") {
                if(sampled_actual || !horizon_set || std::string(argv[arg+1])!="sampled-actual-v1")throw std::runtime_error("sampled Actual profile");
                sampled_actual=true;continue;
            }
            if(std::string(argv[arg])=="--diagnostic-fault") {
                const std::array<std::string,6> names{"none","input-loss","stop-ack-loss","front-command-loss","braking-timeout","front-link-failure"};
                const auto found=std::find(names.begin(),names.end(),argv[arg+1]);
                if(found==names.end())throw std::runtime_error("diagnostic fault recipe");
                rig.diagnostic_profile(static_cast<DiagnosticFault>(1+std::distance(names.begin(),found)));diagnostic_selected=true;continue;
            }
            if(std::string(argv[arg])=="--route") {
                if(!horizon_set)throw std::runtime_error("route requires simulation horizon");
                std::ifstream file(argv[arg+1]);if(!file)throw std::runtime_error("route open");
                std::vector<stratadrive::central::RoutePoint> points;std::string row;
                auto profile=RouteProfile::Curve30;bool header=false,antiwindup=false;
                while(std::getline(file,row)) {
                    if(row.rfind("PROFILE ",0)==0) {
                        if(row.size()>3 && row.substr(row.size()-3)=="_AW") {antiwindup=true;row.resize(row.size()-3);}
                        if(header || !points.empty() || (row!="PROFILE S01" && row!="PROFILE S03" && row!="PROFILE S03v2" && row!="PROFILE STOP30"))throw std::runtime_error("route profile header");
                        header=true;profile=row=="PROFILE STOP30"?RouteProfile::Straight30Stop:row=="PROFILE S01"?RouteProfile::Straight30:row=="PROFILE S03v2"?RouteProfile::CombinedV2:RouteProfile::Combined;continue;
                    }
                    stratadrive::central::RoutePoint p{};std::string extra;std::istringstream input(row);
                    if(!(input>>p.x_m>>p.y_m) || (input>>extra) || points.size()>=2001)throw std::runtime_error("route row");
                    points.push_back(p);
                }
                rig.route_profile(std::move(points),profile,antiwindup);continue;
            }
            if(std::string(argv[arg])=="--supervised-speed") {
                if(!horizon_set)throw std::runtime_error("supervision requires simulation horizon");
                // Explicit fixed load calibration in newtons, minimum:maximum.
                std::string value=argv[arg+1];const auto colon=value.find(':');
                if(colon==std::string::npos)throw std::runtime_error("road load requires min:max newtons");
                std::size_t a=0,b=0;
                const double low=std::stod(value.substr(0,colon),&a),high=std::stod(value.substr(colon+1),&b);
                if(a!=colon || b!=value.size()-colon-1)throw std::runtime_error("road load bounds syntax");
                rig.supervise_speed({low,high});continue;
            }
            if(std::string(argv[arg])=="--speed-profile") {
                const std::string v=argv[arg+1];
                if(!horizon_set || (v!="v1" && v!="v1-stop" && v!="v1-input-loss" && v!="v1-stop-protection"))throw std::runtime_error("invalid speed profile");
                rig.speed_profile(v=="v1-stop"?SpeedTerminal::NormalStop:v=="v1-input-loss"?SpeedTerminal::SpeedInputLoss:v=="v1-stop-protection"?SpeedTerminal::StopProtection:SpeedTerminal::None);continue;
            }
            if(std::string(argv[arg])=="--wall-response") {
                if(!response_path.empty())throw std::runtime_error("duplicate wall response");
                response_path=argv[arg+1];continue;
            }
            if(std::string(argv[arg])=="--wall-watch") {
                if(!wall_path.empty())throw std::runtime_error("duplicate wall watch");
                wall_path=argv[arg+1];continue;
            }
            if(std::string(argv[arg])!="--scenario" || scenario_loaded)throw std::runtime_error("invalid/duplicate scenario");
            scenario_loaded=true;
            std::ifstream file(argv[arg+1]);if(!file)throw std::runtime_error("scenario open");
            std::vector<RequestPhase> phases;std::string row;
            while(std::getline(file,row)) {
                if(row.empty() || row[0]=='#')continue;
                RequestPhase phase{};unsigned hold;std::string extra;std::istringstream input(row);
                if(!(input>>phase.end_ms>>phase.acceleration>>phase.curvature>>phase.braking>>hold) || hold>1 || (input>>extra))
                    throw std::runtime_error("invalid scenario row");
                phase.hold=hold!=0;phases.push_back(phase);
            }
            rig.request_profile(std::move(phases));
        }
        if(!response_path.empty() && wall_path.empty())throw std::runtime_error("wall response requires wall watch");
        if(sampled_actual && !diagnostic_selected)throw std::runtime_error("sampled Actual requires diagnostic STOP30 scope");
        std::cout<<std::setprecision(17);
        std::string line;
        std::unique_ptr<stratadrive::m7_native::Admission> admission;
        std::optional<stratadrive::m7_external::SolverWork> work;
        std::optional<WheelSample> previous_wheel;
        stratadrive::m7_native::Output previous_admission;
        Input lines;
        const auto stop_if_fault=[&] {
            if(wall_watch && wall_watch->faulted()) {
                BarrierStop selected{};
                Time selected_wall=0;
                const auto emit_stop=[&] {
                std::cout<<"{\"status\":\"WALL_GUARD_STOP\",\"next_frame\":null,\"normal\":"<<(selected.normal?"true":"false")
                    <<",\"credit_mask\":"<<selected.credit_mask<<",\"selected_mask\":"<<selected.selected_mask
                    <<",\"logical_barrier_ns\":"<<selected.logical_ns<<",\"wall_selected_ns\":"<<selected_wall
                    <<",\"actual_exported\":false,\"physical_braking_accepted\":false}"<<std::endl;
                };
                if(response_path.empty()) {
                    selected=rig.stop_at_barrier();selected_wall=WallExecutionWatch::now();
                } else {
                    // Bounded terminal probe, no input/read or synchronous trace
                    // writes on this service path. Never sends these branch-local
                    // timestamps to CARLA or requests another physics tick.
                    struct Record {Time wall;Report report;};
                    std::vector<Record> records;records.reserve(1024);
                    const auto anchor=WallExecutionWatch::now();
                    rig.begin_terminal_response(anchor);
                    auto wake=anchor+ms;
                    do {
                        stratadrive::simulation::runtime_support::sleep_until(wake);
                        const auto now=WallExecutionWatch::now();
                        auto r=rig.service_terminal_response(now);
                        if(records.empty()) {
                            selected_wall=WallExecutionWatch::now();
                            selected={r.now-(now-anchor),r.native_export->protection_selected_mask,r.credit_mask,r.armed};
                            emit_stop(); // Let adapter contain immediately, before the probe completes.
                        }
                        records.push_back({now,std::move(r)});
                        const auto finished=WallExecutionWatch::now();
                        wake=anchor+((finished-anchor)/ms+1)*ms;
                    } while(WallExecutionWatch::now()-anchor<300*ms && records.size()<1024);
                    std::ofstream trace(response_path);trace<<std::setprecision(17);
                    for(const auto& v:records) {
                        const auto& r=v.report;const auto& e=*r.native_export;
                        trace<<"{\"clock\":\"LOCAL_TERMINAL_RESPONSE_NOT_CARLA\",\"wall_ns\":"<<v.wall
                            <<",\"wall_anchor_ns\":"<<anchor<<",\"barrier_ns\":"<<selected.logical_ns
                            <<",\"local_ns\":"<<r.now<<",\"next_frame\":null,\"normal\":false,\"credit_mask\":"<<r.credit_mask
                            <<",\"service_mask\":"<<r.service_mask<<",\"selected_mask\":"<<e.protection_selected_mask
                            <<",\"selection_ns\":"<<e.protection_since<<",\"controller_releases\":"<<r.controller_releases
                            <<",\"energy_end_ns\":"<<r.electrical->end<<",\"mechanical_j\":"<<r.electrical->total_mechanical_j
                            <<",\"soc\":"<<r.electrical->soc<<",\"wheel_source_ns\":"<<r.sensor_wheel->source
                            <<",\"actual\":";packets(e.actual,trace);trace<<"}\n";
                    }
                    if(!trace)throw std::runtime_error("terminal response trace write");
                }
                wall_watch->write(wall_path);
                if(response_path.empty())emit_stop();
                return true;
            }
            return false;
        };
        for(;;) {
            if(stop_if_fault())return 2;
            const auto read=lines.read(line);
            if(stop_if_fault())return 2;
            if(read==Input::Result::End)break;
            if(read==Input::Result::Wait)continue;
            if(line=="WALL_ARM") {
                if(wall_path.empty() || wall_watch || work || !previous_admission.normal)
                    throw std::runtime_error("wall arm requires settled normal barrier and opt-in output");
                // Declared diagnostic window; preceding INIT is NOT monitored.
                wall_watch=std::make_unique<WallExecutionWatch>(WallExecutionWatch::now()+100000000);
                rig.execution_watch(wall_watch.get());
                std::cout<<"{\"status\":\"WALL_GUARD_ARMED\",\"first_release_ns\":"<<wall_watch->first_release()
                    <<",\"period_ns\":2000000,\"deadline_ns\":4000000}"<<std::endl;
                continue;
            }
            if(line=="FORCE_INPUT 0" || line=="FORCE_INPUT 1") {
                if(!solver_work || work || !previous_wheel)throw std::runtime_error("force input command barrier");
                rig.omit_force_input(line.back()=='0');continue;
            }
            if(line.rfind("REINIT ",0)==0) {
                std::uint32_t epoch;std::string op,extra;std::istringstream input(line);
                if(!(input>>op>>epoch) || (input>>extra) || !solver_work || work || !previous_wheel || !admission)
                    throw std::runtime_error("reinit command barrier");
                rig.reinitialize(epoch);
                if(!admission->reinitialize(epoch,previous_wheel->source))throw std::runtime_error("reinit admission barrier");
                continue;
            }
            if(line=="PROTECT") {
                if(!solver_work || !previous_admission.normal)throw std::runtime_error("protection request context");
                rig.request_protection();continue;
            }
            if(line.rfind("POSE ",0)==0) {
                stratadrive::central::RoutePose pose{};std::uint32_t actor_id;std::string op,extra;std::istringstream input(line);
                if(!(input>>op>>actor_id>>pose.epoch>>pose.sequence>>pose.source_ns>>pose.x_m>>pose.y_m>>pose.yaw_rad) || (input>>extra))throw std::runtime_error("invalid POSE");
                rig.pose(pose,actor_id);continue;
            }
            if(line.size()>(solver_work?20000U:1024U))throw std::runtime_error("input size");
            if(line.rfind("WORK ",0)==0) {
                if(!solver_work || work || !previous_wheel || !admission)throw std::runtime_error("unexpected work");
                stratadrive::m7_external::SolverWork v;unsigned sleeping=0,count=0;
                std::string op,extra;std::istringstream input(line);
                if(!(input>>op>>v.frame>>v.begin>>v.end>>v.dt>>sleeping>>count) || sleeping>1 ||
                   count!=(sleeping?0U:320U))throw std::runtime_error("work header");
                v.sleeping=sleeping!=0;
                for(unsigned k=0;k<count;++k)if(!(input>>v.rear_mean[k]))throw std::runtime_error("missing work substep");
                if(input>>extra)throw std::runtime_error("extra work substep");
                v.torque=double(float((previous_admission.torque*.5)*10000))*2/10000;
                v.oldest=previous_admission.empty?v.begin:previous_admission.oldest_actuator;
                const auto& w=*previous_wheel;
                v.wheel={(w.omega[2]+w.omega[3])/2,{7,static_cast<std::uint32_t>(w.frame),w.source},w.source};
                if(v.frame!=w.frame+1 || v.begin!=w.source || !v.valid())throw std::runtime_error("invalid work binding/value");
                work=v;continue;
            }
            Observation o{};WheelSample w{};std::string op,extra;std::istringstream in(line);
            if(!(in>>op>>o.scope.run>>o.scope.application>>o.scope.plant>>o.clock>>o.frame>>o.elapsed_s>>o.delta_s
                 >>w.actor>>w.frame>>w.source>>w.omega[0]>>w.omega[1]>>w.omega[2]>>w.omega[3]) ||
               op!="WHEEL" || (in>>extra))throw std::runtime_error("invalid WHEEL");
            if(solver_work && previous_wheel && !work)throw std::runtime_error("missing solver work receipt");
            const auto r=work?rig.observe(o,w,*work):rig.observe(o,w);
            if(stop_if_fault())return 2;
            const bool settled=bool(work);
            work.reset();previous_wheel=w;
            bool admission_good=true;
            std::cout<<"{\"status\":\"WHEEL_SHADOW_BARRIER\",\"driving\":false,\"normal_apply\":\""
                <<(exporting?"REQUIRES_SERVER_ADMISSION":"BLOCKED_CALIBRATION_AND_PLANT_OWNERSHIP")<<"\""
                <<",\"now_ns\":"<<r.now<<",\"next_frame\":"<<r.next_frame<<",\"armed_fixture\":"<<(r.armed?"true":"false")
                <<",\"release_mask\":"<<r.release_mask<<",\"credit_mask\":"<<r.credit_mask<<",\"service_mask\":"<<r.service_mask
                <<",\"sensor_wheel\":";audit(r.sensor_wheel);
            std::cout<<",\"returned_wheel\":";audit(r.returned_wheel);
            std::cout<<",\"fixture_torque_nm\":";
            if(r.returned_torque)std::cout<<*r.returned_torque;else std::cout<<"null";
            std::cout<<",\"regen_oldest_ns\":";
            if(r.regen_oldest)std::cout<<*r.regen_oldest;else std::cout<<"null";
            if(r.terminal_mode==SpeedTerminal::StopProtection || r.terminal_mode==SpeedTerminal::NormalStop30)std::cout<<",\"stop_handoff_ns\":"<<r.handoff_ns;
            if(r.terminal_mode==SpeedTerminal::NormalStop30) {
                const auto& c=r.stop_configuration;
                std::cout<<",\"stop_configuration\":{\"id\":\"normal-stop30-a1-t10-v1\",\"deceleration_mps2\":"<<c.deceleration_mps2<<",\"braking_timeout_ns\":"<<c.braking_timeout_ns<<",\"confirmation_ns\":"<<c.confirmation_ns<<",\"shutdown_timeout_ns\":"<<c.shutdown_timeout_ns<<'}';
            }
            if(r.terminal_mode!=SpeedTerminal::None) {
                std::cout<<",\"speed_terminal\":{\"mode\":"<<static_cast<int>(r.terminal_mode)<<",\"trigger_ns\":"<<r.trigger_ns<<",\"detection_ns\":"<<r.detection_ns
                    <<",\"speed_fault\":"<<r.speed_fault<<",\"stop_state\":"<<static_cast<int>(r.stop_state)<<",\"stop_fault\":"<<r.stop_fault<<",\"power_off\":"<<(r.power_off?"true":"false")<<",\"power_status\":";packet(r.power_status);std::cout<<'}';
            }
            if(r.diagnostic_fault!=DiagnosticFault::Disabled) {
                std::cout<<",\"diagnostics\":{\"fault\":"<<static_cast<unsigned>(r.diagnostic_fault)<<",\"omissions\":"<<r.fault_omissions<<",\"events\":[";
                bool comma=false;if(r.diagnostic_events) { for(const auto& e:*r.diagnostic_events){if(comma)std::cout<<',';comma=true;std::cout<<'"';
                    for(auto byte:stratadrive::diagnostics::encode(e))std::cout<<std::hex<<std::setw(2)<<std::setfill('0')<<static_cast<unsigned>(byte);
                    std::cout<<std::dec<<'"';} }
                std::cout<<"]}";
            }
            if(r.propulsion_antiwindup) {
                std::cout<<",\"allocation_feedback_schema\":3";
                std::cout<<",\"allocation_selection\":";selection(r.allocation_selection);
                std::cout<<",\"speed_selection\":";selection(r.speed_selection);
                std::cout<<",\"saturation_used\":"<<(r.saturation_used?"true":"false");
                std::cout<<",\"braking_saturation_used\":"<<(r.braking_saturation_used?"true":"false");
            }
            if(r.supervised_speed) {
                const auto& s=*r.supervised_speed;
                std::cout<<",\"supervised_speed\":{\"source\":"<<static_cast<unsigned>(s.decision.source)
                    <<",\"reason\":"<<static_cast<unsigned>(s.decision.reason)<<",\"force\":";
                if(s.force) {const auto& f=*s.force;std::cout<<"{\"source_ns\":"<<f.source_ns<<",\"expiry_ns\":"<<f.expires_ns
                    <<",\"propulsion_n\":"<<f.propulsion_n<<",\"braking_n\":"<<f.braking_n
                    <<",\"road_load_min_n\":"<<f.road_load_min_n<<",\"road_load_max_n\":"<<f.road_load_max_n<<'}';}
                else std::cout<<"null";
                std::cout<<",\"reference\":";
                if(s.reference) {const auto& f=*s.reference;std::cout<<"{\"target_mps\":"<<f.target_mps<<",\"minimum_acceleration_mps2\":"<<f.minimum_acceleration_mps2
                    <<",\"maximum_acceleration_mps2\":"<<f.maximum_acceleration_mps2<<",\"source_ns\":"<<f.oldest_source_ns<<",\"expiry_ns\":"<<f.expires_ns<<'}';}
                else std::cout<<"null";
                std::cout<<",\"fault_ns\":";if(s.fault)std::cout<<s.fault->detected_ns;else std::cout<<"null";std::cout<<'}';
            }
            if(r.speed_control) {
                const auto& s=*r.speed_control;
                std::cout<<",\"speed_control\":{\"release_ns\":"<<s.release_ns<<",\"origin_ns\":"<<s.origin_ns
                    <<",\"source_ns\":"<<s.source_ns<<",\"expiry_ns\":"<<s.expiry_ns<<",\"sequence\":"<<s.sequence
                    <<",\"input_expiry_ns\":"<<s.input_expiry_ns
                    <<",\"target_mps\":"<<s.target_mps<<",\"speed_mps\":"<<s.speed_mps
                    <<",\"acceleration_mps2\":"<<s.acceleration_mps2<<",\"integral\":"<<s.integral<<'}';
            }
            if(r.route_reference) {
                const auto& reference=*r.route_reference;
                std::cout<<",\"route_reference\":{\"requested_mps\":"<<reference.requested_mps
                    <<",\"slow_elapsed_ns\":";
                if(reference.slow_elapsed_ns)std::cout<<*reference.slow_elapsed_ns;else std::cout<<"null";
                std::cout<<",\"stop_elapsed_ns\":";
                if(reference.stop_elapsed_ns)std::cout<<*reference.stop_elapsed_ns;else std::cout<<"null";
                std::cout<<'}';
            }
            if(r.lateral_control) {
                const auto& l=*r.lateral_control;
                std::cout<<",\"lateral_control\":{\"curvature_inv_m\":"<<l.curvature_inv_m
                    <<",\"progress_m\":"<<l.progress_m<<",\"cross_track_m\":"<<l.cross_track_m
                    <<",\"heading_error_rad\":"<<l.heading_error_rad<<",\"lookahead_m\":"<<l.lookahead_m
                    <<",\"source_ns\":"<<l.source_ns<<",\"limited\":"<<(l.limited?"true":"false")<<'}';
            }
            if(r.native_export) {
                const auto& e=*r.native_export;
                std::cout<<",\"native_export\":{\"observed_ns\":\""<<e.observed<<"\",\"enable_ns\":\""<<e.enable
                    <<"\",\"normal\":"<<(e.normal?"true":"false")<<",\"actual\":";packets(e.actual);
                std::cout<<",\"commands\":";packets(e.commands);
                if(r.terminal_mode==SpeedTerminal::NormalStop || r.terminal_mode==SpeedTerminal::StopProtection || r.terminal_mode==SpeedTerminal::NormalStop30) {std::cout<<",\"stop_requests\":";packets(e.stop_requests);std::cout<<",\"stop_results\":";packets(e.stop_results);}
                std::cout<<",\"release\":";packets(e.release);
                std::cout<<",\"credit\":";packets(e.credit);
                std::cout<<",\"permission\":";packet(e.permission);
                std::cout<<",\"protection_since_ns\":\""<<e.protection_since<<"\",\"protection_selected_mask\":"<<e.protection_selected_mask<<'}';
                if(!admission)admission=std::make_unique<stratadrive::m7_native::Admission>(static_cast<std::uint32_t>(app),r.now,
                    sampled_actual?stratadrive::m7_native::ClockPolicy::FunctionalSampledActual:stratadrive::m7_native::ClockPolicy::Functional);
                stratadrive::m7_native::Input input;
                input.observed=e.observed;input.enable=e.enable;input.normal=e.normal;
                input.protection_since=e.protection_since;input.protection_selected_mask=e.protection_selected_mask;
                input.stop_requests=e.stop_requests;input.stop_results=e.stop_results;
                input.actual=e.actual;input.commands=e.commands;input.release=e.release;input.credit=e.credit;input.permission=e.permission;
                input.service_mask=r.service_mask;input.credit_mask=r.credit_mask;input.release_mask=r.release_mask;
                stratadrive::m7_native::Output out;
                const bool good=admission->accept(input,r.now,out);
                admission_good=good;
                previous_admission=out;
                std::cout<<",\"admission\":{\"ok\":"<<(good?"true":"false")<<",\"reason\":\""<<admission->error()
                    <<"\",\"empty\":"<<(out.empty?"true":"false")<<",\"normal\":"<<(out.normal?"true":"false")
                    <<",\"normal_stop\":"<<(out.normal_stop?"true":"false")<<",\"protection\":"<<(out.protection?"true":"false")<<",\"angle_rad\":"<<out.angle<<",\"torque_nm\":"<<out.torque<<",\"pressure_pa\":"<<out.pressure
                    <<",\"oldest_actuator_ns\":\""<<out.oldest_actuator<<"\",\"oldest_dependency_ns\":\""<<out.oldest_dependency
                    <<"\",\"exclusive_expiry_ns\":\""<<out.exclusive_expiry<<"\",\"admission_profile\":\""<<(sampled_actual?"sampled-actual-v1":"whole-interval-v1")
                    <<"\",\"command_checked_through_ns\":\""<<(sampled_actual?r.now:r.now+stratadrive::m7_native::step)<<"\"}";
            }
            if(external) {
                std::cout<<",\"energy_basis\":\""<<(solver_work?"OBSERVED_SOLVER_WORK_SINGLE_EV":(exporting?"MODEL_ZOH_PREDICTION_NOT_CARLA_WORK":"MODEL_ZOH_UNAPPLIED"))
                    <<"\",\"carla_work_valid\":"<<(settled?"true":"false")<<",\"electrical_steps\":[";
                for(unsigned j=0;j<r.electrical_count;++j) {
                    const auto& e=r.electrical_steps[j];if(j)std::cout<<',';
                    std::cout<<"{\"begin_ns\":"<<e.begin<<",\"end_ns\":"<<e.end<<",\"wheel_source_ns\":"<<e.wheel_source
                        <<",\"wheel_oldest_ns\":"<<e.wheel_oldest<<",\"wheel_rad_s\":"<<e.wheel_rad_s
                        <<",\"actual_torque_nm\":"<<e.torque_nm<<",\"mechanical_j\":"<<e.mechanical_j
                        <<",\"total_mechanical_j\":"<<e.total_mechanical_j<<",\"soc\":"<<e.soc<<",\"balance_j\":"<<e.balance_j<<'}';
                }
                std::cout<<']';
                if(solver_work && settled && r.electrical)std::cout<<",\"settlement\":{\"frame\":"<<o.frame
                    <<",\"end_ns\":"<<r.now<<",\"total_mechanical_j\":"<<r.electrical->total_mechanical_j
                    <<",\"soc\":"<<r.electrical->soc<<",\"balance_j\":"<<r.electrical->balance_j
                    <<",\"motor_loss_j\":"<<r.electrical->motor_loss_j<<",\"auxiliary_j\":"<<r.electrical->auxiliary_j
                    <<",\"ohmic_j\":"<<r.electrical->ohmic_j<<",\"capacitor_delta_j\":"<<r.electrical->capacitor_delta_j
                    <<",\"circuit_loss_j\":"<<r.electrical->circuit_loss_j<<",\"chemical_j\":"<<r.electrical->chemical_j<<'}';
            }
            std::cout<<"}"<<std::endl;
            if(!admission_good) {if(wall_watch)wall_watch->write(wall_path);return 1;}
        }
        if(wall_watch)wall_watch->write(wall_path);
        return 0;
    } catch(const std::exception& e) {
        if(wall_watch) {
            try {wall_watch->write(wall_path);}catch(const std::exception& failure) {std::cerr<<failure.what()<<'\n';}
        }
        std::cerr<<e.what()<<'\n';
        std::cout<<"{\"status\":\"FAIL\",\"driving\":false,\"next_frame\":null}"<<std::endl;
        return 1;
    }
}
