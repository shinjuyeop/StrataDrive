from pathlib import Path
import hashlib,json,tarfile,shutil
root=Path.cwd();base=root/'build/m9-sdk-owner-core';out=root/'docs/test-plan/evidence/m9_sdk_owner_core'
out.mkdir(parents=True,exist_ok=False);reports={}
for cohort in ('service-campaign',):
 folder=base/cohort;manifest=json.loads((folder/'manifest.json').read_text());rows=json.loads((folder/'results.json').read_text());reports[cohort]={'manifest':manifest,'results':rows}
 if cohort=='functional-regressions':
  with tarfile.open(out/'functional.tar.gz','w:gz',compresslevel=6)as tar:tar.add(folder,arcname=cohort)
 else:
  for profile,repeat in [('normal',1),('asan',1),('tsan',1),('tsan',2),('tsan',3)]:
   group=[r for r in rows if r['name'].startswith(profile+'-')and(r['name'].endswith('-r'+str(repeat))if repeat>1 else not r['name'].endswith(('-r2','-r3')))]
   assert len(group)==6
   with tarfile.open(out/(profile+'-r'+str(repeat)+'.tar.gz'),'w:gz',compresslevel=6)as tar:
    for row in group:
     name=row['name'];tar.add(folder/name,arcname=cohort+'/'+name)
     for p in sorted(folder.glob(name+'.*.log')):tar.add(p,arcname=cohort+'/'+p.name)
sources=json.loads((base/'runtime-sources.json').read_text())
with tarfile.open(base/'runtime-sources.tar.gz')as tar:
 for name,digest in sources.items():
  assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest,name
  assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for profile,digest in reports['service-campaign']['manifest']['binaries'].items():assert hashlib.sha256((root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==digest
with tarfile.open(out/'validation-tools.tar.gz','w:gz')as tar:
 for p in sorted(base.iterdir()):
  if p.is_file():tar.add(p,arcname=p.name)
 for p in sorted((base/'service-campaign').glob('*.json')):tar.add(p,arcname='service-campaign/'+p.name)
for name in ('runtime-sources.json','runtime-sources.tar.gz','preflight.json'):
 shutil.copy2(base/name,out/name)
(out/'results.json').write_text(json.dumps(reports,indent=2)+'\n')
(out/'identity-checks.json').write_text(json.dumps({'snapshot_sources_verified':len(sources),'worktree_sources_match':True,'binaries_match':True})+'\n')
print(json.dumps({p.name:p.stat().st_size for p in out.iterdir()},indent=2))
