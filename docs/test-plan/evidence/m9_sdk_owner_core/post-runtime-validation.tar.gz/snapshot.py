from pathlib import Path
import json,hashlib,subprocess,tarfile
base=Path('build/m9-sdk-owner-core')
files=subprocess.check_output(['git','ls-files','-co','--exclude-standard','-z']).decode().split('\0')
files=sorted(set(p for p in files if p and Path(p).is_file() and (Path(p).suffix in ('.cpp','.hpp','.py','.cmake') or Path(p).name=='CMakeLists.txt' or p in ('docs/test-plan/sdk-owner-core-protocol.md','docs/test-plan/egress-availability-protocol.md','docs/test-plan/plant-field-io-protocol.md','docs/test-plan/deferred-grant-protocol.md','docs/test-plan/stop-deadline-poll-protocol.md','docs/test-plan/allocation-release-protocol.md','docs/test-plan/owner-input-phase-protocol.md'))))
manifest={p:hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in files}
(base/'runtime-sources.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(base/'runtime-sources.tar.gz','w:gz')as tar:
 for p in files:tar.add(p,arcname=p)
(base/'candidate.patch').write_bytes(subprocess.check_output(['git','diff']))
