from pathlib import Path
import tarfile,hashlib,json
rows=[]
for candidate,folder in [('m9-feedback-root','m9_plant_field_io'),('m9-egress','m9_egress'),('m9-sdk-owner-core','m9_sdk_owner_core')]:
 root=Path('build')/candidate;out=Path('docs/test-plan/evidence')/folder
 for path in sorted(out.glob('*.tar.gz')):
  if path.name!='functional.tar.gz' and not path.name.startswith(('normal-r','asan-r','tsan-r')):continue
  count=size=0
  with tarfile.open(path)as tar:
   for member in tar:
    if not member.isfile():continue
    original=root/member.name;data=tar.extractfile(member).read();assert original.is_file(),str(original)
    assert hashlib.sha256(data).digest()==hashlib.sha256(original.read_bytes()).digest(),str(original)
    count+=1;size+=len(data)
  rows.append({'archive':str(path),'files':count,'bytes':size})
report={'archives':len(rows),'files':sum(r['files'] for r in rows),'rows':rows}
Path('build/m9-sdk-owner-core/archive-verification.json').write_text(json.dumps(report,indent=2)+'\n');print({'archives':report['archives'],'files':report['files']})
