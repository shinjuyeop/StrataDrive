from pathlib import Path
import subprocess,tarfile,json
base=Path('build/m9-sdk-owner-core/archive-recheck');base.mkdir(exist_ok=False);rows=[]
checks=[('m9_egress','normal-r1.tar.gz','normal-normal','audit_native_service.py',0),('m9_egress','asan-r1.tar.gz','asan-stop-ack-loss','audit_native_service_faults.py',1),('m9_sdk_owner_core','normal-r1.tar.gz','normal-normal','audit_service_timing.py',0)]
for index,(folder,archive,case,reader,expected) in enumerate(checks):
 root=base/str(index);root.mkdir();prefix='service-campaign/'+case
 with tarfile.open(Path('docs/test-plan/evidence')/folder/archive)as tar:
  for member in tar:
   if member.name==prefix or member.name.startswith(prefix+'/'):
    assert not member.name.startswith('/') and '..' not in Path(member.name).parts
    tar.extract(member,root)
 tool=Path('tests/integration/diagnostics')/reader
 if folder=='m9_sdk_owner_core':
  with tarfile.open(Path('docs/test-plan/evidence')/folder/'runtime-sources.tar.gz')as tar:(root/reader).write_bytes(tar.extractfile(str(tool)).read())
  tool=root/reader
 with (root/'audit.log').open('w')as log:r=subprocess.run(['python3',str(tool),str(root/prefix/'central-rejoin-1'),'--mutations'],stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==expected,(case,r.returncode,expected)
 rows.append({'archive':archive,'folder':folder,'case':case,'reader':str(tool),'exit':r.returncode,'expected':expected})
Path('build/m9-sdk-owner-core/archive-recheck.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
