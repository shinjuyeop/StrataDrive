from pathlib import Path
import csv,json
base=Path('build/m9-egress/service-campaign');rows=json.loads((base/'results.json').read_text());report=[]
for case in rows:
 root=base/case['name']/'central-rejoin-1';result=json.loads((root/'result.json').read_text());counts=[]
 for role in ('front','rear'):
  summary=next(p['summary'] for p in result['processes']if p['role']==role)
  timing=list(csv.DictReader((root/(role+'-1.sdk-api.csv')).open()))
  rejected=[r for r in timing if r['event']=='tx-unavailable'];acks=[r for r in timing if r['event']=='send-begin' and r['method']=='128']
  assert len(rejected)==summary['unavailable_rejected']
  assert acks and all(r['lane']=='1' for r in acks)
  assert not summary['tx_overflow_ns']
  counts.append(dict(role=role,disconnected_rejections=len(rejected),priority_results=len(acks)))
 central=list(csv.DictReader((root/'central-2.sdk-api.csv').open()))
 acks=[r for r in central if r['event']=='rx-enter' and r['method']=='128']
 assert acks and all(r['lane'] in ('1','3') for r in acks)
 sdk=result.get('unexpected_sdk_errors',[])
 assert not any('Queue size limit' in r['text'] for r in sdk)
 report.append(dict(case=case['name'],owners=counts,central_priority_results=len(acks),sdk_errors=sdk))
summary={'scope':'transport trace consistency; original scenario verdicts are independent',
         'cases':len(report),'rows':report,'queue_overflow_cases':0,
         'unavailable_rejections':sum(p['disconnected_rejections'] for r in report for p in r['owners']),
         'priority_results':sum(p['priority_results'] for r in report for p in r['owners'])}
(base.parent/'egress-audit.json').write_text(json.dumps(summary,indent=2)+'\n');print({k:v for k,v in summary.items()if k!='rows'})
