from pathlib import Path
import subprocess,json,time
base=Path('build/m9-egress');rows=[]
def run(name,cmd):
 (base/'phase.json').write_text(json.dumps({'phase':name,'time_ns':time.monotonic_ns()})+'\n')
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode and name!='native-cohorts':raise SystemExit(r.returncode)
for profile,d in [('normal','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 run(profile+'-build',['cmake','--build',d,'--parallel','2','--target','remote_contract_test','plant_io_test'])
 for target in ['remote_contract_test','plant_io_test']:
  run(profile+'-'+target,(['setarch','x86_64','-R']if profile=='tsan'else[])+[d+'/'+target])
 run(profile+'-adapter',['cmake','--build','build/m5-someip-'+profile+'/project','--parallel','2','--target','someip_front_adapter'])
run('static',['python3',str(base/'static.py')])
run('sdk-stages-python',['python3','tests/unit/sdk_stages_test.py'])
run('source-snapshot',['python3',str(base/'snapshot.py')])
run('native-cohorts',['python3',str(base/'run-cohorts.py')])
(base/'phase.json').write_text(json.dumps({'phase':'complete'})+'\n')
