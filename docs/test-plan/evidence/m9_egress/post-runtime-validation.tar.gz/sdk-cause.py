import json,re,hashlib
from pathlib import Path
from datetime import datetime,timezone,timedelta
base=Path('build/m9-egress/service-campaign');rows=[]
for case in ('asan-stop-ack-loss',):
 root=base/case/'central-rejoin-1';result=json.loads((root/'result.json').read_text());clock=result['clock_sample']
 successor=json.loads((root/'native-diagnostics/central/central-2.producer.json').read_text())
 for file in sorted(root.glob('*.stdout')):
  for line in file.read_text().splitlines():
   if '[error]' not in line:continue
   dt=datetime.strptime(line[:26],'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=timezone(timedelta(seconds=clock['utc_offset_s'])))
   # Decimal seconds avoid floating-point rounding in wall-to-monotonic mapping.
   wall=int(dt.timestamp())*1_000_000_000+dt.microsecond*1000
   ns=wall-clock['wall_ns']+clock['monotonic_ns'];crash=result['injected_crash']['ns']
   row=dict(case=case,file=file.name,line=line,event_ns=ns,crash_ns=crash,after_crash_ns=ns-crash,
            successor_boot_ns=successor['boot_ns'],before_successor=crash<=ns<successor['boot_ns'],
            survivor_protection_ns=int((root/(file.stem.split('-')[0]+'-protected')).read_text()),
            same_survivors=result['survivor_pids_before']==result['survivor_pids_after'],
            original_runtime_pass=result['pass'],original_sdk_errors=result['sdk_errors'])
   rows.append(row)
source=Path('build/m5-someip-deps/vsomeip/implementation/endpoints/src/tcp_client_endpoint_impl.cpp')
report={'scope':'causal analysis only; no verdict or SDK whitelist changed','errors':rows,
        'sdk_source':str(source),'sdk_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'sdk_behavior':'write_completion_condition logs every OS send error before send_cbk notifies disconnect/restarts endpoint',
        'limitation':'one captured wall/monotonic pair maps log times; not an independent clock agreement',
        'remaining_requirement':'zero unexpected SDK error in a cohort that deliberately SIGKILLs a live TCP peer'}
Path('build/m9-egress/sdk-cause.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
