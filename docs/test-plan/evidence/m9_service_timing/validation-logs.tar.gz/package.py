from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
root=Path.cwd();base=root/'build/m9-service-timing';out=root/'docs/test-plan/evidence/m9_service_timing'
cohorts={}
for name in ['campaign','ordered-campaign','split-campaign','fifo-campaign']:
 p=base/name;rows=json.loads((p/'results.json').read_text());assert len(rows)==18
 manifest=json.loads((p/'manifest.json').read_text())
 completed=json.loads((p/'binary-build-completion.json').read_text())['completed_binaries'] if (p/'binary-build-completion.json').exists() else manifest['binaries']
 for r in rows:
  plan=json.loads((p/r['name']/'plan.json').read_text())
  assert plan['binary_sha256']==completed[plan['profile']],r['name']
 def qualified(r):return r['audit_exit']==0 and r.get('ordering_exit',0)==0 and (name!='fifo-campaign' or r['timing_exit']==0)
 cohorts[name]={'runtime_attempts':18,'qualified':sum(qualified(r) for r in rows),'normal':sum(qualified(r) for r in rows if r['name'].startswith('normal-') and 'slow-signals' not in r['name']),'asan':sum(qualified(r) for r in rows if r['name'].startswith('asan-') and 'slow-signals' not in r['name']),'tsan':sum(qualified(r) for r in rows if r['name'].startswith('tsan-') and 'slow-signals' not in r['name']),'slow_signals':sum(qualified(r) for r in rows if 'slow-signals' in r['name']),'results':rows}
 if not (out/(name+'.tar.gz')).exists():
  with tarfile.open(out/(name+'.tar.gz'),'w:gz',compresslevel=6) as t:t.add(p,arcname=name)
final=cohorts['fifo-campaign'];failures=[];timing=[]
for r in final['results']:
 d=base/'fifo-campaign'/r['name']/'central-rejoin-1';result=json.loads((d/'result.json').read_text())
 if r['audit_exit'] or r['ordering_exit'] or r['timing_exit']:failures.append({'name':r['name'],'error':result.get('error')})
 f=base/'fifo-campaign'/(r['name']+'.timing.log')
 if not r['timing_exit']:timing.append({'name':r['name'],**json.loads(f.read_text())})
report={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'m9_complete':False,'service_fixed_profile_qualified':final['qualified']==18,'runtime_attempts_total':73,'cohorts':cohorts,'final_failures':failures,'timing':timing,'validation':{'core':1253,'unit':1028,'logical':211,'transport':5,'wall':9,'asan_affected':22,'tsan_signal_tests':3,'carla_logical':135},'remaining':['Clock qualification/recovery','pre-proposal bootstrap incident','silent packet loss CARLA subinterval coupling','full eight-role BMS/Power fault and recovery matrix','operational load and long-term retention acceptance','learner understanding review (separate)']}
if final['qualified']!=18:report['remaining'].insert(0,'native service timing qualification')
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
for name in ['ordered-campaign','split-campaign','fifo-campaign']:
 shutil.copyfile(base/name/'manifest.json',out/(name+'-manifest.json'))
logs=[p for p in base.iterdir() if p.is_file() and p.suffix in ('.log','.json','.py')]
with tarfile.open(out/'validation-logs.tar.gz','w:gz') as t:
 for p in logs:t.add(p,arcname=p.name)
files=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines()
files=sorted({f for f in files if not f.startswith('docs/test-plan/evidence/') and Path(f).is_file()})
manifest={f:hashlib.sha256(Path(f).read_bytes()).hexdigest() for f in files}
(out/'source-final-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'source-final.tar.gz','w:gz') as t:
 for f in files:t.add(f,arcname=f)
artifacts={}
for profile in ('normal','asan','tsan'):
 p=root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter'
 artifacts[profile]={'binary':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size}
with tarfile.open(out/'build-configurations.tar.gz','w:gz') as t:
 for profile in ('normal','asan','tsan'):
  for name in ('CMakeCache.txt','compile_commands.json'):
   p=root/f'build/m5-someip-{profile}/project'/name;t.add(p,arcname=profile+'/'+name)
(out/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
print(json.dumps({k:{f:v[f] for f in ('normal','asan','tsan','slow_signals','qualified')} for k,v in cohorts.items()},indent=2))
