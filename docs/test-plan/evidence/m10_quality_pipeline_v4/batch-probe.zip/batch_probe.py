from ctypes import CDLL,c_void_p,c_int,c_bool,c_ubyte
from contextlib import ExitStack,contextmanager,nullcontext
from pathlib import Path
import numpy as np
import tensorrt as trt
from quality_latency_cuda import GpuBuffers,checked,cu
from quality_shadow_v1 import detector,predict
from endurance_recording_v1 import RawReader
import json,time
from memo import memo

class SixEng(GpuBuffers):
    def __init__(self,views,folder):
        super().__init__()
        self.views=views
        self.logger=trt.Logger(trt.Logger.ERROR)
        self.runtime=trt.Runtime(self.logger)
        self.engine=self.runtime.deserialize_cuda_engine((folder/'full-six.plan').read_bytes())
        self.ctx=self.engine.create_execution_context()
        self.stream=checked(cu.cudaStreamCreate())
        self.callback(lambda:checked(cu.cudaStreamDestroy(self.stream)))
        self.arrays={}
        self.buffers={}
        for i in range(self.engine.num_io_tensors):
            name=self.engine.get_tensor_name(i)
            shape=self.engine.get_tensor_shape(name)
            dtype=trt.nptype(self.engine.get_tensor_dtype(name))
            size=int(np.prod(shape))*np.dtype(dtype).itemsize
            self.buffers[name]=self.allocate(size)
            assert self.ctx.set_tensor_address(name,self.buffers[name])
            if name!='images':
                pin=checked(cu.cudaMallocHost(size))
                self.callback(lambda p=pin:checked(cu.cudaFreeHost(p)))
                self.arrays[name]=np.ctypeslib.as_array((c_ubyte*size).from_address(pin)).view(dtype).reshape(tuple(shape))
            else: assert tuple(shape)==(6,3,960,960)
        self.enqueue=CDLL(str(folder/'graph_crop.so')).enqueue_quality_crop
        self.enqueue.argtypes=[c_void_p,c_int,c_int,c_int,c_bool,c_void_p,c_void_p,c_void_p,c_void_p]
        self.enqueue.restype=c_int
    @contextmanager
    def enable(self):
        v=self.views;c=v.crops
        upload,forward=c.frame,v.forward
        cache={}
        def frame(img):
            cache.clear()
            rgb=upload(img)
            for i,(_,rect,flip) in enumerate(v.windows):
                x,y,r,b=rect
                p=self.buffers['images']+i*3*960*960*4
                if self.enqueue(c.pixels,x,y,r-x,flip,c.axis(r-x,960),c.axis(b-y,960),p,int(self.stream)):
                    raise RuntimeError('crop')
            if not self.ctx.execute_async_v3(self.stream):
                raise RuntimeError('batch enqueue')
            for name,arr in self.arrays.items():
                checked(cu.cudaMemcpyAsync(arr.ctypes.data,self.buffers[name],arr.nbytes,cu.cudaMemcpyKind.cudaMemcpyDeviceToHost,self.stream))
            checked(cu.cudaStreamSynchronize(self.stream))
            for i,(_,rect,flip) in enumerate(v.windows):
                cache[rect,flip]={k:(a[i] if k in ('car_boxes','car_logits','adjacent_delta') else a[i:i+1]) for k,a in self.arrays.items()}
            return rgb
        def fetch(rect,flip=False):
            key=tuple(rect),bool(flip)
            if key not in cache:cache[key]=forward(rect,flip)
            return cache[key]
        c.frame,v.forward=frame,fetch
        try:yield
        finally:c.frame,v.forward=upload,forward

w=Path(__file__).resolve().parent
if __name__=='__main__':
    folder=Path('/tmp/stratadrive-m10-quality-shadow-views03/capture/paired/renderer')
    result=json.loads((folder/'result.json').read_bytes())
    raw={r['frame']:r for r in result['raw']}
    reader=RawReader(folder); rows=[]
    with detector([0,1,3,5,7,9],True) as (m,_),SixEng(m.views,w) as batch:
        for i,row in enumerate(result['inference'][::4]):
            pixels=reader.read(raw[row['renderer_frame']])
            for mode in (('memo','batch') if i%2 else ('batch','memo')):
                with (batch.enable() if mode=='batch' else memo(m.views)):
                    start=time.monotonic_ns();r=predict(m,pixels);ms=(time.monotonic_ns()-start)/1e6
                equal=r['detections']==row['detections']
                if mode=='memo' and not equal:raise ValueError((mode,i))
                rows.append(dict(mode=mode,ms=ms,frame=row['renderer_frame'],equal=equal,stage=r['stages_ms']['full_and_multiview']))
    reader.close()
    (w/'batch-probe.json').write_text(json.dumps(rows)+'\n')
    for mode in ('memo','batch'):
        data=[x for x in rows[8:] if x['mode']==mode]
        print(mode,len(data),sum(x['equal'] for x in data),[(k,np.percentile([x[k] for x in data],[50,95]).tolist()) for k in ['ms','stage']])
