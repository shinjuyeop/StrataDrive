import json,gzip
from pathlib import Path
import numpy as np
from batch_probe import SixEng
from quality_shadow_v1 import detector
from quality_latency import replay
from m10_screen_view_schedules import prior,sites

w=Path(__file__).resolve().parent
rows=json.loads((w/'batch-probe.json').read_bytes())[8:]
med=lambda mode,key,p:np.percentile([r[key] for r in rows if r['mode']==mode],p)
gain=med('memo','ms',50)-med('batch','ms',50)
if gain<3 or med('memo','ms',95)<=med('batch','ms',95):
    print('STOP timing screen',gain,flush=True)
else:
    out=w/'batch-quality'
    out.mkdir()
    summary={}
    with detector([0,1,3,5,7,9],True) as (m,binding),SixEng(m.views,w) as batch,batch.enable():
        sources=sites()
        for name in [*prior.DEV,*[n for n in sources if n not in prior.DEV]]:
            path=out/(name+'.json')
            replay(m,sources[name],None,path)
            report=json.loads(path.read_bytes())
            score=report['quality']
            summary[name]=dict(passed=score['passed'],micro=score['card']['micro'],absolute=score.get('gates'),relative=score.get('relative'),p95=report['raw_p95_ms'])
            print(name,score['passed'],score['card']['micro'],flush=True)
            if not score['passed']: break
    (w/'batch-quality-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
