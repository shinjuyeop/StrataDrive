from contextlib import nullcontext
import json,time,gzip,numpy as np
from pathlib import Path
from graph_views import FixedGraph
from quality_shadow_v1 import detector,predict
from endurance_recording_v1 import RawReader
w=Path(__file__).resolve().parent
folder=Path('/tmp/stratadrive-m10-quality-shadow-views03/capture/paired/renderer')
result=json.loads((folder/'result.json').read_bytes())
raw={r['frame']:r for r in result['raw']}
reader=RawReader(folder)
rows=[]
with detector([0,1,3,5,7,9],True) as (m,_):
    with FixedGraph(m.views,w/'graph_crop.so') as graph:
        for i,row in enumerate(result['inference'][::3]):
            pixels=reader.read(raw[row['renderer_frame']])
            for mode in (('original','graph') if i%2 else ('graph','original')):
                with (graph.enable(m.views) if mode=='graph' else nullcontext()):
                    start=time.monotonic_ns()
                    r=predict(m,pixels)
                    ms=(time.monotonic_ns()-start)/1e6
                if r['detections']!=row['detections']:raise ValueError((mode,i))
                rows.append(dict(mode=mode,ms=ms,frame=row['renderer_frame'],stage=r['stages_ms']['full_and_multiview']))
reader.close()
(w/'paired-probe.json').write_text(json.dumps(rows)+'\n')
for mode in ('original','graph'):
    data=[x for x in rows[8:] if x['mode']==mode]
    print(mode,len(data),[(k,np.percentile([x[k] for x in data],[50,95]).tolist()) for k in ['ms','stage']])
