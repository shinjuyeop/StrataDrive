"""Capture all fixed RGB crops, FP16 inferences and output copies in one CUDA graph."""
from contextlib import ExitStack, contextmanager
from ctypes import CDLL,c_void_p,c_int,c_bool,c_ubyte
import numpy as np
from quality_latency_cuda import checked,cu

class FixedGraph(ExitStack):
    def __init__(self, views, library):
        super().__init__()
        crops,engine=views.crops,views.model.session
        self.stream=engine.stream
        self.outputs={}
        names=views.model.spec['outputs']
        enqueue=CDLL(str(library)).enqueue_quality_crop
        enqueue.argtypes=[c_void_p,c_int,c_int,c_int,c_bool,c_void_p,c_void_p,c_void_p,c_void_p]
        enqueue.restype=c_int
        commands=[]
        try:
            for _, rect, flip in views.windows:
                x,y,r,b=rect
                args=(crops.pixels,x,y,r-x,flip,crops.axis(r-x,960),crops.axis(b-y,960),crops.tensor,int(self.stream))
                out={}
                for name in names:
                    arr=engine.host[name]
                    pin=checked(cu.cudaMallocHost(arr.nbytes))
                    self.callback(lambda p=pin:checked(cu.cudaFreeHost(p)))
                    out[name]=np.ctypeslib.as_array((c_ubyte*arr.nbytes).from_address(pin)).view(arr.dtype).reshape(arr.shape)
                self.outputs[rect,flip]=out
                commands.append((args,out))
            if not engine.ctx.set_tensor_address('images',crops.tensor):
                raise RuntimeError('engine input binding')
            # TensorRT must settle shape-dependent internal allocations before graph capture.
            if not engine.ctx.execute_async_v3(self.stream):
                raise RuntimeError('warm enqueue')
            checked(cu.cudaStreamSynchronize(self.stream))
            checked(cu.cudaStreamBeginCapture(self.stream,cu.cudaStreamCaptureMode.cudaStreamCaptureModeThreadLocal))
            try:
                for args,out in commands:
                    if enqueue(*args) or not engine.ctx.execute_async_v3(self.stream):
                        raise RuntimeError('fixed crop and inference enqueue')
                    for k,arr in out.items():
                        checked(cu.cudaMemcpyAsync(arr.ctypes.data,engine.buffers[k],arr.nbytes,cu.cudaMemcpyKind.cudaMemcpyDeviceToHost,self.stream))
            finally:
                graph=checked(cu.cudaStreamEndCapture(self.stream))
            try:
                self.executable=checked(cu.cudaGraphInstantiate(graph,0))
            finally:
                checked(cu.cudaGraphDestroy(graph))
            self.callback(lambda:checked(cu.cudaGraphExecDestroy(self.executable)))
        except BaseException:
            self.close()
            raise

    @contextmanager
    def enable(self,views):
        upload,forward=views.crops.frame,views.forward
        def frame(image):
            rgb=upload(image)
            checked(cu.cudaGraphLaunch(self.executable,self.stream))
            checked(cu.cudaStreamSynchronize(self.stream))
            return rgb
        def fetch(rect,flip=False):
            key=tuple(rect),bool(flip)
            if key not in self.outputs:
                return forward(rect,flip)
            views.count+=1
            return self.outputs[key]
        views.crops.frame=frame
        views.forward=fetch
        try:
            yield
        finally:
            views.crops.frame=upload
            views.forward=forward
