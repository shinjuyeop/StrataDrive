from contextlib import contextmanager
@contextmanager
def memo(views):
    upload,forward=views.crops.frame,views.forward
    counts=[0,0]
    cache={}
    def frame(image):
        cache.clear()
        return upload(image)
    def fetch(rect,flip=False):
        key=tuple(rect),bool(flip)
        counts[0]+=1
        if key not in cache:
            cache[key]=forward(rect,flip)
        else:
            counts[1]+=1
        return cache[key]
    views.crops.frame,views.forward=frame,fetch
    try: yield counts
    finally: views.crops.frame,views.forward=upload,forward
