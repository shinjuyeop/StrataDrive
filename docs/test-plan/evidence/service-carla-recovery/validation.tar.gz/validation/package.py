from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

root = Path('build/m9-closeout')
validation = root / 'validation'
out = Path('docs/test-plan/evidence/service-carla-recovery')

def read(path):
    return json.loads(path.read_text())

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

changed = set(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines())
sources = sorted(Path(p) for p in changed if not p.startswith('docs/') and Path(p).suffix in ('.cpp', '.hpp', '.py'))
write(out / 'sources.json', [dict(path=str(p), sha256=digest(p)) for p in sources])
with tarfile.open(out / 'sources.tar.gz', 'w:gz') as tar:
    for p in sources:
        tar.add(p, arcname=str(p))

# Retain the original failed development output separately from final acceptance.
for p in Path('build').glob('m9-closeout-*.log'):
    shutil.copy2(p, validation / p.name)
shutil.copy2('/d/shin/stratadrive-tools/m7-source/m7-nodrive-install.json', validation / 'ue-install-final.json')

audits = {name: read(validation / (name + '.json')) for name in (
    'carla-supervision', 'carla-work', 'prior-nominal', 'prior-input-loss',
    'service-final-audit', 'service-epoch-audit', 'service-ack-loss-audit',
    'service-actual-loss-audit', 'service-finite-audit')}
audits['service-first-audit'] = read(validation / 'm9-closeout-service-audit-first.log')
for name in ('service-final-audit', 'service-epoch-audit', 'service-first-audit'):
    assert audits[name]['passed']
assert audits['service-finite-audit']['pass_']
for name in ('service-ack-loss-audit', 'service-actual-loss-audit'):
    assert audits[name]['expected_rejection'] and not audits[name]['runtime_pass'] and audits[name]['service_commits'] == 0
assert audits['carla-supervision']['status'] == 'PASS_NATIVE_SUPERVISED_SPEED'
assert audits['carla-work']['status'] == 'PASS_SOLVER_WORK_SINGLE_EV'
assert audits['carla-supervision']['exact_native_replay']['observations'] == 6001
for name in ('prior-nominal', 'prior-input-loss'):
    assert audits[name]['exact_native_replay']['observations'] == 4001
write(out / 'audits.json', audits)

cohorts = []
with tarfile.open(out / 'someip.tar.gz', 'w:gz', compresslevel=6) as tar:
    for name in ('service-first', 'service-final', 'service-ack-loss', 'service-actual-loss', 'service-finite'):
        folder = root / name
        results = read(folder / 'results.json')
        report = read(folder / 'central-rejoin-1/result.json')
        negative = name in ('service-ack-loss', 'service-actual-loss')
        assert report['pass'] == (not negative) and results[0]['exit'] == int(negative)
        assert not report['forced_cleanup'] and not report['sdk_errors'] and not report['sanitizer_diagnostics']
        cohorts.append(dict(name=name, accepted_as='expected_rejection' if negative else 'successful_service',
                            revision='preliminary before historical producer reuse guard' if name == 'service-first' else 'final',
                            results=results, runtime=report))
        tar.add(folder, arcname=name)

carla = []
normalizations = []
for name, destination in (('first', 'failed-grid-phase'), ('grid', 'recovery')):
    rawpath = root / ('server-carla-' + name + '.json')
    raw = rawpath.read_text()
    server, end = json.JSONDecoder().raw_decode(raw)
    target = out / 'carla' / destination
    shutil.copy2(rawpath, target / 'server-output.raw')
    write(target / 'server.json', server)
    normalizations.append(dict(path=str(target / 'server.json'), source=str(target / 'server-output.raw'),
                               action='Decode complete first JSON object; retain trailing fragment verbatim in source',
                               trailing_characters=len(raw[end:]), original_sha256=digest(rawpath)))
    assert server['server_exit'] == 130 and server['stop_requested'] == 'SIGINT to owned process group after probe'
    assert server['probe_exit'] == (1 if name == 'first' else 0)
    for log in server['logs'].values():
        assert digest(Path(log['path'])) == log['sha256']
    for snapshot in server['native_source_snapshots'].values():
        assert digest(Path(snapshot)) == server['executed_artifact_sha256'][snapshot]
    report = read(target / 'result.json')
    assert (report['status'] == 'PASS_FUNCTIONAL_NATIVE_SOLVER_WORK') == (name == 'grid')
    carla.append(dict(name=destination, accepted=name == 'grid', runtime=report,
                      server_status=server['status'], server_exit=server['server_exit'],
                      probe_exit=server['probe_exit'], artifacts=server['executed_artifact_sha256']))
write(validation / 'server-report-normalization.json', normalizations)

# Save the runner that was actually used; only subsequent input validation differs.
runner = Path('tests/integration/carla/m7_1o_run.py').read_text().replace(" and a.native_fault=='none'", '', 1)
runtime_runner = validation / 'm7_1o_run-executed.py'
runtime_runner.write_text(runner)
assert digest(runtime_runner) == carla[1]['artifacts'][str(Path('tests/integration/carla/m7_1o_run.py').resolve())]

debug = ET.parse(validation / 'debug-tests.xml').getroot()
sanitized = ET.parse(validation / 'sanitized-tests.xml').getroot()
assert int(debug.attrib['tests']) == 1560 and int(debug.attrib['failures']) == 0
assert int(sanitized.attrib['tests']) == 90 and int(sanitized.attrib['failures']) == 0
for name in ('debug', 'sanitized'):
    text = (validation / ('test-cleanup-' + name + '.log')).read_text()
    assert '100% tests passed' in text and 'out of 1' in text
python = (validation / 'python-tests-final.log').read_text()
assert 'Ran 280 tests' in python and python.rstrip().endswith('OK')
for name in ('tidy-front-gcc12.log', 'tidy-functional-detail.log', 'tidy-wheel-detail.log'):
    text = (validation / name).read_text()
    assert 'non-user code' in text and 'error:' not in text

binaries = [Path(p) for p in ('build/m1-angle/tests/integration/carla/m7_1g/m7_wheel_shadow',
                              'build/m5-someip-normal/project/tests/integration/someip/someip_front_adapter')]
assert digest(binaries[0]) == audits['carla-supervision']['exact_native_replay']['binary_sha256']
report = dict(passed=True, base_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
              scope=['Terminal continuity service over retained epoch families', 'Actual higher INIT and supervised recovery in the same CARLA vehicle'],
              debug=dict(tests=1560, failures=0, excluded_label='runtime.wall'),
              sanitized=dict(tests=90, failures=0, asan=True, ubsan=True, tsan=False),
              python_tests=280,
              final_test_cleanup='Removed temporary diagnostic printing only; affected recovery test rebuilt and passed under Debug and ASan/UBSan',
              clang_tidy=dict(units=9, user_source_diagnostics=0, compatibility_retry='Clang14 front_adapter analysis retried with GCC12 standard headers after GCC13 chrono consteval error; actual binary remains GCC13'),
              binaries=[dict(path=str(p), sha256=digest(p)) for p in binaries],
              carla=carla, someip=cohorts,
              initial_failures=['Early coordinator Abort during recovery bootstrap', 'Drive NonDriving Actual incorrectly attributed old command receiver', 'CARLA rounded barrier mismatched original native job grid', 'Test ASSERT macro required braces for dangling-else warning', 'Auditor initially expected speed-loss instead of injected force-loss reason', 'Clang14 incompatible with GCC13 chrono'],
              closed_followups=2,
              remaining_in_this_scope=[],
              separate_extensions=['Whole wall/Target/ODD validation', 'Trained perception/model and online resistance estimation', 'Dynamic role membership', 'Single-epoch uninterrupted rollover and disk lifecycle'])
write(out / 'acceptance.json', report)

with tarfile.open(out / 'validation.tar.gz', 'w:gz', compresslevel=6) as tar:
    tar.add(validation, arcname='validation')
    for name in ('carla-runtime-first', 'carla-runtime-grid'):
        tar.add(root / name, arcname=name, filter=lambda item: None if '__pycache__' in item.name else item)
    for name in ('server-carla-first.stderr', 'server-carla-grid.stderr'):
        tar.add(root / name, arcname=name)
    for build in ('m1-angle', 'm1-angle-sanitized', 'm5-someip-normal/project'):
        for name in ('CMakeCache.txt', 'compile_commands.json'):
            tar.add(Path('build') / build / name, arcname='build-config/' + build + '/' + name)
print(json.dumps(dict(sources=len(sources), someip_attempts=len(cohorts), carla_attempts=len(carla), closed_followups=2)), flush=True)
