from pathlib import Path
import hashlib,json,os,signal,subprocess,time,xml.etree.ElementTree as ET
base=Path('build/post-m9-refactor');parent=1954080
children=[int(n) for n in subprocess.check_output(['ps','-o','pid=','--ppid',str(parent)],text=True).split()]
(base/'initial-validation-abort.json').write_text(json.dumps(dict(reason='cppcheck identified an extra Event copy in the new wrappers; final const-reference wrappers require rebuilt sanitizers',paused_supervisor=parent,finishing_children=children,initial_results='sanitizers.json',initial_sources='initial-sources.json',runtime_smoke_started=False),indent=2)+'\n')
for child in children:
 status=Path('/proc')/str(child)/'status'
 while status.exists():
  try:state=next(line for line in status.read_text().splitlines() if line.startswith('State:'))
  except FileNotFoundError:break
  if '\tZ' in state:break
  time.sleep(1)
try:os.kill(parent,signal.SIGTERM);os.kill(parent,signal.SIGCONT)
except ProcessLookupError:pass
folder=Path('build/m9-service-timing/tsan-unit');out=base/'tsan-final';out.mkdir(exist_ok=False);rows=[]
targets=['diagnostics_test','control_diagnostics_sil_test','control_recovery_sil_test','owner_diagnostics_test','native_diagnostics_test','startup_diagnostics_test','startup_diagnostics_sil_test','native_diagnostics_sil_test','clock_recovery_test','clock_recovery_vehicle_test','power_lifecycle_vehicle_test','native_sensor_matrix_test','owner_diagnostics_sil_test','m7_functional_test','m7_native_admission_test']
command=['cmake','--build',str(folder),'--target',*targets,'--parallel','2']
with (out/'build.log').open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
rows.append(dict(stage='build',command=command,exit=code));(base/'tsan-final.json').write_text(json.dumps(rows,indent=2)+'\n')
if code:raise SystemExit(code)
for target in targets:
 sub='tests/integration/carla/m7_1f/' if target=='m7_functional_test' else 'tests/integration/carla/m7_1q/' if target=='m7_native_admission_test' else ''
 binary=folder/sub/target;xml=(out/(target+'.xml')).resolve();command=['setarch','x86_64','-R',str(binary),'--gtest_output=xml:'+str(xml)]
 digest=hashlib.sha256(binary.read_bytes()).hexdigest()
 with (out/(target+'.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 tree=ET.parse(xml).getroot() if xml.exists() else None
 row=dict(target=target,command=command,exit=code,binary_sha256=digest,tests=int(tree.get('tests')) if tree is not None else 0,failures=int(tree.get('failures')) if tree is not None else 1,errors=int(tree.get('errors')) if tree is not None else 1)
 rows.append(row);(base/'tsan-final.json').write_text(json.dumps(rows,indent=2)+'\n');print(target,code,row['tests'],flush=True)
 if code or row['failures'] or row['errors']:raise SystemExit(1)
