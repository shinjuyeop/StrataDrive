from pathlib import Path
import datetime,json,subprocess,sys,time
base=Path('build/post-m9-refactor');watch=Path('/proc/1986604/cmdline')
while watch.exists():
 try:active=b'validate_tsan_final.py' in watch.read_bytes()
 except FileNotFoundError:break
 if not active:break
 time.sleep(1)
for name in ('asan-final.json','tsan-final.json'):
 rows=json.loads((base/name).read_text());assert len(rows)==16 and all(r['exit']==0 and r.get('failures',0)==0 and r.get('errors',0)==0 for r in rows),name
(base/'native-start-gate.json').write_text(json.dumps(dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),waited_tsan_supervisor=1986604,final_sanitizers_complete=True,heavy_prior_work_complete=True),indent=2)+'\n')
print('Final sanitizer gate passed; starting native smoke',flush=True)
with (base/'native-smoke-final.log').open('w') as stream:code=subprocess.run([sys.executable,str(base/'native_smoke.py')],stdout=stream,stderr=subprocess.STDOUT).returncode
print('Native smoke exit',code,flush=True);raise SystemExit(code)
