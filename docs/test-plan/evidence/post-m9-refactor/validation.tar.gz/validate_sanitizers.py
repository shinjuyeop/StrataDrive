from pathlib import Path
import hashlib,json,subprocess,xml.etree.ElementTree as ET
base=Path('build/post-m9-refactor');rows=[]
targets=['diagnostics_test','control_diagnostics_sil_test','control_recovery_sil_test','owner_diagnostics_test','native_diagnostics_test','startup_diagnostics_test','startup_diagnostics_sil_test','native_diagnostics_sil_test','clock_recovery_test','clock_recovery_vehicle_test','power_lifecycle_vehicle_test','native_sensor_matrix_test','owner_diagnostics_sil_test','m7_functional_test','m7_native_admission_test']
for profile,folder in [('asan_ubsan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 out=base/profile;out.mkdir(exist_ok=True)
 command=['cmake','--build',folder,'--target',*targets,'--parallel','2']
 with (out/'build.log').open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(profile=profile,stage='build',exit=code,command=command));(base/'sanitizers.json').write_text(json.dumps(rows,indent=2)+'\n')
 if code:raise SystemExit(code)
 for target in targets:
  sub='tests/integration/carla/m7_1f/' if target=='m7_functional_test' else 'tests/integration/carla/m7_1q/' if target=='m7_native_admission_test' else ''
  binary=Path(folder)/sub/target;xml=(out/(target+'.xml')).resolve();command=[str(binary),'--gtest_output=xml:'+str(xml)]
  if profile=='tsan':command=['setarch','x86_64','-R',*command]
  digest=hashlib.sha256(binary.read_bytes()).hexdigest()
  with (out/(target+'.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
  tree=ET.parse(xml).getroot() if xml.exists() else None
  row=dict(profile=profile,target=target,command=command,exit=code,binary_sha256=digest,tests=int(tree.get('tests')) if tree is not None else 0,failures=int(tree.get('failures')) if tree is not None else 1,errors=int(tree.get('errors')) if tree is not None else 1)
  rows.append(row);(base/'sanitizers.json').write_text(json.dumps(rows,indent=2)+'\n');print(profile,target,code,row['tests'],flush=True)
  if code or row['failures'] or row['errors']:raise SystemExit(1)
