from pathlib import Path
import hashlib,json,subprocess,sys,time
base=Path('build/post-m9-refactor')
for name in ('asan-final.json','tsan-final.json'):
 validation=json.loads((base/name).read_text())
 assert len(validation)==16 and all(r['exit']==0 and r.get('failures',0)==0 and r.get('errors',0)==0 for r in validation),name+' prerequisite incomplete/failed'
static=json.loads((base/'static/results.json').read_text());assert len(static)==5 and all(r['exit']==0 for r in static),'static prerequisite failed'
identity=json.loads((base/'sources.json').read_text());assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in identity['sources'].items())
binary=Path('build/m5-someip-normal/project/tests/integration/someip/someip_front_adapter');digest=hashlib.sha256(binary.read_bytes()).hexdigest()
out=base/'native';out.mkdir(exist_ok=False);cases=[('normal',None,0),('ack-loss','ack-loss',1),('stop-ack-loss','stop-ack-loss',1)]
(out/'protocol.json').write_text(json.dumps(dict(cases=cases,sources=identity,binary_sha256=digest,scope='post-refactor functional native smoke; prior finite loaded cohort is not rerun'),indent=2)+'\n')
rows=[]
for name,fault,expected in cases:
 assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest
 command=[sys.executable,'tests/integration/someip/front_run.py',str(out/name),'--profile','normal','--three','--simple-vehicle','--diagnostics','--diagnostic-service','--isolated-ecus','--cases','central-rejoin','--split-owner-io','--separate-aux-io','--owner-fifo','--sdk-fifo','--sdk-io-threads','2']
 if fault:command+=['--service-fault',fault]
 with (out/(name+'.runtime.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
 rows.append(dict(name=name,command=command,runtime_exit=code,expected_runtime_exit=expected,audits=[]));(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,'runtime',code,'expected',expected,flush=True)
(out/'runtime-complete.json').write_text(json.dumps(dict(runtimes=3,monotonic_ns=time.monotonic_ns()))+'\n')
for row in rows:
 readers=['audit_native_service' if row['name']=='normal' else 'audit_native_service_faults','audit_service_ordering','audit_service_timing','audit_service_response']
 for reader in readers:
  command=[sys.executable,'tests/integration/diagnostics/'+reader+'.py',str(out/row['name']/'central-rejoin-1'),'--mutations']
  with (out/(row['name']+'.'+reader+'.log')).open('w') as f:code=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT).returncode
  row['audits'].append(dict(tool=reader,exit=code))
 row['passed']=row['runtime_exit']==row['expected_runtime_exit'] and all(r['exit']==0 for r in row['audits']);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['name'],'audits',row['passed'],flush=True)
raise SystemExit(not all(row['passed'] for row in rows))
