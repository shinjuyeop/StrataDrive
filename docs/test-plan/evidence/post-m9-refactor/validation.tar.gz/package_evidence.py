from pathlib import Path
import collections,hashlib,json,shutil,tarfile,xml.etree.ElementTree as ET
base=Path('build/post-m9-refactor')
out=Path('docs/test-plan/evidence/post-m9-refactor')
identity=json.loads((base/'sources.json').read_text())
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==digest for p,digest in identity['sources'].items())
profiles={}
for name in ('asan-final','tsan-final'):
 rows=json.loads((base/(name+'.json')).read_text())
 assert len(rows)==16 and all(r['exit']==0 and r.get('failures',0)==0 and r.get('errors',0)==0 for r in rows)
 profiles[name]=dict(targets=len(rows)-1,tests=sum(r.get('tests',0) for r in rows),failures=0,errors=0,result_file=name+'.json')
root=ET.parse(base/'debug-final-tests.xml').getroot()
assert root.get('tests')=='1450' and root.get('failures')=='0' and root.get('skipped')=='0'
labels=collections.Counter()
for case in root.findall('testcase'):
 for prop in case.findall('properties/property'):
  if prop.get('name')=='cmake_labels':labels.update(prop.get('value').split(';'))
replay=json.loads((base/'replay-results.json').read_text());assert len(replay['cases'])==4 and all(r['passed'] for r in replay['cases'])
static=json.loads((base/'static/results.json').read_text());assert len(static)==5 and all(r['exit']==0 for r in static)
native=json.loads((base/'native/results.json').read_text());assert len(native)==3 and all(r['passed'] and len(r['audits'])==4 for r in native)
links=json.loads((base/'docs-links.json').read_text());assert not links['errors']
builds=json.loads((base/'final-builds.json').read_text());assert all(r['exit']==0 for r in builds)
acceptance=dict(date='2026-11-06',base_commit=identity['base'],scope='Post-M9 structural documentation/diagnostic refactor. Original physical deadlines, code mappings, recovery and clear predicates unchanged.',sources=identity,builds=builds,
 debug=dict(tests=1450,failures=0,skipped=0,labels=labels,xml='debug-final-tests.xml',log='debug-final-tests.log',reproduction_command=['ctest','--test-dir','build/m1-angle','-LE','runtime.wall','--output-on-failure','--parallel','2','--output-junit','build/post-m9-refactor/debug-final-tests.xml']),
 sanitizers=profiles,static=static,
 python=dict(carla_evidence_tests=4,service_validation_tests=12,failures=0,commands=[['python3','tests/unit/carla_evidence_test.py'],['python3','tests/unit/service_validation_test.py']]),
 replay=dict(cases=4,observations=sum(r['observations'] for r in replay['cases']),decoder_events=sum(r['decoded_original_events'] for r in replay['cases']),exact_match=True,result=replay,new_carla_server_runs=0),
 native=dict(scope='Three fixed post-refactor functional smoke cases, not another 7/7 loaded or 18/18 service cohort',normal_success=1,expected_fault_refusals=2,cases=native,binary_sha256=json.loads((base/'native/protocol.json').read_text())['binary_sha256'],heavy_work_overlaps_runtime=False),
 documentation_links=links,documentation=json.loads((base/'documentation.json').read_text()),intermediate_results=dict(accepted_as_final=False,initial_compiler_failure='debug-build-initial.log',initial_static_warnings='static-initial/',initial_by_value_sources='initial-sources.json',initial_sanitizers='sanitizers.json',interrupted_initial_validator='initial-validation-abort.json',initial_replay='replay-initial-results.json'),
 preserved_scope='All previous evidence/source snapshots and frozen protocols retained. Logical sanitizer checks do not assert native wall timing or Target conformance.')
(base/'acceptance.json').write_text(json.dumps(acceptance,indent=2,ensure_ascii=False)+'\n')
table=f"""| 검사 | 실제 결과·범위 |
| --- | --- |
| Debug CTest | 1450/1450; unit1098·논리 통합347·전송5. Wall 성능 수용과 구분 |
| ASan·UBSan | {profiles['asan-final']['tests']}/{profiles['asan-final']['tests']}, 관련15 targets |
| TSan | {profiles['tsan-final']['tests']}/{profiles['tsan-final']['tests']}, 같은15 targets; `setarch x86_64 -R` |
| Python | CARLA evidence4/4·서비스 판정12/12 |
| 기존 trace 재현 | 4/4, native 관측24004개·기존 decoder 이벤트68개 정확히 동일 |
| Native 3-ECU | 3/3: 정상 성공1·예상 고장 거절2, 각4개 독립 감사·변조 검사 통과 |
| 정적 검사 | 변경4 TU의 clang-tidy와 cppcheck 통과; 최종 프로젝트 진단0 |
| 문서·추적성 | {links['files']}개 문서·{links['links']}개 링크/앵커 오류0; CSV261개 고유 ID와 변경 함수 경로 확인 |"""
readme=(base/'README.md').read_text()
if 'FINAL_VALIDATION' in readme:readme=readme.replace('FINAL_VALIDATION',table)
else:
 start=readme.index('| 검사 | 실제 결과·범위 |');end=readme.index('\n\n새 경계 테스트',start);readme=readme[:start]+table+readme[end:]
(base/'README.md').write_text(readme)
out.mkdir(exist_ok=True)
for name in ('README.md','acceptance.json','sources.json'):shutil.copyfile(base/name,out/name)
with tarfile.open(out/'sources.tar.gz','w:gz') as archive:
 for p in sorted(identity['sources']):archive.add(p,arcname=p,recursive=False)
with tarfile.open(out/'native-smoke.tar.gz','w:gz') as archive:archive.add(base/'native',arcname='native')
exclude={'README.md','acceptance.json','sources.json','native-smoke.log'}
files=[]
for p in base.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(base)
 if rel.parts[0]=='native' or str(rel) in exclude:continue
 if rel.parts[0]=='baseline' and p.suffix!='.json':continue
 if '__pycache__' in rel.parts:continue
 files.append((p,rel))
with tarfile.open(out/'validation.tar.gz','w:gz') as archive:
 for p,rel in sorted(files):archive.add(p,arcname=str(rel),recursive=False)
manifest=[]
for p in sorted(out.iterdir()):
 if p.is_file() and p.name!='SHA256SUMS':manifest.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name)
(out/'SHA256SUMS').write_text('\n'.join(manifest)+'\n')
print(json.dumps(dict(evidence=str(out),validation_files=len(files),debug=acceptance['debug']['tests'],sanitizers=profiles,native_cases=len(native),sizes={p.name:p.stat().st_size for p in out.iterdir()}),indent=2))
