from pathlib import Path
import csv,hashlib,json,subprocess
p=Path('docs/test-plan/component-traceability.csv')
with p.open(newline='') as f:
 reader=csv.DictReader(f);rows=list(reader)
assert len({r['id'] for r in rows})==len(rows)
for row in rows:assert set(row)==set(reader.fieldnames) and all(v is not None for v in row.values()),row['id']
selected=[r for r in rows if r['id'] in ('C-M9-CTRL-07','C-M9-OWN-04','C-M9-REFACTOR-01')]
assert len(selected)==3
for row in selected:
 for location in row['implementation'].split(';'):
  name,sep,symbol=location.partition('#');path=Path(name);assert path.is_file(),name
  if sep:assert symbol.split('::')[-1] in path.read_text(),symbol
changed=set(subprocess.check_output(['git','diff','HEAD','--name-only'],text=True).splitlines())
changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())
files=sorted(n for n in changed if n.endswith(('.md','.csv')) and not n.startswith('docs/test-plan/evidence/'))
report=dict(rows=len(rows),unique_ids=True,updated_implementation_refs=selected,documentation={n:hashlib.sha256(Path(n).read_bytes()).hexdigest() for n in files})
Path('build/post-m9-refactor/documentation.json').write_text(json.dumps(report,indent=2)+'\n')
print('CSV',len(rows),'unique rows;',len(files),'current documentation hashes; updated implementation paths/symbols valid')
