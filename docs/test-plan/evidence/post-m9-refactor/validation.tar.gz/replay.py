from pathlib import Path
import hashlib,json,subprocess,sys,types
base=Path('build/post-m9-refactor');out=base/'replay';out.mkdir(exist_ok=True)
sys.path.insert(0,str(Path('tests/integration/carla').resolve()));sys.path.insert(0,str(Path('tests/integration/diagnostics').resolve()))
from evidence_io import json_rows
from audit_control_diagnostics import event
old=types.ModuleType('baseline_decoder');old.__file__='baseline_decoder.py'
exec(subprocess.check_output(['git','show','3d685f6:tests/integration/diagnostics/audit_control_diagnostics.py'],text=True),old.__dict__)
original=Path('docs/test-plan/evidence/m9_followup/carla');binary=Path('build/m7-functional/tests/integration/carla/m7_1g/m7_wheel_shadow').resolve();rows=[]
canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n'
for case in json.loads((original/'results.json').read_text()):
 path=original/case['name'];r=json.loads((path/'result.json').read_text());expected=hashlib.sha256();actual=hashlib.sha256();count=decoded=0
 command=[str(binary),'--native-solver-work','1','42','7',str(r['binding']['actor']),'--sim-horizon-ms','60000','--route',str((path/'route.txt').resolve()),'--diagnostic-fault',case['fault']]
 if case['sampled']:command+=['--admission-profile','sampled-actual-v1']
 with (out/(case['name']+'.stderr')).open('w') as err:
  p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
  try:
   for row in json_rows(path/'trace.jsonl'):
    for field in ('work_input','pose_input','native_input'):
     if row.get(field):p.stdin.write(row[field]+'\n')
    p.stdin.flush();received=json.loads(p.stdout.readline());before=canonical(row['native']);after=canonical(received)
    if before!=after:raise ValueError('changed native output '+case['name']+' barrier '+str(row['index']))
    expected.update(before);actual.update(after);count+=1
    for payload in row['native']['diagnostics']['events']:
     raw=bytes.fromhex(payload);prior=old.event(raw);reader=old.Reader(raw);reader.uint(1);reader.uint(2);reader.identity();prior['_related']=reader.identity()
     assert event(raw)==prior,'decoder changed existing fields or full related identity'
     decoded+=1
   p.stdin.close();assert p.wait(timeout=10)==0 and count==6001
  finally:
   if p.poll() is None:p.kill();p.wait()
 rows.append(dict(case=case['name'],observations=count,decoded_original_events=decoded,original_canonical_sha256=expected.hexdigest(),refactored_canonical_sha256=actual.hexdigest(),passed=True))
 (base/'replay-results.json').write_text(json.dumps(dict(binary=str(binary),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),baseline='3d685f6',cases=rows),indent=2)+'\n');print(case['name'],count,decoded,'PASS',flush=True)
