from pathlib import Path
import subprocess,json,time,os,fcntl,hashlib
root=Path.cwd();out=root/'build/m6-simple-vehicle';rows=[]
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
def run(name,argv,timeout=300,lock=True):
    entry={'name':name,'source':head,'argv':argv,'start_ns':time.time_ns()};rows.append(entry)
    with (out/(name+'.txt')).open('w') as log:
        try:
            with (root/'build/.m4-exclusive.lock').open('a') as guard:
                if lock:fcntl.flock(guard,fcntl.LOCK_EX|fcntl.LOCK_NB)
                entry['exit']=subprocess.run(argv,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except Exception as e:entry.update(exit=1,error=repr(e))
    entry['end_ns']=time.time_ns();(out/'final-checks.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,entry['exit'],flush=True)
    return entry['exit']==0
for label,path in [('normal','build/m4-readiness'),('asan','build/m1-angle-sanitized')]:
    if run('full-'+label+'-build',['cmake','--build',path,'--parallel','4']):
        run('full-'+label,['ctest','--test-dir',path,'--output-on-failure','--output-junit',str(out/('full-'+label+'.xml'))])
for label in ['asan','tsan']:
    if run('sdk-'+label+'-build',['cmake','--build',f'build/m5-someip-{label}/project','--target','someip_front_adapter','--parallel','4']):
        argv=['python3','tests/integration/someip/front_run.py',str(out/('sdk-final-'+label)),'--three','--fault-zone','rear','--native-watch','--fifo','--simple-vehicle','--profile',label,'--cases','normal']
        if label=='tsan':argv+=['--fixed-layout']
        run('sdk-'+label,argv,40,False)
if run('tsan-configure',['cmake','-S','.','-B','build/m4-contract-tsan-final']):
    if run('tsan-boundary-build',['cmake','--build','build/m4-contract-tsan-final','--target','simple_vehicle_test','normal_stop_test','--parallel','4']):
        run('tsan-boundary',['setarch','x86_64','-R','ctest','--test-dir','build/m4-contract-tsan-final','-R','^(SimpleVehicle\.|NormalStopTest\.|StopLease\.|NormalStopConfig\.)','--output-on-failure','--output-junit',str(out/'tsan-boundary.xml')])
run('python-pilot',['python3','tests/unit/someip_pilot_test.py'])
run('python-m6',['python3','tests/unit/m6_model_test.py'])
run('mil-final',['python3','models/longitudinal/mil.py',str(out/'mil-final')])

raise SystemExit(1 if any(r.get("exit",1)!=0 for r in rows) else 0)
