from pathlib import Path
import subprocess,json,csv,hashlib,platform,os,resource,xml.etree.ElementTree as ET
from datetime import datetime,timezone,timedelta
root=Path.cwd();out=root/'build/m6-simple-vehicle';ev=root/'docs/test-plan/evidence/m6_simple_vehicle'
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def cmd(a,**kw):return subprocess.check_output(a,text=True,**kw).strip()
save(out/'environment.json',{'source':cmd(['git','rev-parse','HEAD']),'cpp_execution_source':'13d1e87aab7de3fe38119839b0799fe383a5adbc','kernel':platform.platform(),'python':platform.python_version(),'compiler':cmd(['c++','--version']).splitlines()[0],'cmake':cmd(['cmake','--version']).splitlines()[0],'rtprio':resource.getrlimit(resource.RLIMIT_RTPRIO),'affinity':sorted(os.sched_getaffinity(0)),'uid':os.getuid()})
(out/'lscpu.txt').write_text(cmd(['lscpu']))
meta={'sdk_head':cmd(['git','-C','build/m5-someip-deps/vsomeip','rev-parse','HEAD']),'sdk_status':cmd(['git','-C','build/m5-someip-deps/vsomeip','status','--porcelain']),'profiles':{}}
old=json.loads((root/'build/someip-rear-adapter/instrumentation.json').read_text())
for profile in ['normal','asan','tsan']:
 b=root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter'
 libs=old['profiles'][profile]['libraries'];same=[]
 for lib in libs:
  p=Path(lib['path']);symbols=cmd(['nm','-D',str(p)])
  same.append(dict(lib,sha256=sha(p),same_as_m5=sha(p)==lib['sha256'],asan='__asan_' in symbols,ubsan='__ubsan_' in symbols,tsan='__tsan_' in symbols))
 symbols=cmd(['nm',str(b)]);meta['profiles'][profile]={'binary':str(b.relative_to(root)),'sha256':sha(b),'asan':'__asan_' in symbols,'ubsan':'__ubsan_' in symbols,'tsan':'__tsan_' in symbols,'libraries':same}
 commands=json.loads((root/f'build/m5-someip-{profile}/project/compile_commands.json').read_text());sel=[r for r in commands if any(s in r['file'] for s in ['simple_vehicle.cpp','normal_stop.cpp','front_adapter.cpp','m4_owner_network.cpp'])];save(out/(profile+'-compile-commands.json'),sel)
 p=root/f'build/m5-someip-{profile}/project/CMakeCache.txt';(out/(profile+'-build-options.txt')).write_text('\n'.join(l for l in p.read_text().splitlines() if l.startswith(('CMAKE_CXX_FLAGS','CMAKE_BUILD_TYPE','STRATADRIVE_','vsomeip')))+'\n')
 env=dict(os.environ,LD_LIBRARY_PATH=str(root/f'build/m5-someip-{profile}/install/lib'));(out/(profile+'-ldd.txt')).write_text(cmd(['ldd',str(b)],env=env)+'\n')
save(out/'instrumentation.json',meta)
rows=[];warn=[]
for cohort in sorted(out.glob('sdk-*')):
 if not (cohort/'results.json').is_file():continue
 for item in json.loads((cohort/'results.json').read_text()):
  d=cohort/(item['case']+'-'+str(item['repeat']));r=json.loads((d/'result.json').read_text());final=cohort.name.startswith('sdk-final-');row={'cohort':cohort.name,'case':item['case'],'raw_exit':item['exit'],'eligible':final,'pass':r['pass'],'vehicle':r.get('vehicle'),'renewal':r.get('renewal',r.get('rear',{}).get('renewal')),'forced_cleanup':r.get('forced_cleanup'),'sanitizer_diagnostics':r.get('sanitizer_diagnostics'),'sdk_errors':r.get('sdk_errors'),'native':r.get('native'),'processes':[{'role':v['role'],'exit':v['exit'],'expected_abrupt_stop':v.get('expected_abrupt_stop',False),'error':v.get('summary',{}).get('error')} for v in r.get('processes',[])]};rows.append(row)
  if final:
   bounds=[v.get('summary',{}).get(k,0) for v in r['processes'] for k in ('normal_stop_started','pre_shutdown_protection','stop_begin')];bounds=[v for v in bounds if v];inj=int((d/'inject').read_text()) if (d/'inject').exists() else 0
   if inj:bounds.append(inj)
   boundary=min(bounds) if bounds else 0
   sample=r['clock_sample']
   for f in d.glob('*.stdout'):
    for n,l in enumerate(f.read_text(errors='replace').splitlines(),1):
     if '[warning]' not in l and '[error]' not in l:continue
     dt=datetime.strptime(l[:26],'%Y-%m-%d %H:%M:%S.%f').replace(tzinfo=timezone(timedelta(seconds=sample['utc_offset_s'])))
     ns=int(dt.timestamp()*1e9)-sample['wall_ns']+sample['monotonic_ns'];text=l.split(']',1)[-1].strip()
     kind='interface/route' if 'state changed: up' in text else 'SD multicast lifecycle' if ('multicast' in text or '550ms' in text) else 'after stop/fault boundary' if boundary and ns>=boundary else 'REVIEW'
     warn.append({'cohort':cohort.name,'case':item['case'],'file':f.name,'line':n,'ns':ns,'boundary_ns':boundary,'classification':kind,'text':text})
save(ev/'results-summary.json',{'cpp_source':'13d1e87aab7de3fe38119839b0799fe383a5adbc','raw_attempts':len(rows),'raw_pass':sum(r['raw_exit']==0 for r in rows),'final_attempts':sum(r['eligible'] for r in rows),'final_pass':sum(r['eligible'] and r['raw_exit']==0 for r in rows),'cpp':{f:ET.parse(out/f).getroot().attrib for f in ['full-normal.xml','full-asan.xml','tsan-boundary.xml']},'sdk':rows})
with (ev/'results.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['cohort','case','raw_exit','eligible','pass']);w.writeheader();w.writerows({k:r[k] for k in w.fieldnames} for r in rows)
with (ev/'sdk-warnings.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['cohort','case','file','line','ns','boundary_ns','classification','text']);w.writeheader();w.writerows(warn)
print('SDK',len(rows),sum(r['raw_exit']==0 for r in rows),'warnings',len(warn),'review',[w for w in warn if w['classification']=='REVIEW'])
(out/'source.patch').write_text(cmd(['git','diff','ae3bb4f','13d1e87','--','.']))
