#pragma once
#include "frame_clock.hpp"
#include <array>
#include <memory>

namespace stratadrive::m7_functional {
struct Report {
    Time now=0,next_frame=0,lease_source=0,lease_expiry=0;
    unsigned release_mask=0,credit_mask=0,service_mask=0;
    bool armed=false,actual_interval=false;
    std::array<Time,3> actual_sources{};
    std::array<std::size_t,5> commands{};
    std::array<Time,5> leaf_body{};
    std::size_t controller_releases=0;
};
// Real native actors + real session/credit state machines, but ONLY a stationary
// M6 actuator/electrical fixture. No CARLA vehicle observation or actuation port.
// This deliberate type boundary prevents treating the shadow result as driving.
class FunctionalRig {
public:
    explicit FunctionalRig(Scope scope);
    ~FunctionalRig();
    FunctionalRig(const FunctionalRig&)=delete;
    FunctionalRig& operator=(const FunctionalRig&)=delete;
    Report observe(const Observation& observation);
    // Explicit test fault injection, set before observe. Missing processing is
    // never counted as an ACK. Credit loss keeps the original native age rules.
    void omit_role(int role);
    void stop_credit(bool value);
    void drop_actual(bool value);
private:
    struct Native;
    Scope scope_;FrameClock clock_;std::unique_ptr<Native> native_;
    int omitted_=-1;bool stop_credit_=false,drop_actual_=false;
};
} // namespace stratadrive::m7_functional
