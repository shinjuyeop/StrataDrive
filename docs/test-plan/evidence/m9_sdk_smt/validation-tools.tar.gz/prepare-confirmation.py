from pathlib import Path
import hashlib,json,subprocess
base=Path('build/m9-sdk-smt');report=json.loads((base/'service-campaign/results.json').read_text())
assert len(report)==30 and all(all(r[k]==0 for k in ('audit_exit','ordering_exit','timing_exit','response_exit'))for r in report),'first SMT campaign must pass before confirmation'
out=Path('build/m9-sdk-smt-confirmation');out.mkdir(exist_ok=False)
# Exact, standalone orchestration copied after the first campaign. Its own
# hash is in the generated manifest; ROOT stays the original checkout.
p=Path('tests/integration/someip/service_timing_campaign.py');s=p.read_text()
s=s.replace("HERE=Path(__file__).resolve().parent","HERE=Path('tests/integration/someip').resolve()")
start=s.index("    cases=[(p,f,0,1)");end=s.index("    files=[",start)
s=s[:start]+"    cases=[('tsan',fault,delay,repeat) for repeat in range(1,11) for fault,delay in [(f,0) for f in faults]+[('normal',250)]]\n"+s[end:]
s=s.replace("ROOT/'docs/test-plan/sdk-smt-protocol.md',","ROOT/'docs/test-plan/sdk-smt-protocol.md',ROOT/'docs/test-plan/sdk-smt-confirmation-protocol.md',")
s=s.replace("Path(__file__),","Path(__file__).resolve(),")
(out/'campaign.py').write_text(s)
old=json.loads((base/'service-campaign/manifest.json').read_text())['binaries']
for profile,digest in old.items():assert hashlib.sha256(Path(f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==digest
(out/'binary-identity.json').write_text(json.dumps({'matches_first_smt':True,'binaries':old},indent=2)+'\n')
cmd=['python3',str(out/'campaign.py'),str(out/'service-campaign'),'--split-owner-io','--separate-aux-io','--owner-fifo','--sdk-smt','--response-audit','--defer-audits']
with (out/'campaign.log').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(out/'run-result.json').write_text(json.dumps({'command':cmd,'exit':r.returncode})+'\n');print('confirmation',r.returncode,flush=True)
raise SystemExit(r.returncode)
