from pathlib import Path
import hashlib,json,subprocess,time
base=Path('build/m9-sdk-smt')
previous=json.loads(Path('build/m9-release-slot/service-campaign/manifest.json').read_text())['binaries']
for profile,digest in previous.items():assert hashlib.sha256(Path(f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==digest
(base/'binary-identity.json').write_text(json.dumps({'matches_release_slot':True,'binaries':previous},indent=2)+'\n')
subprocess.run(['python3',str(base/'snapshot.py')],check=True)
cmd=['python3','tests/integration/someip/service_timing_campaign.py',str(base/'service-campaign'),'--split-owner-io','--separate-aux-io','--owner-fifo','--sdk-smt','--tsan-repeats','3','--response-audit','--defer-audits']
begin=time.monotonic_ns()
with (base/'campaign.log').open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
(base/'run-result.json').write_text(json.dumps({'command':cmd,'begin_ns':begin,'end_ns':time.monotonic_ns(),'exit':r.returncode},indent=2)+'\n')
print('SMT campaign',r.returncode,flush=True)
raise SystemExit(r.returncode)
