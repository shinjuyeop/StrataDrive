from pathlib import Path

def replace(name,old,new):
 p=Path(name);s=p.read_text();assert old in s,(name,old);p.write_text(s.replace(old,new))
replace('docs/project-status.md','ECU 재기동·발행자 계승·로컬 Linux 서비스 요청/심사/clear; 3-ECU 서비스 조합 후속','ECU 재기동·발행자 계승·실제3-ECU terminal 서비스 심사/clear; 서비스 고장 주입 후속')
replace('docs/project-status.md','다음은 실제3-ECU 서비스 owner/SDK quiesce·새 global Epoch 후 물리 정지 취득 조합과 다른 고장 원인/복구다.', '''실제3-ECU terminal 서비스도 연결했다. Central 재기동의 Epoch2 정상 정지 후 별도 명시적 요청으로
Epoch3를 발급하고 실제8-role Release·운전/정지·보호 뒤9개 source/collector를 순서대로 드레인한다.
새 physical Actual은 전 writer의 freeze보다 뒤에서 취득됐음을 PCAP/CAN/원본 물리 기록으로 대조한다.
로컬 인가와 Review→Passed→별도 clear만 별도 service journal에 기록하며 원형 unknown 이력은 유지한다.
[Native 서비스 조합·분모·실패](test-plan/evidence/m9_native_service/README.md)를 따른다.
EpochStore fsync 동안 owner가 멈춘 초기 ASan 실패는 보호 ACK 후 비실시간 IO/계속 수신과
old owner의 지연 폐기로 수정했다. 초기 소켓 정리·독립 감사/취득 기록·compile 실패도 보존했다.
다음은 서비스 중 ACK/Actual 누락·정지 실패/시간초과의 실제 clear 거절과 다른 고장 원인/복구다.''')
replace('docs/roadmap.md','quiesce·새 global Epoch/물리 정지 조합과 native fault matrix/원인 연결·복구·', '''quiesce·새 global Epoch/물리 정지 조합은 [terminal native 서비스](test-plan/evidence/m9_native_service/README.md)에서
부분 검증했다. 다음은 서비스 중 ACK/Actual 누락·정지 실패/시간초과 거절과 native fault matrix/원인 연결·복구·''')
replace('docs/roadmap.md','frozen guard·원본 Actual adapter·별도 clear 요청을 연결한다. 다음은 실제3-ECU 서비스 owner/SDK', 'frozen guard·원본 Actual adapter·별도 clear 요청을 연결한다. 실제3-ECU 서비스 owner/SDK')
replace('docs/interfaces/diagnostics.md','## 다음 구현 경계', '''## 실제3-ECU terminal 서비스 연결

Host native3-ECU opt-in 구성은 동일 Central process/SDK에서 Epoch2의 실제 NormalStop/HV-off 뒤
별도 operator startup 요청으로 Epoch3를 연다. 실제8-role Release와9개 source accepted credit를
다시 확보한다. Review/clear 요청이 Epoch·INIT를 발급하지 않는다. Source producer/sequence와
physical model epoch는 유지한다. 새 source 세대를 임의로 만들지 않는다.

EpochStore IO는 기존 session의 normal authority를 닫고 실제 Front/Rear 보호 ACK를 받은 뒤
CPU15/SCHED_OTHER 작업에서 수행한다. 기존 owner는 수신/보호 처리를 계속하며 old owner graph는
새 graph와 분리해 join 이후 폐기한다. 새 Epoch의 실제 handshake 전에는 정상 dispatch를 열지 않는다.
기존 control FIFO8·10ms renewal/18ms support·NormalStop2500ms·diagnostic drain2000ms는 유지한다.

Epoch3 정상 운전/NormalStop/HV-off 뒤 명시적 보호를 선택한다. Front13/Rear114/Central128의
normal gate를 모두 닫고 마지막 진단 capture 뒤 `quiesce`한다. Front/Rear source의 queue/pending와
실제 durable ACK를 먼저 끝내고 collector를 멈춘다. 이후 실제 journal lifetime flock을 서비스가
인수해 같은9개 source/replica/merged cut을 심사/commit 동안 소유한다. SDK callback이 늦은 복사본을
전달해도 journal writer를 재개하지 않는다. Source/collector/report의 health와 정확한 ordinal을 대조한다.

Control owner/SDK/plant는 보호 상태에서 현재 Actual만 계속 제공한다. 서비스는 owner의 현재
feedback/current_sample을 받아 자체 monotonic now로 age를 다시 평가한다. Wheel/drive/brake 취득은
전 writer freeze 이후여야 하며 polling 시각으로 바꾸지 않는다. 준비 시 최대200ms 기다리지만
기존 stationary/age30ms/skew20ms는 유지한다. 요청 window2s·packet readiness100ms·16 connection은
이 terminal 서비스 fixture의 별도 유한 경계이며 control deadline을 연장하지 않는다.

기존 Event-only merged와 source/replica bytes는 보존한다. Fresh registry4/store8900에 원형 prefix를
가져오고 서비스 actor64를 사용한다. 고정 local peer/boot/Session/incident/revision 인가 뒤
Review3의 proof9→Review10→Passed11과 별도 Clear4/ID16만 추가한다. 정확히4 entry가 증가한다.
잘못된 PID/capability·미명시 disposition·old Epoch·stale revision·ID 충돌은 거절한다. Duplicate는
원래 receipt이며 추가 commit이 아니다. Canonical SD-5001 한 건만 해제하며 다른 DTC와 immutable
unknown history/count/generation은 보존한다. 전체 DTC 해소나 과거 loss-free 선언이 아니다.

독립 감사는 실제3개 global Session·24 Release ACK·27 accepted credit·11 stream의 원형 Data/ACK,
source→collector freeze 순서·closed role mask·exact9 cut·실제 local 인가와 별도 clear를 검사한다.
PCAP의 owner CRC32C/CAN P05와 원래 Actual의 값·시각을 별도 physical acquisition 기록에 대조한다.
단순화 차량 모델은 실제로 이동한 뒤 정지하며17개 변조를 거절한다. 기존10ms physical trace는
유지하고 서비스 구간의 acquisition만 별도 유한40000 기록에 남긴다.
[Recipe](../test-plan/diagnostics-protocol.md#native3-ecu-terminal-연속성-서비스-fixture),
[실행·분모·실패](../test-plan/evidence/m9_native_service/README.md)를 따른다.

이는 same-kernel2세대/one-shot terminal maintenance fixture다. Service 뒤 normal 운행을 재개하지
않고 ECU/SDK를 종료한다. 실행 중인 native-watch4ms profile/Target, 일반 service/RPC·다른 host/clock·
반복 세대·서비스 중 새 고장의 실제 거절 수용은 OPEN이다.

## 다음 구현 경계''')
replace('docs/interfaces/diagnostics.md','Central/Front/Rear 재기동과 로컬 Linux 서비스 연결 뒤에는 실제3-ECU 서비스 owner/SDK\nquiesce·새 global Epoch와 물리 정지 취득 조합 및 미결정 고장 조합·원인 연결/복구를 검증한다.', 'Central/Front/Rear 재기동과 terminal native 서비스 뒤에는 서비스 중 ACK/Actual 누락·정지 실패/\n시간초과에서의 실제 clear 거절 및 미결정 고장 조합·원인 연결/복구를 검증한다.')
p=Path('docs/archive/design-decisions.md');p.write_text(p.read_text()+'''

<a id="adr-0094"></a>

## ADR-0094: 실제3-ECU terminal 서비스와 보호 상태의 비실시간 Epoch IO

상태: same-kernel2세대/terminal fixture 부분 구현·검증. 일반 service 운용·서비스 중 고장 거절·
TBD-08·native4ms/Target·M9/학습자 수용 OPEN.

실제 Central 재기동의 unknown continuity incident보다 높은 실제 application Epoch가 필요하다.
Epoch2 NormalStop/HV-off 후 operator가 별도로 Epoch3 startup을 요청한다. Review는 startup 권한을
발급하지 않는다. 실제 보호 ACK를 받은 뒤 EpochStore fsync를 비실시간 작업에 맡기고 owner는
수신을 계속한다. Old graph는 단일 owner 사용이 끝난 후 보유만 하며 새 graph와 구분하고 SDK join
후 폐기한다. 초기 ASan에서 동기 fsync 동안 발생한 remote TX overflow/INIT 실패가 이 결정의 근거다.
FIFO/renewal/permission/handshake/정지/drain budget을 늘려 통과시키지 않는다.

Epoch3 실제 Release/운전/정지 뒤 전체 normal gate와 진단 capture를 닫는다. Source의 queue/pending/
실제 ACK를 먼저 끝낸 뒤 collector를 닫고 original FileJournal lifetime flock을 service writer가
인수한다. SDK/제어/plant는 보호 상태의 최신 Actual만 계속 제공한다. 실제 freeze report와 고정9개
source/replica를 검사부터 commit까지 소유하고 서비스 증분은 별도 registry4/store8900에만 둔다.
Terminal maintenance이며 capture/normal 운행을 재개하지 않는다. 일반적인 온라인 진단 정지는 아니다.

물리 취득은 마지막 freeze보다 뒤여야 한다. Trusted current_sample과 서비스의 독립 monotonic now를
사용하고 원래 age30ms/skew20ms·정지 값을 유지한다. 준비200ms/요청2s/packet100ms/16연결은 새
fixture 경계다. Physical producer의 별도 acquisition 기록과 PCAP/CAN 원본으로 같은 시각/값을
검사하며 기존10ms trace를 보간해 취득 원본으로 가장하지 않는다. Queue/소스 유실·미완료 ACK·
불완전/충돌 store·인가/시대/revision 불일치와 실제 증거 누락은 fail closed다.

고정 local peer/boot로 Review와 별도 clear를 구분한다. Unknown history 원형은 그대로 남고 정확한
canonical incident 한 건만 해제한다. 다른 fault/이전 미심사 원인·운행 권한을 일괄 해소하지 않는다.
실제 SimpleVehicle 이동/정지와 three-ECU/SDK의 기능·sanitizer 결과를 native4ms/실차/일반 운용
수용으로 올리지 않는다. 새 고장 조합·서비스 중 evidence/ACK 실패의 실제 거절은 다음 단계다.
''')
p=Path('docs/test-plan/component-traceability.csv');p.write_text(p.read_text()+'''C-M9-NATIVE-SERVICE-01,SYS-DIAG-001,tests/integration/someip/front_adapter.cpp;tests/integration/someip/native_diagnostic_routes.cpp,native-service-global3;native-service-mutations17,Explicit startup separate from review;actual three global Releases and27 credits;all255 normal gates closed;source ACK drain before collector;original journals held by lifetime flock,m9_native_service/results.json
C-M9-NATIVE-SERVICE-02,SYS-DIAG-001,tests/integration/someip/native_continuity_service.cpp;tests/integration/someip/native_service_client.py,native-service-admission;native-service-mutations17,Fixed local kernel peer and boot capability;scope/revision/disposition checks;duplicate receipt;separate explicit clear with exactly4 local transactions and immutable unknown history,m9_native_service/results.json
C-M9-NATIVE-SERVICE-03,SYS-DIAG-001,tests/integration/diagnostics/audit_native_service.py;tests/integration/someip/front_adapter.cpp,native-service-physical;native-service-mutations17,Independent PCAP owner CRC32C/CAN P05 and original model acquisition/value;after whole frozen cut;current stationary age/skew;SimpleVehicle motion then standstill;no polling timestamp substitution,m9_native_service/results.json
C-M9-NATIVE-SERVICE-04,SYS-DIAG-001,tests/integration/someip/front_adapter.cpp,native-service-epoch-io;native-service-regression,Close authority and receive real protection ACK before nonRT EpochStore IO;owner continues receive;old graph disposal after join;no FIFO or timing budget enlargement,m9_native_service/results.json
''')
p=Path('docs/test-plan/requirements-traceability.md');s=p.read_text().replace('검증한다. Clock/Actual 주입과 실제3-ECU 서비스 운용/plant 물리 정지 수용은 구분한다.', '''검증한다. Clock/Actual 주입과 실제3-ECU 서비스 운용/plant 물리 정지 수용은 구분한다.
C-M9-NATIVE-SERVICE-01–04는 [terminal native 서비스](evidence/m9_native_service/README.md)의
실제3 global Session/27 accepted credit·9 source/collector freeze·원본 physical/CAN/PCAP·인가와
별도 clear를 연결한다. Terminal fixture이며 서비스 후 운행 재개·고장 거절 matrix·Target/전체 TC 수용은 OPEN이다.''');p.write_text(s)
p=Path('docs/test-plan/README.md');s=p.read_text().replace('실제3-ECU 서비스 운용은 후속이다.', '[실제3-ECU terminal 서비스 조합](evidence/m9_native_service/README.md)은 별도 부분 검증이며 서비스 중 고장 거절/일반 운용은 후속이다.');p.write_text(s)
