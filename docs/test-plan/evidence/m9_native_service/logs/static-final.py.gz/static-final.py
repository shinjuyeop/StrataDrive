from pathlib import Path
import json,subprocess,shlex,re
raw=Path('build/m9-native-service');baseline=raw/'static-baseline';baseline.mkdir(exist_ok=True);rows=json.loads((raw/'compile_commands.cppcheck.json').read_text());before=[]
for row in rows:
 name=Path(row['file']).name
 if name=='native_continuity_service.cpp':continue
 old=baseline/name;old.write_bytes(subprocess.check_output(['git','show','HEAD:tests/integration/someip/'+name]))
 args=shlex.split(row['command']);args=[str(old.resolve()) if arg==row['file'] else arg for arg in args];args+=['-I'+str(Path('tests/integration/someip').resolve())]
 before.append(dict(directory=row['directory'],file=str(old.resolve()),command=shlex.join(args)))
(baseline/'native_diagnostic_routes.hpp').write_bytes(subprocess.check_output(['git','show','HEAD:tests/integration/someip/native_diagnostic_routes.hpp']))
(raw/'compile_commands.baseline.json').write_text(json.dumps(before,indent=2)+'\n')
common=['cppcheck','--enable=warning,style,performance,portability','--inline-suppr','--suppress=missingIncludeSystem','--std=c++20','--template={file}:{line}:{severity}:{id}:{message}']
reports={};commands=[]
for mode,project in [('baseline','compile_commands.baseline.json'),('current','compile_commands.cppcheck.json')]:
 command=common+['--project='+str(raw/project)]
 with (raw/('cppcheck-'+mode+'.log')).open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 commands.append(dict(command=command,exit=code));report=set()
 for line in (raw/('cppcheck-'+mode+'.log')).read_text().splitlines():
  match=re.match(r'(.*?):(\d+):(style|warning|error|performance|portability):([^:]+):(.*)',line)
  if match:report.add((Path(match[1]).name,match[3],match[4],match[5]))
 reports[mode]=report
new=reports['current']-reports['baseline'];result={'commands':commands,'baseline_diagnostics':sorted(reports['baseline']),'current_diagnostics':sorted(reports['current']),'new_diagnostics':sorted(new)}
for name in ['native_continuity_service.cpp','native_diagnostic_routes.cpp','front_adapter.cpp']:
 command=['clang-tidy','tests/integration/someip/'+name,'-p','build/m5-someip-normal/project','--extra-arg=-nostdinc++','--extra-arg=-isystem/usr/include/c++/11','--extra-arg=-isystem/usr/include/x86_64-linux-gnu/c++/11','--extra-arg=-isystem/usr/include/c++/11/backward','--warnings-as-errors=*']
 with (raw/('tidy-final-'+name+'.log')).open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 commands.append(dict(command=command,exit=code))
(raw/'static-final.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));raise SystemExit(bool(new) or any(c['exit'] for c in commands))
