from pathlib import Path
import datetime,gzip,hashlib,json,platform,runpy,shutil,subprocess,sys,tarfile,xml.etree.ElementTree as ET
root=Path.cwd();raw=root/'build/m9-native-service';out=root/'docs/test-plan/evidence/m9_native_service'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def junit(name):
 rows=ET.parse(raw/name).getroot().findall('.//testcase');bad=[r.attrib['name'] for r in rows if any(r.find(k) is not None for k in ('failure','error','skipped'))];return dict(passed=len(rows)-len(bad),total=len(rows),failed=bad)
def archive(src):
 if (out/(src.name+'.tar.gz')).exists():return
 with (out/(src.name+'.tar.gz')).open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:
   with tarfile.open(mode='w',fileobj=z) as t:t.add(src,arcname=src.name)
def gzcopy(src,dst):
 dst.parent.mkdir(parents=True,exist_ok=True)
 with dst.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(src.read_bytes())
sys.path.insert(0,str(root/'tests/integration/diagnostics'))
apis={k:runpy.run_path(str(root/'tests/integration/diagnostics'/v)) for k,v in [('service','audit_native_service.py'),('routing','audit_native_routing.py'),('central','audit_central_restart.py'),('adoption','audit_native_adoption.py')]}
results={'scope':'Same-kernel two-generation terminal three-ECU service with actual SimpleVehicle, explicit Epoch3, real source/collector quiesce and independent current physical sources. Latest Normal/ASan PASS; latest TSan Allocation precondition FAIL before service, no entries or clears. Previous successful TSan cohorts retained separately. General online service/RPC/repeated generations/TBD08/native4ms/Target/M9/learner acceptance OPEN', 'core':junit('core.xml'),'wall':junit('wall.xml'),'asan_component':junit('asan-component.xml'),'python_tests':24,'fingerprint_tests':2,'static':json.loads((raw/'static-final.json').read_text()),'release_sdk_opt_in_build_testing_off':'PASS','failure':json.loads((raw/'failure-analysis.json').read_text()),'prior_evidence':json.loads((raw/'prior-integrity.json').read_text()),'service_complete':{},'previous_service':{},'regression':{},'mutations_rejected':0,'source_variants':{}}
# Known literal source states retained for exact inventories, including style-only changes.
variant_bytes={}
for name in ['before-style-fix.tar.gz','before-last-scope-fix.tar.gz']:
 with tarfile.open(raw/name) as t:
  for member in t.getmembers():
   if member.isfile():variant_bytes[(member.name,sha_bytes:=hashlib.sha256(t.extractfile(member).read()).hexdigest())]=name
store_files={}
def compare_store(case):
 result=case/'result.json'
 if not result.exists():return None
 info=json.loads(result.read_text()).get('diagnostic_storage')
 if not info:return None
 original=Path(info['path']);copy=case/'native-diagnostics';count=0
 for f in original.rglob('*'):
  if not f.is_file():continue
  if f.is_socket():continue
  assert sha(f)==sha(copy/f.relative_to(original)),f;count+=1
 assert count==sum(p.is_file() for p in copy.rglob('*'));store_files[str(case.relative_to(raw))]=count;return count
def check_plan(folder):
 plan=json.loads((folder/'plan.json').read_text())
 for name,expected in plan['source_sha256'].items():
  if sha(root/name)!=expected:
   key=(name,expected);assert key in variant_bytes,(folder,key)
   results['source_variants'][name+':'+expected]={'archive':variant_bytes[key],'reason':'Service-only std algorithm and/or local bool declaration scope; current final cohort rebuilt and affected service path revalidated. Prior regression/code/binary inventory retained.'}
 return plan
for cohort in ('verified','accepted','complete'):
 rows=json.loads((raw/(cohort+'-service-results.json')).read_text());group={}
 for row in rows:
  name=cohort+'-'+row['mode'];folder=raw/name;plan=check_plan(folder);case=folder/'central-rejoin-1';compare_store(case)
  report=None
  if row['exit']==row['audit_exit']==0:
   d=apis['service']['load'](case);report=apis['service']['judge'](d);report['mutations_rejected']=apis['service']['mutations'](d);results['mutations_rejected']+=report['mutations_rejected']
  group[row['mode']]={'archive':name+'.tar.gz','exit':row['exit'],'audit_exit':row['audit_exit'],'report':report,'binary_sha256':plan['binary_sha256']}
 if cohort=='complete':results['service_complete']=group
 else:results['previous_service'][cohort]=group
for mode in ('normal','asan','tsan'):
 name='regression-'+mode;directory=raw/name;rows=json.loads((directory/'results.json').read_text());reports=[]
 for row in rows:
  folder=directory/row['case'];check_plan(folder)
  kind='central' if row['case']=='central-process-rejoin' else 'adoption' if row['case'].endswith('process-rejoin') else 'routing'
  case=folder/('central-rejoin-1' if kind=='central' else 'restart-live-1' if kind=='adoption' else 'normal-1' if row['case']=='normal' else 'command-loss-1');compare_store(case)
  if row['exit']==row['audit_exit']==0:
   d=apis[kind]['load'](case);r=apis[kind]['judge'](d);r['mutations_rejected']=apis[kind]['mutations'](d);r['case']=row['case'];reports.append(r);results['mutations_rejected']+=r['mutations_rejected']
 results['regression'][mode]={'archive':name+'.tar.gz','passed':len(reports),'total':len(rows),'reports':reports}
results['initial_service_attempts']=json.loads((raw/'final-service-results.json').read_text());results['original_store_regular_files_compared']=store_files
for p in raw.iterdir():
 if p.is_file() and p.suffix in ('.log','.json','.xml','.py','.stderr'):gzcopy(p,out/'logs'/(p.name+'.gz'))
 elif p.is_file() and p.name.endswith('.tar.gz'):shutil.copy2(p,out/p.name)
for name in ['attempt-normal','probe-vehicle','final-normal','final-asan','final-tsan','verified-normal','verified-asan','verified-tsan','accepted-normal','accepted-asan','accepted-tsan','complete-normal','complete-asan','complete-tsan','regression-normal','regression-asan','regression-tsan','static-baseline']:archive(raw/name)
(out/'results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only'],text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines();names={n for n in changed if not n.startswith('docs/test-plan/evidence/')}
names.update(['docs/development-guide.md','central/diagnostics/continuity_service.cpp','central/diagnostics/continuity_service.hpp','central/diagnostics/continuity_review.cpp','central/diagnostics/continuity_review.hpp','central/diagnostics/service_evidence.cpp','central/diagnostics/service_evidence.hpp','interfaces/someip/owner_transport.hpp','interfaces/remote/owner_wire.cpp'])
names.update('tests/integration/diagnostics/'+n for n in ['audit_control_diagnostics.py','audit_native_adoption.py','audit_native_routing.py','audit_someip_diagnostics.py','audit_continuity_review.py'])
overlay={}
for name in sorted(names):
 p=root/name
 if p.is_file():
  dest=out/'sources'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);overlay[name]=sha(p)
configs={};binaries={};sdk={}
for mode,path in [('core','build/m1-angle'),('core-asan','build/m1-angle-sanitized'),('release','build/m9-someip-release')]+[(m,'build/m5-someip-'+m+'/project') for m in ('normal','asan','tsan')]:
 p=root/path/'CMakeCache.txt';gzcopy(p,out/('CMakeCache-'+mode+'.txt.gz'));configs[mode]=sha(p)
for mode in ('normal','asan','tsan'):
 p=root/f'build/m5-someip-{mode}/project/tests/integration/someip/someip_front_adapter';binaries[str(p.relative_to(root))]=sha(p)
 lib=(root/f'build/m5-someip-{mode}/install/lib/libvsomeip3.so').resolve();symbols=subprocess.check_output(['nm','-D',str(lib)],text=True);sdk[mode]={'path':str(lib),'sha256':sha(lib),'tsan_instrumented':'__tsan_' in symbols,'asan_instrumented':'__asan_' in symbols}
assert sdk['tsan']['tsan_instrumented'] and sdk['asan']['asan_instrumented']
for name in ['build/m9-someip-release/tests/integration/someip/someip_front_adapter','build/m1-angle/remote_diagnostics_context_test','build/m1-angle/diagnostics_delivery_process_test','build/m1-angle-sanitized/remote_diagnostics_context_test','build/m1-angle-sanitized/diagnostics_delivery_process_test']:binaries[name]=sha(root/name)
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_overlay_sha256':overlay,'source_variants':results['source_variants'],'build_inputs_fingerprint':runpy.run_path(str(root/'tests/integration/runtime/check_m4_async.py'))['fingerprint'](),'binary_sha256':binaries,'sdk':sdk,'sdk_source_commit':subprocess.check_output(['git','-C','build/m5-someip-deps/vsomeip','rev-parse','HEAD'],text=True).strip(),'cmake_cache_sha256':configs,'platform':platform.platform(),'tools':{cmd[0]:subprocess.check_output(cmd,text=True,stderr=subprocess.STDOUT).strip() for cmd in [['c++','--version'],['cmake','--version'],['clang-tidy','--version'],['cppcheck','--version'],['python3','--version']]},'scope':results['scope'],'static_log':'logs/static-final.json.gz','source_only_final_cleanup':'before-last-scope-fix.tar.gz contains the previous front_adapter.cpp; before-style-fix.tar.gz reconstructs all earlier regression and verified sources','note':'Latest TSan service cohort FAILED before feature entry; do not infer full TSan/native4ms/Target qualification'}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name!='SHA256SUMS');(out/'SHA256SUMS').write_text(''.join(f'{sha(p)}  {p.relative_to(out)}\n' for p in files))
print(json.dumps(dict(files=len(files),overlay=len(overlay),service={k:(v['exit'],v['audit_exit']) for k,v in results['service_complete'].items()},regression={k:(v['passed'],v['total']) for k,v in results['regression'].items()},mutations=results['mutations_rejected'],core=results['core'],asan=results['asan_component'],wall=results['wall'])))
