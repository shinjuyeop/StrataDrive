from pathlib import Path
import subprocess,sys,json
raw=Path('build/m9-native-service');rows=[]
for mode in ('normal','asan','tsan'):
 command=[sys.executable,'-B','tests/integration/someip/native_diagnostics_run.py',str(raw/('regression-'+mode)),'--profile',mode]
 if mode=='tsan':command+=['--cases','normal','drop-ack','central-process-rejoin','--fixed-layout']
 with (raw/('regression-'+mode+'.log')).open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 rows.append(dict(mode=mode,command=command,exit=code));(raw/'regression-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(mode,code,flush=True)
