from pathlib import Path
import json,subprocess,sys
raw=Path('build/m9-native-service');rows=[]
for mode in ('normal','asan','tsan'):
 directory=raw/('final-'+mode)
 command=[sys.executable,'-B','tests/integration/someip/front_run.py',str(directory),'--three','--simple-vehicle','--diagnostics','--diagnostic-service','--cases','central-rejoin','--profile',mode]
 if mode=='tsan':command+=['--fixed-layout']
 with (raw/('final-'+mode+'.log')).open('w') as log:code=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT).returncode
 audit=[sys.executable,'-B','tests/integration/diagnostics/audit_native_service.py',str(directory/'central-rejoin-1'),'--mutations']
 with (raw/('final-'+mode+'.audit.json')).open('w') as log,(raw/('final-'+mode+'.audit.stderr')).open('w') as err:audited=subprocess.run(audit,stdout=log,stderr=err).returncode if code==0 else None
 rows.append(dict(mode=mode,command=command,exit=code,audit_command=audit,audit_exit=audited));(raw/'final-service-results.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(mode,code,audited,flush=True)
