from pathlib import Path
import fcntl,subprocess,json
base=Path('build/m9-feedback-order');rows=[]
def run(name,cmd):
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'validation.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
with open('build/.m4-exclusive.lock','a')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for p,d in [('normal','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
  run(p+'-control-build',['cmake','--build',d,'--target','vehicle_management_test','control_allocation_test','vehicle_coordinator_test','m4_async_runtime_test','--parallel','2'])
  run(p+'-control',(['setarch','x86_64','-R']if p=='tsan'else[])+['ctest','--test-dir',d,'-R','VehicleManagement|ControlAllocation|Coordinator|M4Async|M4Refresh','--output-on-failure'])
 db=json.loads(Path('build/m5-someip-normal/project/compile_commands.json').read_text())
 names=['central/coordinator/async_coordinator_port.cpp','tests/integration/someip/front_adapter.cpp']
 selected=[r for r in db if any(r['file'].endswith('/'+s)for s in names)]
 assert len(selected)==2
 (base/'compile_commands.json').write_text(json.dumps(selected,indent=2)+'\n')
 run('cppcheck',['cppcheck','--project='+str(base/'compile_commands.json'),'--enable=warning,performance,portability','--error-exitcode=1','--suppress=missingIncludeSystem'])
 for source in names:
  cmd=['clang-tidy',source,'-p','build/m5-someip-normal/project']
  for include in ['/usr/include/c++/11','/usr/include/x86_64-linux-gnu/c++/11','/usr/include/c++/11/backward']:cmd+=['--extra-arg=-isystem','--extra-arg='+include]
  run('clang-tidy-'+Path(source).stem,cmd)
