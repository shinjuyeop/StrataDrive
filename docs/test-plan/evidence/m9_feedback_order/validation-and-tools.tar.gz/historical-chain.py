"""Read preserved prior capture; search original known source then correlate CRC stages.
The source search is diagnostic, not a CAN/P05 acceptance oracle.
"""
import csv,json,sys
from pathlib import Path
sys.path.insert(0,'tests/integration/diagnostics')
from audit_someip_diagnostics import pcap
from audit_native_routing import IPS,CLIENTS
root=Path('build/m9-aux-io/subscribed-campaign/tsan-normal/central-rejoin-1')
messages,_=pcap(root/'traffic.pcap',tuple(range(30501,30509)),tuple(IPS.values()),{(sid,mid):tuple(CLIENTS.values())+(0x1312,)for sid in range(0x5344,0x534c)for mid in (0x10,0x20,0x40,0x50,0x60,0x70,0x80)})
source=801317973989765;found=[]
for m in messages:
 if m['method']==0x70 and source.to_bytes(8,'little')in m['payload']:
  crc=int.from_bytes(m['payload'][-4:],'little');stages=[]
  for p in root.glob('*.sdk-api.csv'):
   stages += [dict(r,file=p.name)for r in csv.DictReader(p.open())if r.get('crc')==str(crc)]
  found.append({'source':source,'crc':crc,'stages':stages})
Path('build/m9-feedback-order/historical-input-chain.json').write_text(json.dumps(found,indent=2)+'\n')
