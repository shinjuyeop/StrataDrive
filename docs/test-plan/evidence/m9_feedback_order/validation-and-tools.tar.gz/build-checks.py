from pathlib import Path
import fcntl,subprocess,json
base=Path('build/m9-feedback-order');results=[]
with open('build/.m4-exclusive.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 for profile,d in [('normal','build/m1-angle'),('asan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
  for name,cmd in [('unit-build',['cmake','--build',d,'--target','async_owner_test','--parallel','2']),('unit',(['setarch','x86_64','-R']if profile=='tsan'else[])+['ctest','--test-dir',d,'-R','AsyncOwnerTest|AsyncZoneOwner','--output-on-failure']),('adapter-build',['cmake','--build',f'build/m5-someip-{profile}/project','--target','someip_front_adapter','--parallel','2'])]:
   with (base/(profile+'-'+name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
   results.append({'profile':profile,'command':cmd,'exit':r.returncode});(base/'build-checks.json').write_text(json.dumps(results,indent=2)+'\n');print(profile,name,r.returncode,flush=True)
   if r.returncode:raise SystemExit(r.returncode)
