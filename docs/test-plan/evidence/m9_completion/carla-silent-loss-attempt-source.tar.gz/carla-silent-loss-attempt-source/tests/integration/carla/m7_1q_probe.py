#!/usr/bin/env python3
"""Native Actual -> server admission -> NoDrive functional closed loop.

Only this adapter owns CARLA stage/advance. No synthetic command/Actual fixture,
no corrected-wheel fallback, no timestamp repair, no general driving acceptance.
"""
import argparse
import copy
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import select
import signal
import subprocess
import time
import traceback

import carla
from audit_m7_1r_work import validate as validate_work, f32
from m7_1k_server_probe import FIELDS
from m7_sensor_capture import Capture
from m7_1p_bridge import aligned_snapshot, require, DOMAIN, SOURCE


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--native', type=Path, required=True)
    p.add_argument('--model', type=Path, required=True)
    p.add_argument('--fault', choices=('none', 'credit', 'command', 'snapshot','work-missing','work-duplicate','ev-ack-missing','ev-ack-duplicate','ev-ack-energy','rgb-drop','protection','wall-gap','client-loss','native-stall','pose-stale'), default='none')
    p.add_argument('--ticks', type=int, default=400)
    p.add_argument('--solver-work', action='store_true')
    p.add_argument('--compact-work', action='store_true')
    p.add_argument('--scenario', type=Path)
    p.add_argument('--cameras', action='store_true')
    p.add_argument('--record-video', action='store_true')
    p.add_argument('--live-view', action='store_true')
    p.add_argument('--terminal-response', action='store_true')
    p.add_argument('--simulation-continuous', action='store_true')
    p.add_argument('--speed-loop', action='store_true')
    p.add_argument('--route-profile', type=Path)
    p.add_argument('--propulsion-aware', action='store_true')
    p.add_argument("--speed-terminal",choices=("none","normal-stop","input-loss","stop-protection"),default="none")
    p.add_argument('--diagnostic-fault',choices=('none','input-loss','stop-ack-loss','front-command-loss','braking-timeout'))
    a = p.parse_args()
    require(not (a.record_video or a.live_view) or (a.cameras and a.fault=='none'), 'video requires nominal cameras')
    require(a.speed_terminal=="none" or (a.speed_loop and a.fault=="none"),"terminal speed scope")
    from m8_route_contract import load_route, pose_from_snapshot
    route=load_route(a.route_profile) if a.route_profile else None
    stop30=route is not None and route['schema']=='m8-normal-stop30-v1'
    require(a.diagnostic_fault is None or (stop30 and a.fault=='none' and a.speed_terminal=='none'),'diagnostic STOP30 scope')
    require(not (a.record_video or a.live_view) or stop30, 'video requires fixed STOP30 profile')
    if stop30:
        require(not a.propulsion_aware and a.fault=='none' and a.speed_terminal=='none','stop30 frozen nominal scope')
        a.speed_terminal='normal-stop30'
    feasibility=None
    if a.propulsion_aware:
        require(route is not None and route['schema'].startswith('m8-reference-'),'propulsion-aware route scope')
        from m8_reference_feasibility import require_feasible_route
        feasibility=require_feasible_route(route)
    require(not route or (a.simulation_continuous and not a.speed_loop and not a.scenario and a.ticks==route["ticks"] and a.fault in ("none","snapshot","work-missing","pose-stale")), "route scope")
    require(a.fault!="pose-stale" or route is not None,"pose fault scope")
    require(150 <= a.ticks <= ((route["ticks"] if route else 6000) if a.simulation_continuous else 950), 'bounded functional horizon')
    require(not a.speed_loop or (a.simulation_continuous and not a.scenario and a.ticks==4000 and a.fault in ('none','snapshot','work-missing')), 'speed loop scope')
    require(not a.simulation_continuous or (a.solver_work and (a.scenario or a.speed_loop or route) and not a.compact_work and (a.fault=='none' or a.speed_loop or route)),
            'continuous simulation requires original work/scenario and streaming raw trace')
    require(not a.compact_work or (a.solver_work and a.fault!='client-loss'), 'compact journal requires surviving owner and work')
    require(a.fault!='rgb-drop' or a.cameras, 'RGB fault requires cameras')
    require(not a.scenario or a.solver_work, 'scenario requires settled work')
    require(a.fault!='protection' or (a.solver_work and a.ticks==400), 'protection case requires 400 settled intervals')
    require(a.fault!='wall-gap' or a.solver_work, 'wall gap requires observed work')
    require(not a.terminal_response or a.fault=='wall-gap', 'terminal response requires wall gap')
    a.output.mkdir(parents=True, exist_ok=False)
    report = dict(status='FAIL', normal_driving_enabled=False, interval_work_valid=False,
                  mode='native eight-role functional Actual connection', fault=a.fault, cases=[])
    report['execution_profile']=(route['schema'] if stop30 or route['schema'].startswith('m8-reference-') else 'm8-route-v1') if route else ('m8-speed-v1' if a.speed_loop else 'm7-simulation-time-v1')
    if route:
        report['route_profile']=dict(definition=route,sha256=hashlib.sha256(a.route_profile.read_bytes()).hexdigest())
        (a.output/'frozen-route.json').write_bytes(a.route_profile.read_bytes())
    report['propulsion_aware']=a.propulsion_aware
    if feasibility:report['reference_feasibility']=feasibility
    report['speed_terminal']=a.speed_terminal
    if a.record_video:report['video_profile']='chase-rgb-960x540-20hz-v1'
    if a.live_view:report['live_view_profile']='chase-rgb-960x540-latest-frame-v1'
    report['speed_loop']=a.speed_loop
    report['continuous_simulation']=a.simulation_continuous
    report['requested_ticks']=a.ticks
    report['wall_runtime_accepted']=False
    if a.scenario:
        report['scenario'] = dict(path=str(a.scenario),sha256=hashlib.sha256(a.scenario.read_bytes()).hexdigest(),text=a.scenario.read_text())
    events = []
    client = carla.Client('127.0.0.1', 2200)
    client.set_timeout(10)
    world = original = actor = process = stderr = None
    capture = Capture(a.output,a.fault=='rgb-drop',1201 if a.simulation_continuous else 256,a.record_video,a.live_view) if a.cameras else None
    bound = False
    session, run = '0', ''
    key = os.environ['STRATADRIVE_M7_OWNER_KEY']
    history = {}
    count = normal = empty = 0
    work_sum = [0.,0.,0.,0.]
    ineligible = []
    settlements = 0
    stopped_frame = None
    raw = gzip.open(a.output/'trace.jsonl.gz','wt',compresslevel=1) if a.simulation_continuous else (a.output/'trace.jsonl').open('w')
    deferred_records = []
    native_stopped=False
    report['compact_solver_work']=a.compact_work

    def case(name, ok, **kw):
        report['cases'].append(dict(name=name, status='PASS' if ok else 'FAIL', **kw))
        require(ok, name)

    def rpc(op, record=True, **kw):
        req = dict(op=op, **kw)
        if op not in ('describe', 'bind'):
            req.update(session=session, run=run)
        req['owner_key'] = key
        result = json.loads(client.m7_nodrive(json.dumps(req)))
        if record:
            events.append(dict(request={k:v for k,v in req.items() if k != 'owner_key'}, response=result))
        return result

    try:
        report['client_version'] = client.get_client_version()
        report['server_version'] = client.get_server_version()
        case('version', report['client_version'] == report['server_version'] == '294096e-dirty')
        world = client.get_world()
        case('dedicated_world', world.get_map().name.endswith('/'+(route['map'] if route else 'Town03_Opt')) and not list(world.get_actors().filter('vehicle.*')))
        original = world.get_settings()
        report['original_settings'] = {k:getattr(original,k) for k in FIELDS}
        settings = world.get_settings()
        settings.synchronous_mode, settings.fixed_delta_seconds, settings.no_rendering_mode = True, .01, not a.cameras
        settings.substepping, settings.max_substep_delta_time, settings.max_substeps = True, .01, 10
        world.apply_settings(settings)
        world.tick()  # sole unbound initialization tick, before ego creation
        blueprint = world.get_blueprint_library().find('vehicle.lincoln.mkz_2020')
        blueprint.set_attribute('role_name', 'm7_native_actual_functional')
        spawn = world.get_map().get_spawn_points()[0]
        if route:
            case('route_map',world.get_map().name.split('/')[-1]==route['map'] and hashlib.sha256(world.get_map().to_opendrive().encode()).hexdigest()==route['xodr_sha256'])
            first=route['points'][0]
            spawn=carla.Transform(carla.Location(x=first['x'],y=first['y'],z=first['z']+.3),carla.Rotation(yaw=first['yaw'],pitch=first['pitch']))
            shift=spawn.transform(carla.Location(x=route['rear_axle_actor_m'][0],y=route['rear_axle_actor_m'][1],z=0))
            spawn.location.x+=first['x']-shift.x;spawn.location.y+=first['y']-shift.y
        report['route_fixture'] = dict(map=world.get_map().name,spawn_index=None if route else 0,seed=dict(engine_fixed_seed=0,traffic_randomness='none'),
            weather='ClearNoon',traffic=False,controller='M8 PurePursuit + SpeedPI' if route else ('M8 SpeedPI; no route following' if a.speed_loop else 'fixed requests; no route following'),
            spawn=dict(x=spawn.location.x,y=spawn.location.y,z=spawn.location.z,
                       roll=spawn.rotation.roll,pitch=spawn.rotation.pitch,yaw=spawn.rotation.yaw),
            opendrive_sha256=hashlib.sha256(world.get_map().to_opendrive().encode()).hexdigest())
        world.set_weather(carla.WeatherParameters.ClearNoon)
        actor = world.spawn_actor(blueprint, spawn)
        if route:world.tick()  # unbound initialization: obtain original actor snapshot before bind
        if capture: capture.attach(world,actor,carla)
        model_hash = hashlib.sha256(a.model.read_bytes()).hexdigest()
        if a.speed_loop or route:
            model=json.loads(a.model.read_text())
            case('speed_calibration',model['mass_kg']==1696 and all(w['radius_m']==.355 for w in model['wheels']))
        binding = rpc('bind', actor=str(actor.id), application='42', model_sha256=model_hash)
        bound, session, run = binding['locked'], binding['session'], binding['run']
        report['binding'] = binding
        if route:
            geometry=rpc('geometry');report['route_geometry']=geometry
            rear=geometry['geometry']['wheels'][2:]
            measured=[sum(w['px_rest_actor_m'][j] for w in rear)/2 for j in range(3)]
            case('route_rear_axle_geometry',geometry['ok'] and geometry['geometry']['valid'] and all(abs(x-y)<.001 for x,y in zip(measured,route['rear_axle_actor_m'])))
            native_route=a.output/'route.txt'
            native_route.write_text((('PROFILE '+route['scenario']+('v2' if route['schema']=='m8-reference-v2' else '')+('_AW' if a.propulsion_aware else '')+'\n') if stop30 or route['schema'].startswith('m8-reference-') else '')+''.join(f"{p['x']:.17g} {-p['y']:.17g}\n" for p in route['points']))
        case('compact_work_binding',binding.get('compact_solver_work',False)==a.compact_work)
        case('native_binding', binding['ok'] and binding['effort_profile'] == 'virtual-ev-v1-native-functional' and
             binding['model_sha256'] == model_hash and binding['application'] == '42' and binding['physics']['inputs_zero'])
        frame, end = int(binding['frame']), binding['simulation_seconds']
        ph = binding['physics']
        case('vehicle320_profile', ph['vehicle_substeps_low'] == ph['vehicle_substeps_high'] == 320)
        snapshot, delivery = aligned_snapshot(world.get_snapshot, frame)
        case('initial_clock', snapshot.timestamp.elapsed_seconds == end and
             math.floor(end*1e9+.5) == int(binding['logical_begin_ns']))
        stderr = (a.output/'native.stderr').open('w')
        process = subprocess.Popen([str(a.native.resolve()), '--native-solver-work' if a.solver_work else '--native-actual-export','1','42','7',str(actor.id)]+(['--scenario',str(a.scenario)] if a.scenario else [])+
                                   (['--sim-horizon-ms',str(route['ticks']*10 if route else 60000)] if a.simulation_continuous else [])+
                                   (['--speed-profile',{'none':'v1','normal-stop':'v1-stop','input-loss':'v1-input-loss','stop-protection':'v1-stop-protection'}[a.speed_terminal]] if a.speed_loop else [])+
                                   (['--route',str(native_route)] if route else [])+
                                   (['--diagnostic-fault',a.diagnostic_fault] if a.diagnostic_fault is not None else [])+
                                   (['--wall-watch',str(a.output/'native-wall.csv')] if a.fault=='wall-gap' else [])+
                                   (['--wall-response',str(a.output/'terminal.jsonl')] if a.terminal_response else []),
                                   stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=stderr, text=True)
        receipt = None
        previous_work_record = None
        for i in range(a.ticks+int(a.solver_work)):
            record = dict(index=i, frame=frame, simulation_seconds=end, physics=ph,
                          wall_begin_ns=time.monotonic_ns())
            try:
                if i==200 and a.fault=='native-stall':
                    # Stop ONLY our child at a completed physics barrier. No
                    # further input is sent, so resuming for cleanup cannot drive.
                    process.send_signal(signal.SIGSTOP);native_stopped=True
                    begin=time.monotonic_ns()
                    require(not select.select([process.stdout],[],[],10)[0], 'stalled native produced a reply')
                    record['host_watchdog']=dict(begin_ns=begin,detected_ns=time.monotonic_ns(),timeout_seconds=10,
                        fault='owned native process SIGSTOP; no input/tick while waiting')
                    stopped_frame=frame
                    case('host_watchdog_no_tick',rpc('describe')['frame']==str(frame))
                    report['fault_observed']='host liveness timeout; no fabricated Actual or physical stop claim'
                    break
                if a.fault == 'snapshot' and i == 200:
                    record['fault'] = 'withheld current snapshot; previous object and timestamp retained'
                    # Explicit local delivery fault; no extra tick or timestamp repair.
                    getter = lambda: previous_snapshot
                else:
                    getter = world.get_snapshot
                snapshot, delivery = aligned_snapshot(getter, frame)
                record['snapshot_delivery'] = delivery
                state=snapshot.find(actor.id)
                require(state is not None or i==0,'missing actor state after first physics tick')
                record['vehicle_state']=dict(frame=snapshot.frame,timestamp=snapshot.timestamp.elapsed_seconds,
                    source_identity='CARLA.ActorSnapshot',valid=state is not None)
                if state is not None:
                    transform=state.get_transform();velocity=state.get_velocity()
                    record['vehicle_state'].update(
                        position_ue_m=[transform.location.x,transform.location.y,transform.location.z],
                        rotation_ue_deg=[transform.rotation.roll,transform.rotation.pitch,transform.rotation.yaw],
                        velocity_ue_m_s=[velocity.x,velocity.y,velocity.z])
                if capture and a.live_view:
                    speed = math.sqrt(sum(v*v for v in record['vehicle_state'].get('velocity_ue_m_s', [0,0,0]))) * 3.6
                    capture.show_live(end, speed)
                require(snapshot.timestamp.elapsed_seconds == end, 'snapshot source timestamp')
                require(ph['generation'] == binding['physics']['generation'] and ph['nodrive'], 'generation')
                require(ph['vehicle_substeps_low'] == ph['vehicle_substeps_high'] == 320, 'profile')
                wheels = ph['wheels']
                require(len(wheels) == 4, 'wheel count')
                for j,w in enumerate(wheels):
                    require(w['index'] == j and w['bone'] == binding['physics']['wheels'][j]['bone'] and
                            w['solver_omega_source'] == SOURCE and math.isfinite(w['solver_omega_rad_s']), 'solver source')
                omega = [w['solver_omega_rad_s'] for w in wheels]
                ns = math.floor(end*1e9+.5)
                history[ns] = (omega[2]+omega[3])/2
                line = f'WHEEL 1 42 7 {DOMAIN} {frame} {end:.17g} 0.01 {actor.id} {frame} {ns} ' + ' '.join(f'{v:.17g}' for v in omega)
                record['native_input'] = line
                if a.solver_work and receipt:
                    work = receipt['solver_work']
                    means = work['rear_mean_rad_s'] if a.compact_work else [(s['after_rad_s'][2]+s['after_rad_s'][3])/2 for s in work['steps']]
                    solver_dt=f32(f32(.01)*f32(1/320)) if a.compact_work or work['sleeping'] else work['steps'][0]['dt_s']
                    packet = (f"WORK {frame} {receipt['logical_begin_ns']} {ns} "
                              f"{solver_dt:.17g} "
                              f"{work['sleeping']} {len(means)} "+' '.join(f'{v:.17g}' for v in means))
                    if i==200 and a.fault=='work-missing': packet=packet.rsplit(' ',1)[0]
                    record['work_input']=packet
                    process.stdin.write(packet+'\n')
                    if i==200 and a.fault=='work-duplicate': process.stdin.write(packet+'\n')
                record['wall_native_begin_ns']=time.monotonic_ns()
                if route:
                    require(state is not None,'route requires original ActorSnapshot')
                    pose=pose_from_snapshot(state.get_transform(),route,carla)
                    pose.update(actor=actor.id,epoch=42,frame=frame,source_ns=ns)
                    record['route_pose']=dict(pose)
                    sent_source=ns-10000000 if i==200 and a.fault=='pose-stale' else ns
                    pose_line=f"POSE {actor.id} 42 {frame} {sent_source} {pose['x_m']:.17g} {pose['y_m']:.17g} {pose['yaw_rad']:.17g}"
                    record['pose_input']=pose_line
                    process.stdin.write(pose_line+'\n')
                process.stdin.write(line+'\n');process.stdin.flush()
                require(bool(select.select([process.stdout],[],[],10)[0]), 'native reply timeout')
                native = json.loads(process.stdout.readline())
                record['native'] = native
                record['wall_native_end_ns']=time.monotonic_ns()
                if i==200 and a.fault in ('work-missing','work-duplicate','pose-stale'):
                    require(native['status']=='FAIL' and native['next_frame'] is None,'native input fail closed')
                    stopped_frame=frame
                    report['fault_observed']='native input rejected before further model jobs/tick'
                    break
                require(native['status'] == 'WHEEL_SHADOW_BARRIER' and native['admission']['ok'], 'native admission')
                if a.diagnostic_fault=='braking-timeout' and native['speed_terminal']['trigger_ns']:
                    # Declared environment fault: a persistent external forward
                    # load opposes normal braking. Actual pressure/torque, wheel
                    # sensor, stop timeout and single EV settlement stay native.
                    direction=state.get_transform().get_forward_vector()
                    force=carla.Vector3D(x=1800*direction.x,y=1800*direction.y,z=0)
                    actor.add_force(force)
                    record['diagnostic_external_force_n']=[force.x,force.y,force.z]
                require(native['now_ns'] == ns and native['next_frame'] == frame+1 and native['service_mask'] == 255, 'barrier identity')
                if a.solver_work and receipt:
                    settlement=native['settlement']
                    require(native['energy_basis']=='OBSERVED_SOLVER_WORK_SINGLE_EV' and native['carla_work_valid'] and
                            settlement['frame']==frame and settlement['end_ns']==ns and
                            math.isclose(settlement['total_mechanical_j'],sum(work_sum),rel_tol=1e-12,abs_tol=1e-12),'single EV complete-frame work settlement')
                    if not (i==200 and a.fault=='ev-ack-missing'):
                        ack=dict(ticket=receipt['ticket'],frame=str(frame),end_ns=str(ns),basis=native['energy_basis'],
                                 total_mechanical_j=settlement['total_mechanical_j'],balance_j=settlement['balance_j'])
                        if i==200 and a.fault=='ev-ack-energy': ack['total_mechanical_j']+=1
                        accepted=rpc('settle_work',record=False,**ack)
                        record['settlement_ack']=accepted
                        if accepted['ok']: settlements+=1
                        if i==200 and a.fault=='ev-ack-duplicate':
                            require(accepted['ok'],'first ack');accepted=rpc('settle_work',record=False,**ack)
                            record['duplicate_settlement_ack']=accepted
                        if i==200 and a.fault in ('ev-ack-duplicate','ev-ack-energy'):
                            require(not accepted['ok'] and accepted['latched'] and accepted['reason']=='ev_settlement_rejected','settlement rejection')
                            stopped_frame=frame;report['fault_observed']=accepted['reason'];break
                        require(accepted['ok'] and not accepted['awaiting_ev_settlement'],'settlement ack')
                    if i==a.ticks:
                        record['terminal_settlement']=True
                        report['final_settlement']=settlement
                        break
                for field in ('sensor_wheel','returned_wheel'):
                    value = native[field]
                    if value is None:
                        require(not native['armed_fixture'], 'missing armed wheel')
                    else:
                        require(value['source_ns'] in history and abs(value['rad_s']-history[value['source_ns']]) <= (0 if field=='sensor_wheel' else .005+1e-12), 'native source/value provenance')
                if capture and capture.snapshot()['errors']:
                    require(a.fault=='rgb-drop' and capture.snapshot()['dropped'], 'unexpected camera delivery gap')
                    stopped_frame=frame
                    report['fault_observed']='RGB missing frame; no reuse or timestamp rewrite; next tick blocked'
                    break
                if i==199 and a.fault=='client-loss':
                    require(native['admission']['normal'] and settlements==count==199,
                            'client loss requires a settled normal barrier')
                    record['client_loss']=dict(exit_code=73,native_pid=process.pid,
                        synchronous_mode=world.get_settings().synchronous_mode,
                        no_stage_pending=True,no_cleanup=True)
                    record['wall_end_ns']=time.monotonic_ns()
                    raw.write(json.dumps(record,separators=(',',':'))+'\n');raw.flush()
                    report.update(status='CLIENT_LOSS_INJECTED_NOT_CLEANUP',receipts=count,
                        settlements=settlements,client_loss=record['client_loss'],frame=frame)
                    (a.output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
                    # Deliberate process loss: no finally, pause/reset/close,
                    # apply_settings, sensor cleanup, or extra tick.
                    os._exit(73)
                if i==199 and a.fault=='wall-gap':
                    # Completed receipt+EV settlement; no new stage/advance is
                    # outstanding. The test withholds the next native input.
                    # Independent C++ monitor detects real missing owner slots;
                    # Python never sends PROTECT or a synthetic brake value.
                    require(native['admission']['normal'] and settlements==count, 'wall diagnostic established barrier')
                    process.stdin.write('WALL_ARM\n');process.stdin.flush()
                    require(bool(select.select([process.stdout],[],[],2)[0]), 'wall arm response')
                    arm=json.loads(process.stdout.readline());record['wall_guard_arm']=arm
                    require(arm['status']=='WALL_GUARD_ARMED', 'wall guard window')
                    require(bool(select.select([process.stdout],[],[],2)[0]), 'independent wall fault response')
                    stop=json.loads(process.stdout.readline());record['wall_guard_stop']=stop
                    require(stop['status']=='WALL_GUARD_STOP' and stop['next_frame'] is None and
                            not stop['normal'] and stop['credit_mask']==0 and stop['selected_mask']==255 and
                            stop['logical_barrier_ns']==ns and not stop['actual_exported'], 'terminal native selection without replay')
                    record['wall_stop_received_ns']=time.monotonic_ns()
                    before=rpc('describe');paused=rpc('pause');after=rpc('describe')
                    require(before['frame']==after['frame']==str(frame) and paused['latched'] and
                            after['physics']['inputs_zero'], 'wall containment without another tick')
                    record['wall_containment_ns']=time.monotonic_ns()
                    stopped_frame=frame
                    report['fault_observed']='independent native owner deadline miss; local protection selected; next tick blocked'
                    report['wall_runtime_accepted']=False
                    report['physical_protection_braking_accepted']=False
                    break
                proof = copy.deepcopy(native['native_export'])
                for k in ('service_mask','credit_mask','release_mask'):
                    proof[k] = str(native[k])
                if i == 200 and a.fault in ('credit','command'):
                    if a.fault == 'credit': proof['credit'][3] = None
                    else: proof['commands'][0] = None
                    record['fault'] = 'withheld original '+a.fault+' packet; no substitute'
                staged = rpc('stage_native', record=False, frame=str(frame+1), native=proof)
                record['staged'] = staged
                if not staged['ok']:
                    record['rejection'] = staged['reason']
                    require(i == 200 and a.fault in ('credit','command','ev-ack-missing') and staged['latched'], 'unexpected server rejection')
                    if a.fault=='ev-ack-missing': require(staged['reason']=='ev_settlement_required','missing settlement gate')
                    # Query, don't retry stage/advance after rejection.
                    report['fault_observed'] = staged['reason']
                    stopped_frame = frame
                    break
                require(int(staged['frame']) == frame, 'stage frame')
                if i == 150:
                    # A second unprivileged client tries both writer and tick paths
                    # while a real native Actual is staged but not applied.
                    foreign = carla.Client('127.0.0.1', 2200)
                    foreign.set_timeout(10)
                    blocked = foreign.apply_batch_sync([carla.command.ApplyVehicleControl(actor.id, carla.VehicleControl(throttle=1))], False)
                    case('foreign_batch_writer_denied', len(blocked)==1 and blocked[0].has_error() and
                         'M7 exclusive zero-probe owner' in blocked[0].error)
                    caught = None
                    try:
                        foreign.get_world().tick()
                    except RuntimeError as exc:
                        caught = str(exc)
                    case('foreign_tick_denied', caught is not None and 'M7 exclusive zero-probe owner' in caught and
                         rpc('describe')['frame']==str(frame), error=caught)
                if i==199 and a.fault=='protection':
                    # Submit while native and CARLA still share this frame,
                    # BEFORE physics advances. The next native subjob can then
                    # select protection causally within the following interval.
                    # Sending at i=200 would retroactively affect replayed jobs.
                    process.stdin.write('PROTECT\n');process.stdin.flush()
                    record['protection_request']=dict(kind='trusted local safety selection; no brake value',
                        source_ns=ns,frame=frame,wall_sent_ns=time.monotonic_ns())
                record['wall_advance_begin_ns']=time.monotonic_ns()
                queued = rpc('advance', record=False, ticket=staged['ticket'])
                require(queued['ok'], 'advance not accepted; never retry')
                deadline = time.monotonic()+10
                receipt = None
                while time.monotonic() < deadline:
                    reply = rpc('receipt', record=False)
                    require(not reply['latched'], 'postphysics latch')
                    if reply.get('receipt',{}).get('ticket') == staged['ticket']:
                        receipt = reply['receipt'];break
                    time.sleep(.001)
                require(receipt is not None, 'ambiguous advance; no retry')
                record['receipt'] = receipt
                record['wall_receipt_ns']=time.monotonic_ns()
                require(all(receipt[k] == binding[k] for k in ('run','session','actor','application','model_id','model_sha256','effort_profile')), 'receipt scope')
                require(receipt['clock_domain'] == 'm7-native-simulation-elapsed' and
                        receipt['source_identity'] == 'native-eight-role-CAN-P05-Actual; authenticated-local-owner', 'source identity')
                require(int(receipt['frame']) == frame+1 and receipt['simulation_begin_seconds'] == end and
                        abs(receipt['simulation_end_seconds']-end-.01)<1e-6, 'receipt interval')
                require(int(receipt['logical_begin_ns']) == ns and int(receipt['logical_end_ns']) == ns+10000000, 'whole interval')
                require(receipt['original_actual']['native'] == proof and receipt['inputs_cleared_after_physics'] and
                        receipt['interval_work_valid'] == a.solver_work and receipt['solver_substep_work_observed'] == a.solver_work, 'original actual/completion/work')
                if a.solver_work:
                    work = receipt['solver_work']
                    if a.compact_work:
                        require(work['valid'] and work['abi']==2 and work['count']==len(work['rear_mean_rad_s']) and
                                work['count']==(0 if work['sleeping'] else 320) and
                                all(math.isfinite(v) for v in work['rear_mean_rad_s']), 'compact complete work header')
                    else:validate_work(record, previous_work_record)
                    previous_work_record = record
                    for j in range(4): work_sum[j] += work['motor_work_j'][j]
                    if not work['forward_energy_eligible']: ineligible.append(i)
                applied = receipt['original_actual']['admitted_actual']
                for k in ('angle_rad','torque_nm','pressure_pa','oldest_actuator_ns','oldest_dependency_ns','exclusive_expiry_ns','normal','protection','normal_stop'):
                    require(applied.get(k,False) == native['admission'].get(k,False), 'server/native admission disagreement '+k)
                require(applied['empty_init'] == native['admission']['empty'], 'INIT admission')
                for j,w in enumerate(receipt['physics']['wheels']):
                    require(abs(w['set_drive_nm']-(applied['torque_nm']/2 if j>=2 else 0)) <= 1e-5, 'Actual drive mapping')
                    require(abs(w['set_friction_nm']-applied['pressure_pa']*.001/4) <= 1e-5, 'Actual brake mapping')
                count += 1;normal += applied['normal'];empty += applied['empty_init']
                previous_snapshot = snapshot
                frame, end, ph = int(receipt['frame']), receipt['simulation_end_seconds'], receipt['physics']
                if i == 150:
                    replay = rpc('advance', ticket=staged['ticket'])
                    case('ticket_single_use', not replay['ok'] and int(replay['frame'])==frame)
                    before = rpc('describe')['frame'];time.sleep(.25)
                    case('wall_pause_no_tick_or_restamp', rpc('describe')['frame'] == before)
            except Exception:
                record['error'] = traceback.format_exc()
                raise
            finally:
                record['wall_end_ns']=time.monotonic_ns()
                if a.compact_work:deferred_records.append(record)
                else:raw.write(json.dumps(record,separators=(',',':'))+'\n');raw.flush()
        if a.fault == 'none':
            case('native_closed_loop_complete', count == a.ticks and normal>300 and empty==4)
            if a.solver_work: case('all_receipts_settled_once',settlements==count)
            if not a.simulation_continuous:
                case('forward_motion_observed', ph['body_forward_velocity_m_s']>0, final_m_s=ph['body_forward_velocity_m_s'])
            elif a.diagnostic_fault!='braking-timeout':
                case('continuous_final_wheel_stop',all(w['solver_omega_rad_s']==0 for w in ph['wheels']))
            rejected = rpc('stage', frame=str(frame+1))
            case('native_profile_rejects_synthetic_stage', not rejected['ok'] and rejected['latched'] and
                 rejected['reason']=='native_actual_only' and rejected['frame']==str(frame))
            if a.speed_terminal!='none':
                terminal=native['speed_terminal']
                if a.diagnostic_fault not in (None,'none'):
                    case('diagnostic_protection_selected',terminal['detection_ns']>=terminal['trigger_ns']>0 and native['admission']['protection'])
                    report['diagnostic_fault']=a.diagnostic_fault
                    report['physical_stopped_at_end']=all(w['solver_omega_rad_s']==0 for w in ph['wheels']) and abs(ph['body_forward_velocity_m_s'])<=.001
                elif a.speed_terminal in ('normal-stop','normal-stop30'):
                    case('normal_stop_complete_hv_off',terminal['stop_state']==5 and terminal['stop_fault']==0 and terminal['power_off'] and native['admission']['normal_stop'])
                elif a.speed_terminal=='stop-protection':
                    case('stop_hold_protection',native['stop_handoff_ns']>terminal['trigger_ns']>0 and terminal['detection_ns']==native['stop_handoff_ns']+100000000 and native['admission']['protection'] and not terminal['power_off'])
                else:
                    case('speed_input_loss_protection',terminal['detection_ns']==terminal['trigger_ns']>0 and native['admission']['protection'] and terminal['speed_fault']==3)
                report['terminal_response']=terminal
            report['status'] = 'PASS_FUNCTIONAL_NATIVE_SOLVER_WORK' if a.solver_work else 'PASS_FUNCTIONAL_NATIVE_ACTUAL'
        elif a.fault=='protection':
            case('protection_continues_physics',count==a.ticks and normal>100 and normal<200 and empty==4)
            case('protection_actual_at_end',native['admission']['protection'] and not native['admission']['normal'] and
                 native['admission']['torque_nm']==0 and native['admission']['pressure_pa']>=1000000)
            case('all_protection_receipts_settled',settlements==count)
            report['final_body_forward_m_s']=ph['body_forward_velocity_m_s']
            report['final_signed_solver_wheels_rad_s']=[w['solver_omega_rad_s'] for w in ph['wheels']]
            report['status']='PASS_FUNCTIONAL_PROTECTION_ACTUAL'
        elif a.fault=='wall-gap':
            case('wall_fault_no_next_tick',stopped_frame is not None and rpc('describe')['frame']==str(stopped_frame))
            case('wall_stop_no_outstanding_work',count==settlements==199)
            report['status']='PASS_EXPECTED_WALL_CONTAINMENT'
        elif a.fault=='rgb-drop':
            case('rgb_drop_before_next_tick',stopped_frame is not None and rpc('describe')['frame']==str(stopped_frame))
            report['status']='PASS_EXPECTED_SENSOR_STOP'
        elif a.fault=='native-stall':
            case('host_stall_before_next_tick',count==200 and stopped_frame is not None and rpc('describe')['frame']==str(stopped_frame))
            report['status']='PASS_EXPECTED_HOST_LIVENESS_STOP'
        elif a.fault in ('credit','command','work-missing','work-duplicate','ev-ack-missing','ev-ack-duplicate','ev-ack-energy','pose-stale'):
            case('server_rejection_before_next_tick', stopped_frame is not None and rpc('describe')['frame']==str(stopped_frame))
            report['status'] = 'PASS_EXPECTED_SERVER_REJECTION'
        else:
            raise AssertionError('snapshot fault was not observed')
    except Exception:
        report['error'] = traceback.format_exc()
        if a.fault == 'snapshot' and count==200 and 'snapshot missing/skipped' in report['error']:
            report['status'] = 'PASS_EXPECTED_SNAPSHOT_STOP'
    finally:
        if a.compact_work:
            try:
                previous=None;drained=0
                for record in deferred_records:
                    if 'receipt' not in record:continue
                    r=record['receipt'];reply=rpc('solver_trace',record=False,ticket=r['ticket'])
                    require(reply['ok'] and reply['ticket']==r['ticket'] and reply['trace_frame']==r['frame'] and
                            all(reply[k]==r[k] for k in ('actor','session','run','physics_generation')), 'journal scope binding')
                    steps=reply['trace']['steps'];work=r['solver_work']
                    require(work['rear_mean_rad_s']==[(q['after_rad_s'][2]+q['after_rad_s'][3])/2 for q in steps], 'compact means equal raw solver')
                    work['steps']=steps
                    record['solver_trace_binding']={k:v for k,v in reply.items() if k!='trace'}
                    validate_work(record,previous);previous=record;drained+=1
                case('complete_raw_journal_drain',drained==count)
                report['journal_drained']=drained
            except Exception:
                report['journal_error']=traceback.format_exc();report['status']='FAIL'
            finally:
                for record in deferred_records:raw.write(json.dumps(record,separators=(',',':'))+'\n')
        raw.close()
        if capture:
            try:
                time.sleep(.5)  # bounded drain, no tick and no restamping
                capture.stop()
                if capture.viewer is not None:
                    report['live_view_frames_shown'] = capture.viewer.frames_shown
            except Exception:
                report['sensor_cleanup_error']=traceback.format_exc();report['status']='FAIL'
            finally:
                (a.output/'sensors.json').write_text(json.dumps(capture.snapshot(),indent=2)+'\n')
        report.update(receipts=count, normal_intervals=normal, empty_init_intervals=empty)
        if a.solver_work:
            report.update(solver_work_observed_intervals=count, motor_work_j=work_sum,
                          forward_energy_ineligible_intervals=ineligible, ev_settlement_connected=True,settlements=settlements,
                          interval_work_valid=count>0)
        try:
            if bound:
                before = rpc('describe')['frame']
                paused = rpc('pause')
                time.sleep(.25)
                after = rpc('describe')
                case('containment_pause_clear_no_tick', paused['latched'] and after['frame']==before and after['physics']['inputs_zero'])
                retry = rpc('advance', ticket='0')
                case('latched_no_resume', not retry['ok'] and retry['frame']==before)
                reset = rpc('reset')
                case('reset_requires_new_init', reset['ok'] and reset['latched'] and reset['physics']['inputs_zero'])
                closed = rpc('close')
                case('ego_destroyed', closed['ok'] and not closed['locked'] and not closed['registry_actor_present'])
                bound, actor = False, None
                if a.fault=='protection' and report['status'].startswith('PASS'):
                    actor=world.spawn_actor(blueprint,spawn)
                    rebound=rpc('bind',actor=str(actor.id),application='42',model_sha256=model_hash)
                    old_session=session
                    bound,session,run=rebound['locked'],rebound['session'],rebound['run']
                    case('protection_history_cleared_on_new_init',rebound['ok'] and bound and
                         int(session)>int(old_session) and not rebound['protected_hold_history_valid'] and
                         rebound['physics']['inputs_zero'])
                    rejected=rpc('advance',ticket='0')
                    case('new_init_requires_new_stage',not rejected['ok'] and rejected['frame']==rebound['frame'])
                    closed=rpc('close')
                    case('rebound_ego_destroyed',closed['ok'] and not closed['registry_actor_present'])
                    bound,actor=False,None
            if capture: capture.destroy()
            if process:
                if native_stopped:process.send_signal(signal.SIGCONT)
                process.stdin.close()
                report['native_exit'] = process.wait(timeout=10)
                process.stdout.close()
                if report['status'].startswith('PASS'): case('native_expected_exit', report['native_exit']==(2 if a.fault=='wall-gap' else 1 if a.fault in ('work-missing','work-duplicate','pose-stale') else 0))
            if world and original and not bound:
                if actor: actor.destroy()
                world.apply_settings(original)
                report['restored_settings'] = {k:getattr(world.get_settings(),k) for k in FIELDS}
                case('restored_settings_actors', report['original_settings']==report['restored_settings'] and not list(world.get_actors().filter('vehicle.*')))
        except Exception:
            report['cleanup_error'] = traceback.format_exc();report['status']='FAIL'
            if process and process.poll() is None:
                process.kill();process.wait(timeout=5);report['forced_native_stop']=True
        if stderr: stderr.close()
        (a.output/'events.json').write_text(json.dumps(events,indent=2)+'\n')
        (a.output/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report))
    return 0 if report['status'].startswith('PASS') else 1


if __name__ == '__main__':
    raise SystemExit(main())
