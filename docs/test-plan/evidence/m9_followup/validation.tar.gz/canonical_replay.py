from pathlib import Path
import hashlib,json,subprocess,sys
sys.path.insert(0,str(Path('tests/integration/carla').resolve()))
from evidence_io import json_rows
base=Path('build/m9-followup/carla-v2');binary=Path('build/m7-functional/tests/integration/carla/m7_1g/m7_wheel_shadow').resolve()
results=[]
for case in json.loads((base/'results.json').read_text()):
 path=base/case['name'];r=json.loads((path/'result.json').read_text())
 command=[str(binary),'--native-solver-work','1','42','7',str(r['binding']['actor']),'--sim-horizon-ms','60000','--route',str(path.resolve()/'route.txt'),'--diagnostic-fault',case['fault']]
 if case['sampled']:command+=['--admission-profile','sampled-actual-v1']
 original=hashlib.sha256();replayed=hashlib.sha256();count=0
 canonical=lambda v:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()+b'\n'
 with (path/'canonical-replay.stderr').open('w') as err:
  p=subprocess.Popen(command,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
  try:
   for row in json_rows(path/'trace.jsonl'):
    for key in ('work_input','pose_input','native_input'):
     if row.get(key):p.stdin.write(row[key]+'\n')
    p.stdin.flush();line=p.stdout.readline();actual=json.loads(line)
    a=canonical(row['native']);b=canonical(actual)
    if a!=b:raise ValueError('canonical byte mismatch '+case['name']+' '+str(row['index']))
    original.update(a);replayed.update(b);count+=1
   p.stdin.close();assert p.wait(timeout=10)==0 and count==6001
  finally:
   if p.poll() is None:p.kill();p.wait()
 results.append(dict(case=case['name'],observations=count,original_canonical_sha256=original.hexdigest(),replayed_canonical_sha256=replayed.hexdigest(),passed=True,scope='full native JSON with canonical key ordering, exact number types/values; original text whitespace is not compared'))
 print(case['name'],count,'PASS',flush=True)
Path('build/m9-followup/canonical-replay-results.json').write_text(json.dumps(results,indent=2)+'\n')
