from pathlib import Path
import gzip,hashlib,json,shutil,subprocess,tarfile
base=Path('build/m9-followup');out=Path('docs/test-plan/evidence/m9_followup');out.mkdir(parents=True,exist_ok=True)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def archive(target,entries):
 with tarfile.open(out/target,'w:gz') as t:
  for path,name in entries:t.add(path,arcname=name)
def read(path):return json.loads(Path(path).read_text())
identity=read(base/'source-identity.json')
assert all(sha(p)==h for p,h in identity['sources'].items())
assert all(sha(p)==h for p,h in identity['binaries'].items())
(out/'sources.json').write_text(json.dumps(identity,indent=2)+'\n')
archive('sources.tar.gz',[(Path(p),p) for p in identity['sources']]+[(Path(p),p) for p in ('docs/test-plan/sdk-fifo-protocol.md','docs/test-plan/carla-sampled-actual-protocol.md')])
carla_source=base/'carla-v2'
soak=read(base/'sdk-fifo-soak/results.json');matrix=read(base/'sdk-fifo-service/results.json');carla=read(carla_source/'results.json')
assert len(soak)==7 and len(matrix)==18 and len(carla)==4
summary={'base':identity['base'],'scope':'finite Host SDK FIFO1 and functional simulation10ms sampled Actual M9','native_soak':{'planned':7,'passed':sum(r['passed'] for r in soak),'results':soak},'native_service':{'planned':18,'passed':sum(r['runtime_exit']==(0 if r['fault']=='normal' else 1) and all(r[k]==0 for k in ('audit_exit','ordering_exit','timing_exit','response_exit')) for r in matrix),'results':matrix,'expected_runtime_rejections':12},'carla':{'planned':4,'passed':sum(r['passed'] for r in carla),'results':carla},'component':read(base/'validation-final/results.json'),'static':read(base/'static/results.json')}
summary['component_identity']={}
for profile,folder in [('release','build/m7-functional'),('debug','build/m1-angle'),('asan_ubsan','build/m1-angle-sanitized'),('tsan','build/m9-service-timing/tsan-unit')]:
 binaries=[Path(folder)/'tests/integration/carla'/sub/target for sub,target in [('m7_1f','m7_functional_test'),('m7_1q','m7_native_admission_test')]]
 summary['component_identity'][profile]={'binaries':{str(p):sha(p) for p in binaries},'cache_sha256':sha(Path(folder)/'CMakeCache.txt'),'tests':52}
 shutil.copy2(Path(folder)/'CMakeCache.txt',out/(profile+'-CMakeCache.txt'))
response=[]
for row in soak:
 name=row['case'];path=base/'sdk-fifo-soak'/name
 archive('sdk-soak-'+name+'.tar.gz',[(path,'sdk-fifo-soak/'+name)])
 p=base/'sdk-fifo-soak'/(name+'-audit_service_response.log')
 try:r=read(p)
 except ValueError:r={'error':'audit failed; original log retained'}
 response.append({'case':name,'passed':row['passed'],'response':r})
summary['native_soak']['response']=response
archive('sdk-service.tar.gz',[(base/'sdk-fifo-service','sdk-fifo-service')])
entries=[(p,p.name) for p in sorted(base.iterdir()) if p.is_file() and p.suffix in ('.json','.log','.py')]
entries += [(base/name,name) for name in ('static','validation-final','validation-v2')]
entries += [(p,'sdk-fifo-soak/'+p.name) for p in sorted((base/'sdk-fifo-soak').iterdir()) if p.is_file()]
archive('validation.tar.gz',entries)
archive('carla-launch-failure.tar.gz',[(base/name,name) for name in ('carla','carla-launch-source-before','carla-bad-python-preflight')])
summary['carla_launcher_failure']=read(base/'carla/aborted.json')
summary['canonical_replay']=read(base/'canonical-replay-results.json')
assert len(summary['canonical_replay'])==4 and all(r['passed'] and r['observations']==6001 and r['original_canonical_sha256']==r['replayed_canonical_sha256'] for r in summary['canonical_replay'])
summary['diagnostics']=read(base/'diagnostic-summary.json')
carla_out=out/'carla';carla_out.mkdir(exist_ok=True)
for p in sorted(carla_source.iterdir()):
 if p.is_file():shutil.copy2(p,carla_out/p.name)
for row in carla:
 source=carla_source/row['name'];target=carla_out/row['name'];target.mkdir(exist_ok=True)
 for p in sorted(source.iterdir()):
  if p.name=='trace.jsonl':
   with p.open('rb') as src,gzip.GzipFile(str(target/'trace.jsonl.gz'),'wb',mtime=0) as dst:shutil.copyfileobj(src,dst)
   # Original bytes are retained, compressed only after runtime/audits.
   original=sha(p);h=hashlib.sha256()
   with gzip.open(target/'trace.jsonl.gz','rb') as src:
    for b in iter(lambda:src.read(1024*1024),b''):h.update(b)
   assert h.hexdigest()==original
   row['trace_original_sha256']=original
  elif p.is_dir():shutil.copytree(p,target/p.name,dirs_exist_ok=True)
  else:shutil.copy2(p,target/p.name)
 runtime=carla_source/('runtime-'+row['name'])
 logs=carla_out/('runtime-'+row['name']);logs.mkdir(exist_ok=True)
 for p in runtime.iterdir():
  if p.is_file():shutil.copy2(p,logs/p.name)
summary['accepted']=all(summary[k]['passed']==summary[k]['planned'] for k in ('native_soak','native_service','carla')) and all(r['exit']==0 for r in summary['component']+summary['static'])
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
shutil.copy2(base/'README.md',out/'README.md')
with (out/'implementation.diff').open('wb') as f:subprocess.run(['git','diff','--','.',':(exclude)docs/test-plan/evidence/**'],stdout=f,check=True)
(out/'SHA256SUMS').write_text(''.join(sha(p)+'  '+str(p.relative_to(out))+'\n' for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS'))
print(json.dumps({k:summary[k]['passed'] for k in ('native_soak','native_service','carla')}),flush=True)
