from pathlib import Path
p=Path('docs/interfaces/diagnostics.md');s=p.read_text();where=s.index('## 다음 구현 경계');s=s[:where]+'''## 연속성 미확인 incident의 로컬 서비스 심사

저장 전 손실 여부는 정상 운전/원본 replay로 증명할 수 없다. 이 경계는 과거 손실이 없었다는
판정을 만들지 않는다. 원래 SD-5001/monitor10/subject=logical producer의 generation·boot·
`cause_unknown/unmapped`와 원형 event bytes를 영구 보존하고, 서비스 요청의 명시적
`AcceptUnknownHistory` disposition으로 **미확인 과거 이력을 수용했음**을 별도로 기록한다.
진단 actor/clock/registry를 임의로 바꾸거나 손실 event 수를 만들어 넣지 않는다.

`ContinuityInspector`는 trusted manifest의 최대32개 고유 stream/producer 전체를 검사하는 단일
비실시간 소유자다. 호출자는 생산자/전송 사용자를 quiesce하고 검사부터 commit까지 같은 frozen
journal/queue/ACK 경계를 소유해야 한다. 미등록/누락/alias/중복 source·registry 불일치·incomplete/
uncommitted suffix·source/replica 원본 불일치·미처리 pending·queue 유실/identity 오류·ACK 미완료는
거부한다. 각 현재 source에는 새 원본 global Session이 있어야 한다. 실제 endpoint의 accepted
credit에 따른 원본 context admission은 기존 `ContextualOutbox`가 수행한다. CRC는 인증을 대신하지 않는다.

| 단계 | 필수 근거와 효과 |
| --- | --- |
| 현재 recording 검사 | 원래 incident보다 높은 application Epoch의 실제8-role global Release. 원래 run/profile/clock과 최신 정지/normal-dispatch 차단. 모든 source/replica가 semantic 검사를 통과하고 원형 bytes/ordinal/ACK가 같아야 함 |
| Recording proof | 별도 서비스 producer의 새 Observation/Proof::Recording. 정확한 incident/occurrence·원래 Session enable·현재 관측 시각에 결속. 과거 loss-free를 주장하지 않음 |
| ContinuityReview | 명시적 AcceptUnknownHistory·현재 Session·incident EventId·record revision·proof EventId·ServiceEvidence·전체 stream의 producer/committed ordinal/tip EventId/CRC. 영속 commit 뒤에만 disposition을 반영 |
| Passed | proof→review→Passed의 별도 영속 순서. 같은 서비스 producer의 증가 sequence와 review ID를 참조해야 함. 심사 전에 저장한 Passed를 나중에 소급 승격하지 않음 |
| Clear | 기존 최신 정지 evidence·current Passed·정확한 revision·명시적 대상 목록 필요. Review만으로 clear되지 않으며 normal control/INIT/actuator 권한을 만들지 않음 |

정지 evidence의 기존 기준(바퀴0–.01rad/s·torque 절대값≤.1Nm·pressure100000–1500000Pa·source
age≤30ms·skew≤20ms)을 재사용한다. Proof도 심사 시점의 같은 clock에서30ms 이내여야 한다.
다른 run/clock·같은/오래된 Epoch·새 genuine Session 없는 local Ready·stale revision/proof·부분 stream
범위·유실된 queue·움직임·dispatch 허용 상태·모르는 native 원인은 승인하지 않는다.

`Ledger::unmapped()`는 미심사 원인이 남았는지를 뜻한다. 승인된 canonical continuity incident의
원본 `unmapped` bytes는 바꾸지 않는다. 일반 CodeNone/unknown reason 등 다른 unmapped 원인은
sticky 차단을 유지하고, 새 incident나 미심사 incident가 하나라도 있으면 clear를 막는다.
손상/incomplete를 뜻하는 `Kind::Gap`/`complete=false`는 이 심사로 해소할 수 없다.

재시작 시 disposition 이력과 이미 commit된 clear tombstone은 유지하지만 현재 condition/latch는
Unknown으로 재평가한다. 과거 proof·Review·Passed의 duplicate 재생은 새 심사를 활성화하지 않는다.
재시작/새 Session 이후 생성한 새 검사 proof와 명시적 심사가 다시 필요하다. 동일 request ID/동일
bytes는 idempotent이며 다른 bytes의 충돌·append 실패·용량 초과는 fail closed다. Review와 clear는
기존 `Limits::clears` 유한 예산64를 **공유**하며 기존 event512/record64/occurrence128을 늘리지 않는다.

로컬 service journal만 manifest registry4와 canonical Entry tag2(ContinuityReview)를 사용한다.
기존 Event(tag0)/Clear(tag1)의 bytes·schema1와 진단 wire1/registry1–3은 유지한다. Source/replica는
기존 registry3의 Event-only journal이다. 오래된 registry에 Review를 쓰거나 Review를 원격 Data로
보내는 것은 거부한다. 기존 파일을 in-place upgrade/repair하지 않고 별도 service journal을 provision한다.

이 API는 인증된 서비스 요청과 실제 최신 정지 상태를 받는 trusted writer-side component다.
현재 시험은 주입 가능한 logical monotonic clock99의 실제8-participant 객체·accepted credit·원본
source/replica와 별도 writer process의 SIGKILL4경계다. 실제 native ECU의 서비스 요청 인증/인가·
quiesce adapter·물리 표본 취득·remote clear/RPC·Target 연결은 후속이며, native 재합류만으로
심사가 실행되지 않는다. [고정 recipe](../test-plan/diagnostics-protocol.md#연속성-로컬-서비스-심사-fixture)와
[실행·한계](../test-plan/evidence/m9_continuity_review/README.md)를 따른다.

'''+s[where:]
s=s.replace('연속성 reconciliation/clear는 후속이다.', '로컬 연속성 서비스 심사는 아래 별도 경계를 따르며 native/원격 clear 연결은 후속이다.')
s=s.replace('연속성 reconciliation/clear 계약은 OPEN이다.', '원격/native clear 수용은 OPEN이며 로컬 서비스 심사는 아래 별도 계약을 따른다.')
s=s.replace('Central/Front/Rear process 재기동의 producer adoption·연속성 미확인 전달 뒤에는\n연속성 reconciliation과 미결정 고장 조합·원인 연결/복구를 검증한다.', 'Central/Front/Rear 재기동과 로컬 서비스 심사 뒤에는 실제 native 서비스 요청/인가·quiesce·\n최신 물리 evidence의 adapter와 미결정 고장 조합·원인 연결/복구를 검증한다.');p.write_text(s)
p=Path('docs/archive/design-decisions.md');s=p.read_text()+'''

## ADR-0092: 미확인 과거 이력 수용과 현재 recording Passed의 분리

상태: 로컬 trusted service component 구현. Native 서비스 adapter/인증/인가·remote clear·
TBD-08·native4ms/Target·M9/학습자 수용 OPEN.

재기동 후 prefix 재전송은 저장 전 손실 여부를 증명하지 못한다. 과거 미확인 사실을 거짓으로
해소하지 않고, canonical SD-5001 incident의 immutable bytes를 보존한 채 명시적
AcceptUnknownHistory disposition을 별도 로컬 transaction에 남긴다. 모르는 모든 native 원인이나
incomplete store를 일괄 승인하는 API는 만들지 않는다.

원래 incident보다 높은 실제 global Epoch와 최신 정지/dispatch 차단, fixed manifest 전체의
frozen source/replica/ACK/queue 검사 뒤에만 현재 Recording proof를 만든다. Proof→영속 Review→
새 Passed→명시적 clear를 구분하고 revision·incident/proof/request ID·stream ordinal/tip CRC로
결속한다. 과거 loss-free 선언이나 손실 개수 재구성·control/INIT 권한은 아니다.

재시작 뒤에는 기존 disposition/tombstone을 유지하고 현재 Unknown을 새 검사로만 해소한다.
예전 proof/Review duplicate나 심사 전에 수신한 Passed는 소급 승격하지 않는다. 새 incident·
일반 unmapped·저장 손상·budget 초과는 차단을 유지한다. Review/clear가 기존64 maintenance
예산을 공유하며 runtime FIFO·pending·retry·drain·wall/물리 예산은 바꾸지 않는다.

Event/Clear의 기존 encoding과 wire registry1–3은 유지하고 로컬 service journal registry4/tag2를
명시적으로 추가한다. 과거 파일을 자동 이주/repair하지 않는다. 별도 writer SIGKILL4경계와
독립 offline codec/원본/승인/clear 감사로 부분 검증한다. Native runtime의 자동 clear는 계속 없다.
''';p.write_text(s)
p=Path('docs/test-plan/diagnostics-protocol.md');s=p.read_text()+'''

## 연속성 로컬 서비스 심사 fixture

사전 고정: 별도 service journal9000/registry4에 canonical SD-5001 incident를 원형 보존한다.
주입 가능한 logical monotonic clock99/run10/profile1을 사용한다. 실제 coordinator/8-participant의
Epoch2 Release와 두 endpoint의 accepted RunLease 뒤 ContextualOutbox의 source500/501 및 별도
replica에 원본 context/incident를 commit/ACK한다. Epoch3의 실제8-role handshake/credit 뒤 모든
stream의 원본 prefix와 ACK가 일치해야 한다. 물리 정지 입력은 service component의 typed fixture
입력이며 실차/native plant 또는 wall 성능 관측으로 표시하지 않는다.

Trusted 서비스 요청 AcceptUnknownHistory가 있어야 전체 manifest를 검사한다. 누락/중복/foreign
stream·incomplete/tail·pending·queue 유실·미완료 ACK·stale/moving/dispatch 허용·잘못된 Session/
clock/revision/proof·미심사 다른 incident·일반 unknown cause·budget 초과는 거부한다. Service
proof가 과거 loss-free를 뜻하지 않음을 원본 unknown/unmapped bytes와 count1로 확인한다.

로컬 writer child가 Proof/Review/Passed/Clear의 fsynced watermark를 parent에 알린 직후 실제
SIGKILL한다. 네 독립 case의 새 writer는 committed prefix만 복구하고 condition/latch Unknown·
count1/generation1·원래 incident bytes·이미 commit된 disposition/clear만 유지해야 한다. Duplicate
Review나 과거 proof로 현재 Passed를 재활성화하지 않는다. 별도 새 검사/심사/Passed/clear의 성공
경로도 unit에서 확인한다. 오래된 registry3는 Review를 저장하지 못하고 remote Event Data는 local
Review/Clear transaction을 수용하지 않아야 한다.

독립 Python reader가 registry4/tag2와 기존 tag0/1·commit watermark·원래8 ACK씩·accepted credit4개·
source/replica/stream cut/CRC·explicit disposition·Passed/clear 순서/revision·SIGKILL·미확인 원본 보존을
감사한다. disposition/incident/proof/부분 범위/ordinal/replica/Release/credit/움직임/clear revision/
가짜 kill/Passed 제거의12개 변조를 거부한다. Normal/ASan4컷씩을 별도로 보관한다.

기존 native12개 Normal/ASan과 SDK TSan normal/drop-ack/Central rejoin3개를 회귀한다. 이들 native
경로는 Review를 자동 발행하지 않고 기존 SD-5001 clear 차단을 유지해야 한다. Compile/초기 test/
regression 실패·source/binary/config/tool hash와 원본 분모를 모두 보존한다. Native 서비스 요청
인증/인가·quiesce/최신 물리 evidence 연결·remote RPC·TBD-08·native4ms/Target 수용은 후속이다.
''';p.write_text(s)
p=Path('docs/test-plan/component-traceability.csv');s=p.read_text()+'''C-M9-REVIEW-01,SYS-DIAG-001,central/diagnostics/continuity_review.cpp#ContinuityInspector::prepare,ContinuityReviewTest.ManifestAndFrozenCoverageRejectOmissionForeignBindingPendingLossAndIncompleteStorage;ContinuityReviewTest.RequestAndServiceStateCannotSubstituteForNewGlobalReleaseOrExactOriginalContext,Trusted whole fixed manifest;new actual global epoch and credit admission;frozen exact source/replica/ACK;fresh stationary dispatch inhibition;no repair or control authority,m9_continuity_review/results.json
C-M9-REVIEW-02,SYS-DIAG-001,central/diagnostics/diagnostics.cpp#Ledger::review;central/diagnostics/diagnostics.cpp#Ledger::pass,ContinuityReviewTest.ExplicitUnknownHistoryDispositionAndFreshRecordingQualifyOnlyCurrentConditionBeforeClear;ContinuityReviewTest.PassedBeforeApprovalCannotBePromotedRetroactivelyAndRestartRequiresANewInspection,Explicit unknown-history disposition preserves immutable incident;separate current Recording proof and durable Review then Passed and explicit clear;no retroactive qualification,m9_continuity_review/results.json
C-M9-REVIEW-03,SYS-DIAG-001,central/diagnostics/diagnostics.cpp#Recorder::review;central/diagnostics/diagnostics_journal.cpp,ContinuityReviewTest.ReviewStorageFailureConflictingIdentityAndLegacyRegistryNeverGrantAServiceClear;ContinuityReviewTest.MaintenanceCapacityIsSharedAndCannotEvictAReviewToMakeRoomForClear,Local registry4/tag2;old bytes and wire unchanged;durable commit before projection;shared64 maintenance budget;storage/conflict fail closed,m9_continuity_review/results.json
C-M9-REVIEW-04,SYS-DIAG-001,central/diagnostics/diagnostics.cpp#Ledger::unmapped;central/diagnostics/diagnostics.cpp#Ledger::clear,ContinuityReviewTest.EveryUnreviewedIncidentAndConcurrentRevisionChangeContinueToBlockClear;ContinuityReviewTest.ReviewRejectsStaleRevisionWrongProofCutAndUnrelatedUnknownCauseWithoutTaintingARefusedRequest,Every unreviewed incident and ordinary unmapped cause blocks clear;exact revision;new proof after restart;refused requests grant no disposition,m9_continuity_review/results.json
C-M9-REVIEW-05,SYS-DIAG-001,tests/unit/continuity_review_process_test.cpp;tests/integration/diagnostics/audit_continuity_review.py,ContinuityReviewTest.SigkillAtProofReviewPassedAndClearCutsPreservesUnknownHistoryAndCommittedDisposition;continuity-review-mutations12,Actual service writer SIGKILL at4 durable cuts;original unknown-loss bytes;8-role Release and accepted credit;independent prefix/codec/disposition/Passed/clear audit,m9_continuity_review/results.json
''';p.write_text(s)
p=Path('docs/test-plan/requirements-traceability.md');s=p.read_text();idx=s.index('| Requirement |');s=s[:idx]+'''C-M9-REVIEW-01–05는 [로컬 연속성 서비스 심사](evidence/m9_continuity_review/README.md)의
미확인 과거 이력 수용·현재 recording proof·영속 Review/Passed/clear와 writer SIGKILL4경계를
연결한다. Trusted service component/typed logical fixture이며 실제 native 서비스 인증/인가·
quiesce/물리 evidence adapter와 SYS-DIAG-001/TC-DIAG-001 전체 수용은 OPEN이다.

'''+s[idx:];p.write_text(s)
p=Path('docs/test-plan/README.md');s=p.read_text().replace('| 실제3-process SOME/IP', '| M9 미확인 과거 이력 수용·현재 recording proof·영속 서비스 심사/clear·writer SIGKILL4경계 | [로컬 서비스 심사](evidence/m9_continuity_review/README.md) |\n| 실제3-process SOME/IP');p.write_text(s)
p=Path('docs/roadmap.md');s=p.read_text().replace('다음은 연속성 reconciliation/clear·native fault matrix와 원인 연결/복구·','[로컬 연속성 심사](test-plan/evidence/m9_continuity_review/README.md)는 미확인 과거 이력의\n명시적 수용과 현재 recording Passed/clear를 분리한다. 실제 native 서비스 인증/인가·quiesce·\n최신 물리 evidence adapter와 native fault matrix/원인 연결·복구·');p.write_text(s)
p=Path('docs/project-status.md');s=p.read_text().replace('Central/Front/Rear ECU 재기동·발행자 계승·prefix 재전송·손실 미확인; 연속성 조정 후속','ECU 재기동·발행자 계승·로컬 연속성 심사/clear; native 서비스 연결 후속')
s=s.replace('다음은 연속성 reconciliation/clear와 다른 native 고장 조합·원인 연결/복구다.', '''로컬 서비스 심사는 미확인 과거 이력의 명시적 수용과 현재 recording Passed를 분리한다.
전체 frozen source/replica/ACK·새 실제 Epoch/credit·최신 정지 입력을 확인하고 영속 Review 뒤
별도 Passed/clear를 요구한다. 재시작 후 과거 proof로 현재 상태를 재활성화하지 않는다.
[로컬 심사·원본·분모·실패](test-plan/evidence/m9_continuity_review/README.md)를 따른다.
다음은 실제 native 서비스 요청 인증/인가·quiesce·최신 물리 evidence adapter와 다른 고장 조합·원인 연결/복구다.''');p.write_text(s)
