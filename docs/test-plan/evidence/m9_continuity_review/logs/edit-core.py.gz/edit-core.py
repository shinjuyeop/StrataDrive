from pathlib import Path
p=Path('central/diagnostics/diagnostics.hpp');s=p.read_text().replace('using Entry = std::variant<Event, Clear>;','''// Local service transaction only. Accepting unknown historical loss is explicit;
// it neither reconstructs missing events nor declares continuity loss-free.
enum class ContinuityDisposition : std::uint8_t { None, AcceptUnknownHistory };
struct StreamCut {
    std::uint64_t stream{0}, producer{0}, committed{0}; EventId tip{}; std::uint32_t tip_crc{0};
};
struct ContinuityReview {
    EventId id{}, incident{}, proof_event{}; Session session{}; std::uint64_t revision{0};
    ContinuityDisposition disposition{ContinuityDisposition::None}; ServiceEvidence evidence{};
    std::vector<StreamCut> streams;
};
bool continuity_incident(const Event&) noexcept;
using Entry = std::variant<Event, Clear, ContinuityReview>;''')
s=s.replace('    Result clear(const Clear&);','    Result clear(const Clear&);\n    Result review(const ContinuityReview&);',1).replace('    bool unmapped() const noexcept { return unmapped_; }','    bool unmapped() const noexcept;')
s=s.replace('    std::vector<Episode> episodes_; std::vector<Clear> clears_;','''    struct Approval { ContinuityReview review; std::size_t event_floor; };
    std::vector<Episode> episodes_; std::vector<Clear> clears_; std::vector<Approval> approvals_;
    std::size_t approval_floor_{0};''')
s=s.replace('    Receipt clear(const Clear&);','    Receipt clear(const Clear&);\n    Receipt review(const ContinuityReview&);');p.write_text(s)
p=Path('central/diagnostics/diagnostics.cpp');s=p.read_text()
a=s.index('template<class I> void transfer(I& i,Clear& v) {');b=s.index('\n} // namespace',a)
s=s[:b]+'''
template<class I> void transfer(I& i,ContinuityReview& v) {
    i(v.id,v.incident,v.proof_event,v.session,v.revision,v.disposition,v.evidence);
    auto size=static_cast<std::uint32_t>(v.streams.size());i(size);
    if(!size || size>32)throw std::runtime_error("diagnostics review stream count");
    v.streams.resize(size);for(auto& cut:v.streams)i(cut.stream,cut.producer,cut.committed,cut.tip,cut.tip_crc);
}'''+s[b:]
s=s.replace('    else { auto c=std::get<Clear>(entry); w(c); }','    else if(tag==1) { auto c=std::get<Clear>(entry); w(c); }\n    else {auto review=std::get<ContinuityReview>(entry);w(review);}')
s=s.replace('    else throw std::runtime_error("diagnostics entry tag");','    else if(tag==2) {ContinuityReview review;r(review);entry=std::move(review);}\n    else throw std::runtime_error("diagnostics entry tag");')
s=s.replace('    episodes_.reserve(limits.occurrences); clears_.reserve(limits.clears);','    episodes_.reserve(limits.occurrences); clears_.reserve(limits.clears);approvals_.reserve(limits.clears);')
s=s.replace('void Ledger::restarted() noexcept {\n', 'void Ledger::restarted() noexcept {\n    approval_floor_=approvals_.size();\n')
s=s.replace('    unmapped_=unmapped_ || e.unmapped;','    unmapped_=unmapped_ || (e.unmapped && !continuity_incident(e));')
s=s.replace('    if(proof==events_.end() ||', '''    const auto incident=std::find_if(events_.begin(),events_.end(),[&](const Event& v){return v.kind==Kind::Fault && v.occurrence==e.occurrence && v.key==e.key;});
    if(incident!=events_.end() && continuity_incident(*incident)) {
        const auto approval=std::find_if(approvals_.begin()+static_cast<std::ptrdiff_t>(approval_floor_),approvals_.end(),[&](const Approval& a){
            return a.review.id==e.related && a.review.incident==incident->id && a.review.proof_event==e.proof_event && a.review.session==e.session;
        });
        if(approval==approvals_.end() || approval->review.id.producer!=e.id.producer || approval->review.id.sequence>=e.id.sequence ||
           static_cast<std::size_t>(&e-events_.data())<approval->event_floor || !comparable(e.times[static_cast<std::size_t>(Time::Observed)],approval->review.evidence.now) ||
           e.times[static_cast<std::size_t>(Time::Observed)].ns<approval->review.evidence.now.ns)return false;
    }
    if(proof==events_.end() ||''')
s=s.replace('!complete_ || !released_ || unmapped_ ||', '!complete_ || !released_ || unmapped() ||')
s=s.replace('if(clears_.size()>=limits_.clears ||', 'if(clears_.size()+approvals_.size()>=limits_.clears ||')
s=s.replace('const auto result=std::holds_alternative<Event>(entry)?ledger_.record(std::get<Event>(entry)):ledger_.clear(std::get<Clear>(entry));','const auto result=std::holds_alternative<Event>(entry)?ledger_.record(std::get<Event>(entry)):std::holds_alternative<Clear>(entry)?ledger_.clear(std::get<Clear>(entry)):ledger_.review(std::get<ContinuityReview>(entry));')
# review and immutable incident recognition are writer-side domain operations.
pos=s.index('EventQueue::EventQueue(')
s=s[:pos]+'''bool continuity_incident(const Event& e) noexcept {
    const auto& detected=e.times[static_cast<std::size_t>(Time::Detected)];const auto& observed=e.times[static_cast<std::size_t>(Time::Observed)];
    return e.kind==Kind::Fault && e.key.code==Code::RecordingGap && e.key.monitor==10 && e.key.subject &&
        e.id.sequence==1 && e.occurrence.sequence==1 && e.occurrence.producer==e.id.producer && e.occurrence.epoch==e.session.epoch &&
        e.native_reason==1 && e.state_before && e.state_before<std::numeric_limits<std::uint32_t>::max() && e.state_after==e.state_before+1 &&
        e.id.producer==((static_cast<std::uint64_t>(e.state_before)<<32)|e.key.subject) && e.cause_unknown && e.unmapped &&
        e.latch==Latch::Unknown && detected.domain==Domain::Monotonic && comparable(detected,observed) && detected.ns<=observed.ns &&
        comparable(e.session_enable,observed) && e.session_enable.ns<=observed.ns;
}
bool Ledger::unmapped() const noexcept {
    if(unmapped_)return true;
    return std::any_of(events_.begin(),events_.end(),[&](const Event& e){
        return continuity_incident(e) && std::none_of(approvals_.begin(),approvals_.end(),[&](const Approval& a){return a.review.incident==e.id;});
    });
}
Result Ledger::review(const ContinuityReview& c) {
    const auto old=std::find_if(approvals_.begin(),approvals_.end(),[&](const Approval& a){return a.review.id==c.id;});
    if(old!=approvals_.end()){if(encode(old->review)==encode(c))return Result::Duplicate;recording_gap();return Result::Conflict;}
    if(!valid(c.id) || !valid(c.session) || c.id.run!=c.session.run || c.disposition!=ContinuityDisposition::AcceptUnknownHistory ||
       c.streams.empty() || c.streams.size()>32 || !valid(c.incident) || !valid(c.proof_event) || c.id.producer!=c.proof_event.producer || c.id.sequence<=c.proof_event.sequence ||
       std::any_of(events_.begin(),events_.end(),[&](const Event& e){return e.id==c.id;}) || std::any_of(clears_.begin(),clears_.end(),[&](const Clear& e){return e.id==c.id;}))return Result::Invalid;
    if(!complete_ || !released_ || !(c.session==session_) || !same_stamp(c.evidence.enable,enable_) || !stationary(c.evidence))return Result::NotReady;
    const auto incident=std::find_if(events_.begin(),events_.end(),[&](const Event& e){return e.id==c.incident;});
    const auto proof=std::find_if(events_.begin(),events_.end(),[&](const Event& e){return e.id==c.proof_event;});
    const auto global=std::find_if(events_.begin(),events_.end(),[&](const Event& e){return e.kind==Kind::Session && e.session==session_;});
    if(incident==events_.end() || !continuity_incident(*incident) || c.session.epoch<=incident->session.epoch ||
       proof==events_.end() || proof->kind!=Kind::Observation || proof->proof!=Proof::Recording || !(proof->related==incident->id) || !(proof->key==incident->key) ||
       !(proof->occurrence==incident->occurrence) || !(proof->session==session_) || !same_stamp(proof->session_enable,enable_) || proof->unmapped || !proof->cause_unknown || proof->latch!=Latch::Clear ||
       !comparable(c.evidence.now,proof->times[static_cast<std::size_t>(Time::Observed)]) || proof->times[static_cast<std::size_t>(Time::Observed)].ns>c.evidence.now.ns ||
       c.evidence.now.ns-proof->times[static_cast<std::size_t>(Time::Observed)].ns>30000000 || global==events_.end() || global->expected_roles!=255 || global->received_roles!=255)return Result::NotReady;
    auto* r=mutable_record(incident->key);
    const auto episode=std::find_if(episodes_.begin(),episodes_.end(),[&](const Episode& p){return p.id==incident->occurrence;});
    if(!r || r->cleared || r->revision!=c.revision || episode==episodes_.end() || !episode->confirmed || episode->generation!=r->generation)return Result::NotReady;
    for(std::size_t i=0;i<c.streams.size();++i){const auto& cut=c.streams[i];
        if(!cut.stream || !cut.producer || !cut.committed || !valid(cut.tip) || cut.tip.run!=session_.run ||
           std::any_of(c.streams.begin(),c.streams.begin()+static_cast<std::ptrdiff_t>(i),[&](const StreamCut& v){return v.stream==cut.stream || v.producer==cut.producer;}))return Result::Invalid;
        const auto tip=std::find_if(events_.begin(),events_.end(),[&](const Event& e){return e.id==cut.tip;});
        if(tip==events_.end())return Result::NotReady;
        const auto bytes=encode(*tip);std::uint32_t crc=0xffffffff;
        for(auto byte:bytes){crc^=byte;for(unsigned bit=0;bit<8;++bit)crc=(crc>>1)^((crc&1)?0xedb88320U:0U);}
        if((~crc)!=cut.tip_crc)return Result::Conflict;
    }
    if(clears_.size()+approvals_.size()>=limits_.clears || revision_==std::numeric_limits<std::uint64_t>::max()){recording_gap();return Result::Capacity;}
    approvals_.push_back({c,events_.size()});r->revision=++revision_;return Result::Accepted;
}
''' +s[pos:]
pos=s.index('std::size_t Recorder::drain(')
s=s[:pos]+'''Receipt Recorder::review(const ContinuityReview& review) {
    Ledger next=ledger_;const auto result=next.review(review);
    if(result==Result::Duplicate)return {result,true,journal_.committed().size()};
    if(result!=Result::Accepted){if(!next.complete()){ledger_.recording_gap();journal_.invalidate();}return {result,false,journal_.committed().size()};}
    bool durable=false;if(journal_.writable()){try{durable=journal_.append(review);}catch(...){durable=false;}}
    if(durable)ledger_=std::move(next);else{ledger_.recording_gap();journal_.invalidate();}
    return {durable?result:Result::StorageFailure,durable,journal_.committed().size()};
}
''' +s[pos:];p.write_text(s)
p=Path('central/diagnostics/diagnostics_journal.cpp');s=p.read_text().replace('    std::uint32_t required=1;','    if(std::holds_alternative<ContinuityReview>(entry))return 4;\n    std::uint32_t required=1;').replace('registry>3','registry>4');p.write_text(s)
