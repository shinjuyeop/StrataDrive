"""Retrospective cause extraction; never changes the failed runtime verdict."""
import csv,hashlib,json,sys
from pathlib import Path
sys.path.insert(0,'tests/integration/diagnostics')
from audit_control_diagnostics import event
from audit_native_adoption import prefix

base=Path('build/m9-remaining/service-soak-v4/loaded-1/central-rejoin-1')
read=lambda name:list(csv.DictReader((base/name).open()))
original=read('native-diagnostics/rear/rear-1.originals.csv')
native=next(r for r in original if r['epoch']=='2' and r['producer']=='31' and r['monitor']=='6' and r['propagation']=='0')
fault_raw=next(raw for raw in prefix(base/'native-diagnostics/rear/source-31')['rows'] if (lambda e:e['epoch']==2 and e['kind']==1 and e['code']==8193)(event(raw)))
fault=event(fault_raw);assert fault['native_reason']==2 and fault['command_expiry_ns']==int(native['root_expiry'])
assert fault['detected_ns']==int(native['detected_ns']) and fault_raw in prefix(base/'native-diagnostics/central/merged-2')['rows']
rows=read('central-2.transport.csv');commands=[r for r in rows if r['epoch']=='2' and r['operation']=='3' and r['event']=='central-enqueued']
previous=[r for r in commands if r['original_source']==native['root_source']]
assert len(previous)==2 and [r['peer'] for r in previous]==['0','1']
front,rear=previous;front_ack=next(r for r in rows if r['event']=='central-result-accepted' and r['peer']=='0' and r['token']==front['token'])
following=next(r for r in commands if int(r['ns'])>int(rear['ns']) and r['peer']=='1')
expiry=fault['command_expiry_ns'];detected=fault['detected_ns']
assert int(front_ack['ns'])<=int(rear['ns'])<expiry<int(following['ns'])
local=next(r for r in read('rear-1.leaf-events.csv') if r['epoch']=='2' and r['event']=='command-expired' and r['owner']=='4')
assert int(local['deadline'])==expiry
physical=[r for r in read('physical.csv') if int(r['ns'])>=detected]
stationary=next(r for r in physical if float(r['speed_mps'])<=.01 and abs(float(r['torque']))<=.1 and float(r['pressure'])>=100000)
result=json.loads((base/'result.json').read_text());assert not result['pass']
names=['central-2.transport.csv','rear-1.leaf-events.csv','physical.csv','native-diagnostics/rear/rear-1.originals.csv','native-diagnostics/rear/source-31/journal','native-diagnostics/central/merged-2/journal','result.json']
out=dict(runtime_pass=False,full_service_completed=False,retrospective_analysis=True,
    fault=fault,native_original=native,front_command=front,front_ack=front_ack,rear_command=rear,next_rear_command=following,
    command_generation_to_front_ack_ns=int(front_ack['ns'])-int(front['payload_source']),
    front_enqueue_to_ack_ns=int(front_ack['ns'])-int(front['ns']),
    rear_enqueue_remaining_ns=expiry-int(rear['ns']),next_rear_enqueue_after_expiry_ns=int(following['ns'])-expiry,
    native_detection_after_expiry_ns=detected-expiry,local_expiry=local,
    first_sampled_stationary=stationary,stationary_after_detection_ns=int(stationary['ns'])-detected,
    last_physical=physical[-1],hv_off_at_end=float(physical[-1]['bus'])<60,
    source_fault_bytes_preserved_in_merged=True,
    original_sha256={n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in names})
Path('build/m9-remaining/loaded-failure-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k.endswith('_ns') or isinstance(v,bool)}))
