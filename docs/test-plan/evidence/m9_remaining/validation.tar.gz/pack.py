from pathlib import Path
import hashlib,json,subprocess,tarfile,xml.etree.ElementTree as ET
base=Path('build/m9-remaining');out=Path('docs/test-plan/evidence/m9_remaining')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
summary={'base':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'scope':'Clock/Power logical integration; finite quiet Host service soak; offline journal retention; loaded timing and full M9 remain open','logical':{},'native':{},'initial':{},'retention':{}}
for profile in ('debug','asan','tsan'):
 reports=json.loads((base/(profile+'-validation')/'results.json').read_text());assert len(reports)==7 and all(r['pass'] for r in reports)
 assert sum(r['tests'] for r in reports)==88
 for r in reports:assert sha(r['command'][3] if profile=='tsan' else r['command'][0])==r['sha256']
 audit=json.loads((base/('audit-'+profile+'.json')).read_text());assert len(audit)==12 and all(r['passed'] for r in audit)
 summary['logical'][profile]={'targets':reports,'vehicle_cases':12,'audits_passed':12,'mutations_rejected':sum(len(r['mutations_rejected']) for r in audit)}
 with tarfile.open(out/(profile+'.tar.gz'),'w:gz') as tar:
  for group in ('power','clock'):tar.add(base/(profile+'-validation')/group,arcname=profile+'/'+group)
 trace=ET.parse(base/('trace-'+profile+'.xml')).getroot();assert int(trace.get('tests'))==37 and int(trace.get('failures'))==0
summary['debug_regression']={'tests':1336,'passed':1336,'scope':'unit+integration.logical+integration.transport'}
assert '100% tests passed, 0 tests failed out of 1336' in (base/'ctest-debug.log').read_text()
summary['later_trace_boundary']={'debug':37,'asan_ubsan':37,'tsan':37}
summary['python']={'service_and_crc':14,'pilot':29,'retention':8,'capture':2,'crc_reference_vectors':1026}
retention=json.loads((base/'retention-results.json').read_text());assert len(retention)==36 and all(r['independent_replay']['passed'] for r in retention)
summary['retention']={'actual_canonical_roundtrips':36,'byte_equal':True,'source_modified':False,'capacity_reclaimed':False}
with tarfile.open(out/'retention.tar.gz','w:gz') as tar:tar.add(base/'retention',arcname='retention')
for stage in ('service-soak','service-soak-v2','service-soak-v3','service-soak-v4'):
 path=base/stage;plan=json.loads((path/'protocol.json').read_text());rows=json.loads((path/'results.json').read_text())
 report={'protocol':plan,'reports':rows,'planned':7,'executed_runtime':sum((p/'central-rejoin-1/result.json').exists() for p in path.iterdir() if p.is_dir())}
 if (path/'aborted.json').exists():report['aborted']=json.loads((path/'aborted.json').read_text())
 if stage=='service-soak-v4':
  assert len(rows)==7 and all(r['passed'] for r in rows[:4])
  report['passed']=sum(r['passed'] for r in rows)
  report['quiet_passed']=all(r['passed'] for r in rows[:4])
  report['loaded_passed']=all(r['passed'] for r in rows[4:])
  assert sha('build/m5-someip-normal/project/tests/integration/someip/someip_front_adapter')==plan['binary_sha256']
  report['response_summary']=[]
  for row in rows:
   try:response=json.loads((path/(row['case']+'-audit_service_response.log')).read_text())
   except ValueError:response={}
   capture=json.loads((path/row['case']/'central-rejoin-1'/'capture.json').read_text())
   assert capture['socket_drops']==0 and not capture['overflow'] and capture['affinity']==[0]
   report['response_summary'].append({'case':row['case'],'passed':row['passed'],'accepted_requests':response.get('accepted_requests'),
    'roundtrip_ns':response.get('metrics',{}).get('roundtrip_ns'),'remaining_margin_ns':response.get('metrics',{}).get('margin_ns'),
    'capture':capture,'response_mutations_rejected':response.get('mutations_rejected')})
  summary['native']['fixed_cohort']=report
 else:summary['initial'][stage]=report
 for p in sorted(path.iterdir()):
  if not p.is_dir():continue
  with tarfile.open(out/(stage+'-'+p.name+'.tar.gz'),'w:gz') as tar:tar.add(p,arcname=stage+'/'+p.name)
with tarfile.open(out/'initial-logical.tar.gz','w:gz') as tar:
 for name in ('power-initial','power-debug','clock-initial','clock-debug'):tar.add(base/name,arcname=name)
summary['initial']['power']={'gtests':5,'passed':4,'failed':1,'exported_cases':9,'binary_hash_available':False}
summary['initial']['clock']={'vehicle_gtests':1,'failed':1,'cause':'registry2 rejects startup Attempt before any durable append','binary_hash_available':False}
with tarfile.open(out/'initial-native-sources.tar.gz','w:gz') as tar:tar.add(base/'initial-soak-sources',arcname='sources')
for version in ('v2','v3'):
 (out/(version+'-sources.tar.gz')).write_bytes((base/(version+'-runtime-sources.tar.gz')).read_bytes())
manifest=json.loads((base/'final-runtime-sources.json').read_text());assert all(sha(p)==h for p,h in manifest.items())
(out/'sources.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'sources.tar.gz').write_bytes((base/'final-runtime-sources.tar.gz').read_bytes())
with tarfile.open(out/'validation.tar.gz','w:gz') as tar:
 for p in sorted(base.iterdir()):
  if p.is_file() and p.suffix not in ('.gz',) and p.name not in ('initial-soak-binary','soak-v2-binary'):tar.add(p,arcname=p.name)
 for name in ('debug-validation','asan-validation','tsan-validation','service-soak','service-soak-v2','service-soak-v3','service-soak-v4'):
  for p in sorted((base/name).iterdir()):
   if p.is_file():tar.add(p,arcname=name+'/'+p.name)
summary['source_files']=len(manifest);summary['static_analysis']={'core_tus':6,'clang_tidy':True,'cppcheck':True,'SDK_TU':'clang-tidy14 C++17 compatibility parse; actual GCC13 C++20 build; original header error retained'}
(out/'loaded-failure-analysis.json').write_bytes((base/'loaded-failure-analysis.json').read_bytes())
summary['native']['remaining']='loaded-1 original Drive command expiry; Front/Rear sequential dispatch and later renewal; failed normal/service run retained; no expiry extension'
(out/'acceptance.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print(json.dumps({'native_pass':summary['native']['fixed_cohort']['passed'],'native_total':7,'logical_profiles':3,'retention':36,'artifacts':len(list(out.iterdir())),'bytes':sum(p.stat().st_size for p in out.iterdir() if p.is_file())}))
