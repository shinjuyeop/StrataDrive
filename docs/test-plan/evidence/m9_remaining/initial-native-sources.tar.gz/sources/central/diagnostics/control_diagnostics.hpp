#pragma once
#include "diagnostics.hpp"
#include "clock_recovery.hpp"
#include "speed_request.hpp"
#include "vehicle_coordinator.hpp"

namespace stratadrive::diagnostics {
// v1 numeric dictionary, not CAN IDs or producer identities.
enum class Component : std::uint32_t { Speed=1, Stop=2, Coordinator=3, Drive=4, Brake=5, Power=6, Front=7, Rear=8, Steering=9, Bms=10, DriveWheel=11 };
enum class Monitor : std::uint32_t { Speed=1, Stop=2, Coordinator=3 };
enum class Subject : std::uint32_t { Wheel=1, StopCycle=2, Handoff=3, Protection=4, Torque=5, Pressure=6, Power=7 };
struct ControlContext {
    std::uint64_t run,producer;
    Domain domain;
    std::uint64_t clock_instance,profile;
};
// Called by the single Central owner after its existing control/protection work.
// Reads immutable source snapshots; only publishes bounded queue copies. No
// file IO, allocation, actuator writes, invented clocks or implicit INIT/clear.
class ControlDiagnostics {
public:
    ControlDiagnostics(EventQueue&,ControlContext,std::uint64_t first_sequence=1);
    // A native composition with a separate global issuer suppresses this
    // observer's Session; it must already have the actual global Release.
    bool start_session(std::uint32_t epoch,std::uint64_t enable_ns,bool publish_context=true) noexcept;
    void observe(const central::VehicleCoordinator&,std::uint64_t observed_ns) noexcept;
    void observe(const central::SpeedRequest&,const central::VehicleCoordinator&,std::uint64_t observed_ns) noexcept;
    void observe(const central::SpeedRequest&,std::uint64_t observed_ns) noexcept;
    void observe(const central::NormalStop&,std::uint64_t observed_ns) noexcept;
    // Trusted original local-owner selection/ACK evidence, never a Central
    // poll timestamp. actor_roles uses existing 8-role session bit positions.
    void local_protection(Component actor,std::uint32_t actor_roles,std::uint32_t epoch,
                          std::uint64_t original_ns,bool acknowledgement) noexcept;
    void observe_response(const central::NormalDriveReadinessInputs&,std::uint64_t observed_ns) noexcept;
    // Only a newer global Epoch with a healthy accepted native speed request
    // qualifies SD-1001/Speed monitor SD-1002. Input restoration or INIT alone cannot publish Passed.
    void observe_speed_recovery(const central::SpeedRequest&,const central::VehicleCoordinator&,
                                const central::NormalDriveReadinessInputs&,std::uint64_t observed_ns) noexcept;
    // Capture on the Central owner; pass this immutable evidence to the non-RT
    // writer together with an explicit clear intent/key/expected revision.
    std::optional<ServiceEvidence> speed_clear_evidence(const central::SpeedRequest&,
        const central::VehicleCoordinator&,const central::NormalDriveReadinessInputs&,
        const std::optional<can::DriveMessage>& current_speed_input,std::uint64_t now_ns) const noexcept;
    std::optional<ServiceEvidence> stop_clear_evidence(const central::VehicleCoordinator&,
        const central::NormalDriveReadinessInputs&,std::uint64_t now_ns) const noexcept;
    bool healthy() const noexcept { return healthy_; }
    bool revalidate_clock(const ClockRevalidation& check) noexcept {return clock_recovery_.revalidate(check,context_.domain,context_.clock_instance);}
    void observe_clock(const ClockRecoverySample& sample) noexcept {
        if(!healthy_)return;
        auto checked=sample;checked.native_healthy=checked.native_healthy && (sample.session==session_ && sample.released.enable_ns==enable_);
        clock_recovery_.observe(checked);
        while(auto e=clock_recovery_.take_ready()) {
            const auto id=publish(*e);
            if(!healthy_)return;
            e->kind=Kind::Passed;e->proof_event=id;publish(*e);
        }
    }
private:
    ClockRecovery clock_recovery_;
    std::optional<ServiceEvidence> stationary_evidence(const central::VehicleCoordinator&,
        const central::NormalDriveReadinessInputs&,const std::optional<can::DriveMessage>&,std::uint64_t) const noexcept;
    Stamp stamp(std::uint64_t,bool trusted=true) const noexcept;
    Event base(std::uint64_t observed_ns) const noexcept;
    EventId publish(Event) noexcept;
    void speed(const central::SpeedRequest&,const std::optional<central::VehicleRequest>&,std::uint64_t) noexcept;
    void stop(const central::NormalStop&,std::uint64_t) noexcept;
    void coordinator(const central::VehicleCoordinator&,std::uint64_t) noexcept;
    void remember_stop_recovery(const Event&,const central::NormalStopConfig&) noexcept;
    void stop_recovery(const central::VehicleCoordinator&,std::uint64_t) noexcept;
    void actuals(const central::NormalStopObservation&,const Event&,EventId,std::uint64_t) noexcept;
    EventQueue& queue_; const ControlContext context_;
    Session session_{}; std::uint64_t enable_{0},next_{1}; bool healthy_{true};
    bool speed_seen_{false},coordinator_seen_{false},response_seen_{false};
    std::array<bool,2> stop_seen_{},protection_seen_{}; std::array<bool,4> phase_seen_{};
    Event root_{};
    // Keep the old occurrence through INIT until its qualified recovery; the
    // source emitter itself is continuous. No process-restart adoption here.
    std::optional<Event> speed_recovery_target_;
    bool speed_recovered_{false};
    struct StopRecovery { Event fault; central::NormalStopConfig config; bool passed{false}; };
    std::array<std::optional<StopRecovery>,8> stop_recovery_targets_{};
};
} // namespace stratadrive::diagnostics
