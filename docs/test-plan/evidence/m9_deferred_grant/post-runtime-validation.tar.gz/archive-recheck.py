from pathlib import Path
import json,subprocess,tarfile
base=Path('build/m9-grant-basis');dest=base/'archive-recheck';dest.mkdir(exist_ok=False);results=[]
cases=[('m9_deferred_grant','tsan-r1.tar.gz','tsan-normal','audit_native_service.py',0),('m9_deferred_grant','tsan-r2.tar.gz','tsan-stop-request-loss-r2','audit_native_service_faults.py',0),('m9_deferred_grant','asan-r1.tar.gz','asan-normal','audit_native_service.py',1),('m9_stop_deadline','tsan-r2.tar.gz','tsan-actual-loss-r2','audit_service_response.py',1)]
for folder,archive,case,reader,expected in cases:
 prefix='service-campaign/'+case+'/';target=dest/folder
 with tarfile.open(Path('docs/test-plan/evidence')/folder/archive)as tar:
  for m in tar:
   if not m.isfile()or not m.name.startswith(prefix):continue
   assert '..'not in Path(m.name).parts
   p=target/m.name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(tar.extractfile(m).read())
 command=['python3','tests/integration/diagnostics/'+reader,str(target/prefix/'central-rejoin-1'),'--mutations']
 with(dest/(folder+'-'+case+'.log')).open('w')as log:code=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT)
 results.append({'archive':folder+'/'+archive,'case':case,'reader':reader,'expected_exit':expected,'exit':code});print(case,code,expected,flush=True)
(base/'archive-recheck.json').write_text(json.dumps(results,indent=2)+'\n');assert all(r['exit']==r['expected_exit']for r in results)
