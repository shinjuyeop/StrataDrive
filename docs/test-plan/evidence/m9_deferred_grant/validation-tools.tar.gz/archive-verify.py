from pathlib import Path
import hashlib,json,tarfile
base=Path('build/m9-grant-basis');reports=[]
configs=[('m9_allocation_release','input-phase-','m9-closeout'),('m9_allocation_release','release-slot-','m9-release-slot'),('m9_sdk_smt','','m9-sdk-smt'),('m9_stop_deadline','','m9-stop-poll'),('m9_deferred_grant','','m9-grant-basis')]
for folder,prefix,raw in configs:
 out=Path('docs/test-plan/evidence')/folder
 names=['normal-r1','asan-r1','tsan-r1','tsan-r2','tsan-r3']+([]if raw=='m9-sdk-smt'else['functional'])
 for name in names:
  archive=out/(prefix+name+'.tar.gz');files=0;size=0
  with tarfile.open(archive)as tar:
   for m in tar:
    if not m.isfile():continue
    assert not Path(m.name).is_absolute() and '..'not in Path(m.name).parts
    actual=Path('build')/raw/m.name;assert actual.is_file(),str(actual)
    payload=tar.extractfile(m).read();assert hashlib.sha256(payload).digest()==hashlib.sha256(actual.read_bytes()).digest(),m.name
    files+=1;size+=len(payload)
  reports.append({'archive':str(archive),'files':files,'bytes':size,'raw_contents_match':True})
  print(archive.name,files,flush=True)
(base/'archive-verification.json').write_text(json.dumps(reports,indent=2)+'\n')
