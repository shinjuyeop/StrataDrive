from pathlib import Path
import copy,hashlib,json,subprocess,sys,time
root=Path.cwd();base=root/'build/m9-grant-basis';source=base/'service-campaign';out=root/'build/m9-grant-confirmation'
original=json.loads((source/'results.json').read_text());functional=json.loads((base/'functional-regressions/results.json').read_text())
fields=('audit_exit','ordering_exit','timing_exit','response_exit')
assert len(original)==30 and len(functional)==12
if any(r[k]!=0 for r in original for k in fields) or any(r['exit']!=0 for r in functional):
 (base/'confirmation-disposition.json').write_text(json.dumps({'status':'NOT RUN','reason':'base fixed cohort failed'})+'\n');raise SystemExit(0)
out.mkdir(exist_ok=False);manifest=json.loads((source/'manifest.json').read_text());templates=[r for r in original if r['name'].startswith('tsan-')and not r['name'].endswith(('-r2','-r3'))];assert len(templates)==6
manifest['cases']=[{'template':r['name'],'round':i}for i in range(1,11)for r in templates]
manifest['confirmation_protocol']='docs/test-plan/deferred-grant-confirmation-protocol.md'
manifest['sources'][str(Path(__file__).relative_to(root))]=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');results=[]
for repeat in range(1,11):
 for template in templates:
  for name,digest in manifest['sources'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
  for profile,digest in manifest['binaries'].items():assert hashlib.sha256((root/f'build/m5-someip-{profile}/project/tests/integration/someip/someip_front_adapter').read_bytes()).hexdigest()==digest,profile
  name=template['name']+'-r'+str(repeat);command=copy.deepcopy(template['command']);assert command[2]==str(source/template['name']);command[2]=str(out/name)
  with(out/(name+'.runtime.log')).open('w')as log:code=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT)
  row={'name':name,'fault':template['fault'],'command':command,'runtime_exit':code,**{k:None for k in fields}};results.append(row)
  (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('runtime',len(results),name,code,flush=True)
(out/'runtime-complete.json').write_text(json.dumps({'runtimes':len(results),'monotonic_ns':time.monotonic_ns()})+'\n')
for row in results:
 scripts=[('audit_exit','audit_native_service.py'if row['fault']=='normal'else'audit_native_service_faults.py'),('ordering_exit','audit_service_ordering.py'),('timing_exit','audit_service_timing.py'),('response_exit','audit_service_response.py')]
 for field,script in scripts:
  command=[sys.executable,str(root/'tests/integration/diagnostics'/script),str(out/row['name']/'central-rejoin-1'),'--mutations']
  with(out/(row['name']+'.'+field+'.log')).open('w')as log:row[field]=subprocess.call(command,stdout=log,stderr=subprocess.STDOUT)
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print('audited',row['name'],[row[k]for k in fields],flush=True)
passed=sum(all(r[k]==0 for k in fields)for r in results)
(base/'confirmation-disposition.json').write_text(json.dumps({'status':'RUN','passed':passed,'total':len(results),'evidence':str(out.relative_to(root))})+'\n')
raise SystemExit(int(passed!=60))
