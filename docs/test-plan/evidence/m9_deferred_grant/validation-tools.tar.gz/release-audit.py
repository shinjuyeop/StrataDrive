"""Offline check: command generation must use the qualified nominal slot.
The grid phase is inferred from original allocation-readiness release rows;
this does not claim an independent clock agreement or physical completion.
"""
import bisect,csv,json
from pathlib import Path
period=10000000

def check(path):
 rows=list(csv.DictReader(path.open()));ready={};phase={};commands=[];bad=[]
 for row in rows:
  if row['event']=='allocation-readiness':
   epoch=int(row['epoch']);sent=int(row['sent']);phase.setdefault(epoch,sent%period)
   assert phase[epoch]==sent%period,(str(path),'inconsistent nominal grid',row)
   ready.setdefault(epoch,[]).append(row)
  if row['event']=='central-enqueued' and row['operation']=='3' and row['peer']=='0':commands.append(row)
 for row in commands:
  epoch=int(row['epoch']);generation=int(row['payload_source']);qualifications=ready.get(epoch,[])
  times=[int(r['ns'])for r in qualifications];at=bisect.bisect_right(times,generation)-1
  q=qualifications[at]if at>=0 else None
  actual=phase[epoch]+((generation-phase[epoch])//period)*period if epoch in phase else None
  if not q or q['decision']!='0' or int(q['sent'])!=actual:
   bad.append({'command':row,'qualification':q,'actual_slot':actual})
 return {'path':str(path),'commands':len(commands),'mismatches':bad}

report={}
for candidate in ('m9-closeout','m9-release-slot','m9-stop-poll','m9-grant-basis'):
 root=Path('build')/candidate/'service-campaign'
 report[candidate]=[check(p)for p in sorted(root.glob('*/central-rejoin-1/central-*.transport.csv'))]
out=Path('build/m9-grant-basis/release-audit.json');out.write_text(json.dumps(report,indent=2)+'\n')
for candidate,rows in report.items():print(candidate,'files',len(rows),'commands',sum(r['commands']for r in rows),'mismatches',sum(len(r['mismatches'])for r in rows))
