from pathlib import Path
import subprocess,json
base=Path('build/m9-grant-basis');source=Path('central/coordinator/async_coordinator_port.cpp');fixed=source.read_bytes();rows=[]
def run(name,cmd):
 with (base/(name+'.log')).open('w')as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 rows.append({'name':name,'command':cmd,'exit':r.returncode});(base/'red-green.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,r.returncode,flush=True);return r.returncode
try:
 old=fixed.replace(b'out.drive_permission.source_time_ns<due_release',b'out.drive_permission.source_time_ns<release');assert old!=fixed;source.write_bytes(old)
 assert run('red-build',['cmake','--build','build/m1-angle','--target','async_owner_test','--parallel','2'])==0
 assert run('red',['build/m1-angle/async_owner_test','--gtest_filter=AsyncOwnerTest.LateUnusedGrant*'])==1
finally:source.write_bytes(fixed)
assert run('green-build',['cmake','--build','build/m1-angle','--target','async_owner_test','vehicle_coordinator_test','--parallel','2'])==0
assert run('green-async',['build/m1-angle/async_owner_test'])==0
assert run('green-coordinator',['build/m1-angle/vehicle_coordinator_test'])==0
