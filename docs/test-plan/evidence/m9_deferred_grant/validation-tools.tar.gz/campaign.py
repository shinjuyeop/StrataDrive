import subprocess
raise SystemExit(subprocess.call(['python3','tests/integration/someip/service_timing_campaign.py','build/m9-grant-basis/service-campaign','--split-owner-io','--separate-aux-io','--owner-fifo','--tsan-repeats','3','--response-audit','--defer-audits']))
