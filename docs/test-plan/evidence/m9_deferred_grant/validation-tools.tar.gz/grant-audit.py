import bisect,csv,json
from pathlib import Path
base=Path('build/m9-grant-basis');report=[]
for path in sorted((base/'service-campaign').glob('*/central-rejoin-1/central-*.transport.csv')):
 rows=list(csv.DictReader(path.open()));ready={};seen={};bad=[];late=[];count=0
 for r in rows:
  epoch=int(r['epoch'])
  if r['event']=='allocation-readiness':ready.setdefault(epoch,[]).append(r)
  if r['event']!='central-enqueued' or r['operation']!='3' or r['peer']!='0':continue
  count+=1;generation=int(r['payload_source']);candidates=ready.get(epoch,[])
  index=bisect.bisect_right([int(q['ns'])for q in candidates],generation)-1
  q=candidates[index]if index>=0 else None
  if not q:bad.append({'command':r,'reason':'no qualification'});continue
  due,slot,source,expiry=(int(q[k])for k in ('source','sent','original_source','inner_deadline'))
  checks={'ready':q['decision']=='0','ordered_release':due<=slot,'fresh_for_due':source>=due,'genuine_source':source<=int(q['ns'])<=generation,
   'current_support':expiry>slot+18000000,'original_command_expiry':int(r['deadline'])<=expiry,'no_completed_reuse':epoch not in seen or due>seen[epoch]}
  if not all(checks.values()):bad.append({'command':r,'qualification':q,'checks':checks})
  if source<slot:late.append({'command':r,'qualification':q})
  seen[epoch]=slot
 report.append({'path':str(path),'commands':count,'mismatches':bad,'accepted_after_slot_crossing':late})
(base/'grant-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print('commands',sum(r['commands']for r in report),'mismatches',sum(len(r['mismatches'])for r in report),'late_unused_grants',sum(len(r['accepted_after_slot_crossing'])for r in report))
raise SystemExit(int(any(r['mismatches']for r in report)))
